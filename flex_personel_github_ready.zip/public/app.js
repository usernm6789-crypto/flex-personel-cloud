// ===== CONFIG =====
// Authentication is handled by the cloud server. These values are only a local cache for the settings UI.
const DEFAULT_CREDS = { recovery: "" };
function getCreds() {
  try { return JSON.parse(localStorage.getItem("cloud_accounts") || "{}"); } catch { return {}; }
}
function toggleForgot() { const b = document.getElementById("forgotBox"); b.style.display = b.style.display === "none" ? "block" : "none"; }
async function resetPassword() {
  const acc = document.getElementById("rpAcc").value, code = document.getElementById("rpCode").value.trim(), np = document.getElementById("rpPass").value, err = document.getElementById("loginError");
  if (np.length < 4) { err.textContent = "Yangi parol kamida 4 belgi bo'lsin"; return; }
  try {
    const r = await fetch('/api/reset-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({account:acc,code,password:np})});
    const j = await r.json(); if(!r.ok) throw new Error(j.error||'Xatolik');
    err.style.color = "#065f46"; err.textContent = "Parol yangilandi ✓ Endi kirishingiz mumkin"; document.getElementById("forgotBox").style.display = "none";
  } catch(e) { err.style.color = "#c00"; err.textContent = e.message; }
}

const OBJECTS = [
  { id: "jois", name: "JOIS", short: "JOIS" },
  { id: "nagatino", name: "NAGATINO", short: "NAG 1" },
  { id: "nagatino2", name: "NAGATINO 2", short: "NAG 2" },
  { id: "preobrejenka", name: "PREOBREJENKA", short: "PRB" }
];

const ALL_COUNTRIES = [
  "УЗБЕКИСТАН","ТАДЖИКИСТАН","АЗЕРБАЙДЖАН","ТУРЦИЯ","ТУРКМЕНИСТАН","КАЗАХСТАН","КЫРГЫЗСТАН","РОССИЯ",
  "БЕЛАРУСЬ","АРМЕНИЯ","ГРУЗИЯ","МОЛДОВА","УКРАИНА","КИТАЙ","ИНДИЯ","ПАКИСТАН","АФГАНИСТАН",
  "ИРАН","ИРАК","СИРИЯ","ЕГИПЕТ","ГЕРМАНИЯ","ФРАНЦИЯ","ИТАЛИЯ","ИСПАНИЯ","ПОЛЬША","РУМЫНИЯ",
  "БОЛГАРИЯ","СЕРБИЯ","БОСНИЯ","МАКЕДОНИЯ","АЛБАНИЯ","ГРЕЦИЯ","БОЛГАРИЯ","ФИЛИППИНЫ","ВЬЕТНАМ",
  "ТАИЛАНД","ИНДОНЕЗИЯ","ЮЖНАЯ КОРЕЯ","ЯПОНИЯ","США","КАНАДА","БРАЗИЛИЯ","МЕКСИКА","НИГЕРИЯ",
  "КЕНИЯ","ЭФИОПИЯ","МАРОККО","АЛЖИР","ТУНИС","ИОРДАНИЯ","ЛИВАН","ПАЛЕСТИНА","БАНГЛАДЕШ","НЕПАЛ",
  "ШРИ-ЛАНКА","МЬЯНМА","КАМБОДЖА","ЛАОС","МОНГОЛИЯ","СЕВЕРНАЯ КОРЕЯ","КУБА","ВЕНЕСУЭЛА","КОЛУМБИЯ",
  "ПЕРУ","ЧИЛИ","АРГЕНТИНА","ЕГИПЕТ","СУДАН","СОМАЛИ","ЙЕМЕН","САУДОВСКАЯ АРАВИЯ","ОАЭ","КАТАР",
  "КУВЕЙТ","ОМАН","БАХРЕЙН","ИЗРАИЛЬ","ЧЕХИЯ","СЛОВАКИЯ","ВЕНГРИЯ","АВСТРИЯ","ШВЕЙЦАРИЯ","НИДЕРЛАНДЫ",
  "БЕЛЬГИЯ","ЛЮКСЕМБУРГ","ПОРТУГАЛИЯ","ШВЕЦИЯ","НОРВЕГИЯ","ФИНЛЯНДИЯ","ДАНИЯ","ИРЛАНДИЯ","ВЕЛИКОБРИТАНИЯ",
  "АВСТРАЛИЯ","НОВАЯ ЗЕЛАНДИЯ","ЮАР","ГАННА","УГАНДА","ТАНЗАНИЯ","КОНГО","АНГОЛА","МОЗАМБИК"
];
function fillDavlatList(q) {
  const dl = document.getElementById("davlatList");
  const hints = document.getElementById("davlatHints");
  if (!dl) return;
  const qq = (q || "").toLowerCase().trim();
  const list = qq.length < 1 ? ALL_COUNTRIES : ALL_COUNTRIES.filter(c => c.toLowerCase().includes(qq) || c.toLowerCase().startsWith(qq));
  dl.innerHTML = list.slice(0, 80).map(c => `<option value="${c}">`).join("");
  if (hints) {
    if (qq.length >= 1 && list.length) {
      hints.style.display = "block";
      hints.innerHTML = list.slice(0, 15).map(c => `<div style="padding:4px 8px;cursor:pointer" onmousedown="document.getElementById('f_davlat').value='${c}';onDavlatChange();document.getElementById('davlatHints').style.display='none'">${c}</div>`).join("");
    } else hints.style.display = "none";
  }
}
function onDavlatInput() {
  fillDavlatList(document.getElementById("f_davlat")?.value || "");
}
function onDavlatChange() {
  const d = (document.getElementById("f_davlat")?.value || "").trim();
  // auto-set millat from country if empty
  const mil = document.getElementById("f_millat");
  if (mil && !mil.value && d) {
    const map = { "УЗБЕКИСТАН":"o'zbek", "ТАДЖИКИСТАН":"tojik", "АЗЕРБАЙДЖАН":"ozarbayjon", "ТУРЦИЯ":"turk", "ТУРКМЕНИСТАН":"turkman", "КАЗАХСТАН":"qozoq", "КЫРГЫЗСТАН":"qirg'iz", "РОССИЯ":"rus" };
    mil.value = map[d] || "";
  }
  // trigger doc type logic using country as millat proxy
  const fake = { value: d };
  // call existing logic
  if (typeof onMillatChange === "function") {
    // temporarily set f_millat select if it was select - now input
    onMillatChangeFromCountry(d);
  }
  const hints = document.getElementById("davlatHints");
  if (hints) hints.style.display = "none";
}
function onMillatChangeFromCountry(country) {
  const mil = (country || "").toLowerCase();
  const isRuLike = /росси|russia|рус|қазақ|qozoq|kazakh|казах|кыргыз|qirg|kyrgyz|беларус|армен/i.test(mil);
  const isPatent = /узбек|таджик|азербайджан|uzbek|tajik|azerbayjan/i.test(mil);
  const isPermit = /турк|turk|türk|туркмен|turkmen/i.test(mil);
  const docSel = document.getElementById("f_doc_type");
  if (docSel && !docSel.dataset.userSet) {
    if (isRuLike) docSel.value = "РФ";
    else if (isPatent) docSel.value = "Патент";
    else if (isPermit) docSel.value = "РНР";
  }
  if (typeof onDocTypeChange === "function") onDocTypeChange();
}

let currentObj = null;
let editId = null;
let exitWorkerId = null;

// ===== AUTH =====
function requireAuth() {
  const a = JSON.parse(localStorage.getItem("auth") || "null");
  if (!a) { location.href = "index.html"; return; }
  a.role = a.role || "admin";
  if (a.role === "obj") {
    const id = new URLSearchParams(location.search).get("id");
    if (!/object\.html/.test(location.pathname) || id !== a.obj) { location.href = "object.html?id=" + a.obj; return; }
    document.querySelector(".back")?.remove();
  }
  const el = document.getElementById("userEmail");
  if (el) el.textContent = a.email || "";
}

document.getElementById("loginForm")?.addEventListener("submit", async e => {
  e.preventDefault();
  const login = document.getElementById("email").value.trim(), pass = document.getElementById("password").value;
  const err = document.getElementById("loginError"); err.textContent = "";
  try {
    const r = await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({login,password:pass})});
    const j = await r.json(); if(!r.ok) throw new Error(j.error||"Login yoki parol noto'g'ri");
    localStorage.setItem("auth", JSON.stringify(j.user));
    localStorage.setItem("cloud_user", JSON.stringify(j.user));
    localStorage.setItem("cloud_objects", JSON.stringify(j.objects||[]));
    location.href = j.user.role === 'admin' ? 'dashboard.html' : 'object.html?id='+j.user.obj;
  } catch(e) { err.textContent = e.message; }
});

async function logout() {
  try { await fetch('/api/logout',{method:'POST'}); } catch(e) {}
  localStorage.removeItem("auth");
  localStorage.removeItem("cloud_user");
  location.href = "index.html";
}

// ===== DASHBOARD =====
function renderObjects() {
  const box = document.getElementById("objectsList");
  if (!box) return;
  box.innerHTML = OBJECTS.map(o => {
    const n = JSON.parse(localStorage.getItem("workers_" + o.id) || "[]").filter(w => !w.exited).length;
    return `<div class="obj-card" onclick="location.href='object.html?id=${o.id}'">
      <div class="obj-card-head"><div class="ico">🏗️</div><span class="obj-live">● Faol</span></div>
      <h3>${o.name}</h3><div class="obj-card-count"><b>${n}</b><span>odam</span></div>
    </div>`;
  }).join("");
}

// ===== OBJECT PAGE =====
function initObject() {
  const id = new URLSearchParams(location.search).get("id");
  const obj = OBJECTS.find(o => o.id === id);
  if (!obj) { location.href = "dashboard.html"; return; }
  currentObj = id;
  document.getElementById("objTitle").textContent = obj.name;
  document.title = obj.name + " — Flex Personel";

  // default dates
  const today = todayStr();
  const month = today.slice(0,7);
  ["statDate","puantajDate","sonDate"].forEach(i => {
    const el = document.getElementById(i);
    if (el) el.value = today;
  });
  const bm = document.getElementById("bodroMonth");
  if (bm) bm.value = month;

  // seed sample data for JOIS if empty
  if (id === "jois") seedJoisData();
  migrateWorkers();
  getBrigades();
  if (!localStorage.getItem(key("dbfill_v1"))) { autoFillAll(); localStorage.setItem(key("dbfill_v1"), "1"); }
  onTurChange();

  updateStats();
  renderPuantaj();
  renderWorkers();
  renderPatent();
  renderChiqishlar();
  renderBodro();
  renderKunlikSon();
}

function showSection(name) {
  document.querySelectorAll(".side-item").forEach(el => el.classList.remove("active"));
  document.querySelector(`.side-item[data-section="${name}"]`)?.classList.add("active");
  document.querySelectorAll(".section").forEach(s => s.classList.remove("active"));
  document.getElementById("sec-" + name)?.classList.add("active");

  if (name === "kunlik") renderPuantaj();
  if (name === "oylik") renderBodro();
  if (name === "ishchilar") renderWorkers();
  if (name === "transfer") renderTransfers();
  if (name === "brigadalar") renderBrigades();
  if (name === "lavozimlar") renderPositionManager();
  if (name === "patent") renderPatent();
  if (name === "chiqishlar") renderChiqishlar();
  if (name === "kunlik_son") renderKunlikSon();
  if (name === "yoqlama") { const t=todayStr(); const f=document.getElementById("yoqFrom"),to=document.getElementById("yoqTo"); if(f&&!f.value)f.value=t.slice(0,8)+"01"; if(to&&!to.value)to.value=t; renderYoqlama(); }
  if (name === "kirish_chiqish_form") fillKCFWorkers();
  if (name === "statistika") updateStats();
  if (name === "dogovor") renderDogovor();
  if (name === "malumot") renderMalumot();
  if (name === "garantiya") renderGarantiya();
}

// ===== DATA HELPERS =====
function key(k) { return `${k}_${currentObj}`; }
function getWorkers() { return JSON.parse(localStorage.getItem(key("workers")) || "[]"); }
function saveWorkers(list) { localStorage.setItem(key("workers"), JSON.stringify(list)); }
function getExits() { return JSON.parse(localStorage.getItem(key("exits")) || "[]"); }
function saveExits(list) { localStorage.setItem(key("exits"), JSON.stringify(list)); }
function getPuantaj(date) { return JSON.parse(localStorage.getItem(key("puantaj_" + date)) || "{}"); }
function savePuantajData(date, data) { localStorage.setItem(key("puantaj_" + date), JSON.stringify(data)); }

// ===== SEED sample JOIS workers =====
function normFio(s) { return (s || "").toLowerCase().replace(/ё/g, "е").replace(/\s+/g, " ").trim(); }
function seedJoisData() {
  if (typeof JOIS_SEED === "undefined" || localStorage.getItem("seed_jois_v3")) return;
  const cur = getWorkers().filter(w => !/^w\d{1,2}$/.test(w.id));   // eski namuna ishchilar o'chadi
  const have = new Set(cur.map(w => normFio(w.fio)));
  JOIS_SEED.forEach(w => { if (!have.has(normFio(w.fio))) cur.push({ ...w }); });
  saveWorkers(cur);
  localStorage.setItem("seed_jois_v3", "1");
}

// ===== STATISTIKA =====
function updateStats() {
  const workers = getWorkers().filter(w => !w.exited);
  const kunduz = workers.filter(w => !isStaff(w) && w.vardiya !== "GECE").length;
  const kecha = workers.filter(w => !isStaff(w) && w.vardiya === "GECE").length;
  const staff = workers.filter(isStaff).length;
  document.getElementById("statKunduz").textContent = kunduz;
  document.getElementById("statKecha").textContent = kecha;
  document.getElementById("statStaff").textContent = staff;
  document.getElementById("statJami").textContent = workers.length;
  const g = dayGroups(document.getElementById("statDate")?.value || todayStr());
  [["Ishda","CALISAN"],["Hasta","HASTA"],["Izinli","IZINLI"],["Fms","FMS"],["Yok","YOK"]].forEach(([id,s]) => {
    const el = document.getElementById("stat" + id); if (el) el.textContent = g[s].length;
  });
}

// ===== KUNLIK PUANTAJ =====
function renderPuantaj() {
  const tbody = document.getElementById("puantajBody");
  if (!tbody) return;
  const date = document.getElementById("puantajDate")?.value || todayStr();
  const workers = activeWorkers(document.getElementById("puantajDate")?.value || todayStr());
  const saved = getPuantaj(date);
  const defH = getDefaultHours(date);

  // group by ekip
  const groups = {};
  workers.forEach(w => {
    const g = w.ekip || "Boshqa";
    if (!groups[g]) groups[g] = [];
    groups[g].push(w);
  });

  let html = "";
  let num = 1;
  Object.keys(groups).sort().forEach(gName => {
    num = 1;   // har ekipda raqam 1 dan boshlanadi
    html += `<tr style="background:#eef2f7"><td colspan="9"><b>${gName}</b></td></tr>`;
    groups[gName].forEach(w => {
      const rec = saved[w.id] || { status:"CALISAN", hours: defH, note:"" };
      // agar saqlangan soat bo'sh bo'lsa default qo'yamiz
      const lk = lockHours(w, rec.status);
      if (lk !== undefined) rec.hours = lk;
      else if (rec.hours === "" || rec.hours === undefined || rec.hours === null) rec.hours = defH;
      html += `<tr>
        <td>${w.ekip || ""}</td>
        <td>${num++}</td>
        <td>${w.sicil || ""}</td>
        <td><b style="cursor:pointer;color:#1d4ed8" onclick="showProfile(currentObj,'${w.id}')">${esc(w.fio)}</b>${missingData(w).length ? ` <span title="Ma&#39;lumot to&#39;liq emas">⚠️</span>` : ""}</td>
        <td>${w.lavozim || ""}</td>
        <td><select onchange="setShift('${w.id}', this.value)"><option value="GUNDUZ" ${w.vardiya !== "GECE" ? "selected" : ""}>Kunduz</option><option value="GECE" ${w.vardiya === "GECE" ? "selected" : ""}>Kecha</option></select></td>
        <td>
          <select id="st_${w.id}" data-prev="${rec.status}" onchange="statusChanged('${w.id}')">
            <option value="CALISAN" ${rec.status==="CALISAN"?"selected":""}>CALISAN</option>
            <option value="IZINLI" ${rec.status==="IZINLI"?"selected":""}>IZINLI</option>
            <option value="HASTA" ${rec.status==="HASTA"||rec.status==="KASAL"?"selected":""}>HASTA</option>
            <option value="CIKIS" ${rec.status==="CIKIS"?"selected":""}>CIKIS</option>
            <option value="FMS" ${rec.status==="FMS"?"selected":""}>FMS</option>
            <option value="YOK" ${rec.status==="YOK"?"selected":""}>YOK</option>
            ${trOptions()}
          </select>
        </td>
        <td><input type="number" id="hr_${w.id}" value="${rec.hours}" min="0" max="24" step="0.5" ${lockHours(w, rec.status) !== undefined ? 'readonly onclick="lockMsg(\'' + w.id + '\')"' : ""}></td>
        <td><input type="text" id="nt_${w.id}" value="${rec.note || ""}" style="width:100px"></td>
      </tr>`;
    });
  });
  tbody.innerHTML = html || `<tr><td colspan="9" style="text-align:center;color:#888;padding:20px">Ishchilar yo'q</td></tr>`;
}

function savePuantaj() {
  const date = document.getElementById("puantajDate").value;
  const workers = getWorkers().filter(w => !w.exited);
  const data = {};
  workers.forEach(w => {
    data[w.id] = {
      status: document.getElementById("st_" + w.id)?.value || "CALISAN",
      hours: lockHours(w, document.getElementById("st_" + w.id)?.value) ?? (document.getElementById("hr_" + w.id)?.value || ""),
      note: document.getElementById("nt_" + w.id)?.value || ""
    };
  });
  savePuantajData(date, data);
  // also push hours to bodro
  pushToBodro(date, data);
  alert("Kunlik puantaj saqlandi ✓");
}

function pushToBodro(date, data) {
  // date = YYYY-MM-DD → day number
  const day = parseInt(date.slice(8,10), 10);
  const monthKey = key("bodro_" + date.slice(0,7));
  const bodro = JSON.parse(localStorage.getItem(monthKey) || "{}");
  Object.keys(data).forEach(wid => {
    if (!bodro[wid]) bodro[wid] = {};
    bodro[wid][day] = data[wid].hours ?? "";
  });
  localStorage.setItem(monthKey, JSON.stringify(bodro));
}

// ===== OYLIK BODRO =====
let bodroEditMode=false;
function toggleBodroEdit(){bodroEditMode=!bodroEditMode;const b=document.getElementById("bodroEditBtn");if(b){b.textContent=bodroEditMode?"✓ Tahrirlashni tugatish":"✎ Tahrirlash";b.classList.toggle("btn-main",bodroEditMode)}renderBodro()}
function transferHistoryForWorker(w){return Array.isArray(w.transferHistory)?w.transferHistory:[]}
function bodroWorkers(month){
  const active=getWorkers().filter(w=>!w.exited),map=new Map(active.map(w=>[w.id,w]));
  const trs=JSON.parse(localStorage.getItem("flex_pending_transfers_v3")||"[]");
  trs.filter(t=>t.status==="ACCEPTED"&&t.from===currentObj).forEach(t=>{const w=t.worker;if(w&&!map.has(w.id))map.set(w.id,w)});
  return [...map.values()];
}
function sourceBodroValue(src,id,month,day){try{const b=JSON.parse(localStorage.getItem("bodro_"+src+"_"+month)||"{}");return b?.[id]?.[day]??""}catch(e){return ""}}
function transferSourceForDay(w,date){
  const hs=transferHistoryForWorker(w).filter(h=>h.to===currentObj&&h.effectiveDate&&date<h.effectiveDate);if(!hs.length)return null;
  hs.sort((a,b)=>b.effectiveDate.localeCompare(a.effectiveDate));return hs[0].from||null;
}
function renderBodro(){
  const month=document.getElementById("bodroMonth")?.value||todayStr().slice(0,7),[y,m]=month.split("-").map(Number),dim=new Date(y,m,0).getDate();
  const b=JSON.parse(localStorage.getItem(key("bodro_"+month))||"{}"),all=bodroWorkers(month);fillBodro("S",all.filter(isStaff),dim,b,month);fillBodro("",all.filter(w=>!isStaff(w)),dim,b,month);
}
function fillBodro(sfx,list,dim,b,month){
  const head=document.getElementById("bodroHead"+sfx),body=document.getElementById("bodroBody"+sfx);if(!head||!body)return;
  let h=`<tr><th>№</th><th>F.I.O</th><th>Sicil</th><th>Lavozim</th><th>Ekip</th>`;for(let d=1;d<=dim;d++)h+=`<th>${d}</th>`;head.innerHTML=h+`<th>Jami</th></tr>`;
  // group by ekip
  const groups={};
  list.forEach(w=>{const g=isStaff(w)?"STAFF":(w.ekip||"Boshqa");(groups[g]=groups[g]||[]).push(w);});
  const order=["STAFF",...getBrigades().map(x=>x.name)];
  Object.keys(groups).forEach(g=>{if(!order.includes(g))order.push(g);});
  let html="", num=1;
  order.forEach(gName=>{
    const gl=groups[gName]; if(!gl||!gl.length)return;
    const br=getBrigades().find(x=>x.name===gName);
    const title=gName==="STAFF"?"STAFF (Ofis)":(br&&br.leader?`${gName} — ${br.leader}`:gName);
    html+=`<tr style="background:#e0e7ff"><td colspan="${dim+6}"><b>${esc(title)}</b> (${gl.length})</td></tr>`;
    gl.sort((a,b)=>(a.fio||"").localeCompare(b.fio||"","uz")).forEach(w=>{
      const days=b[w.id]||{};let total=0,cells="";
      for(let d=1;d<=dim;d++){
        const ds=`${month}-${String(d).padStart(2,"0")}`,src=transferSourceForDay(w,ds);
        let v=days[d]??"";if(v===""&&src)v=sourceBodroValue(src,w.id,month,d);total+=parseFloat(v)||0;
        const edited=(JSON.parse(localStorage.getItem(key("bodro_edits_"+month))||"{}")[w.id]||{})[d];
        const dayDate=new Date(ds+"T12:00:00"),now=new Date();now.setHours(12,0,0,0);
        const daysAgo=Math.floor((now-dayDate)/864e5);const showRed=edited&&daysAgo>3;
        const canEdit=bodroEditMode&&daysAgo<=3;
        const hist=src?` title="${esc((OBJECTS.find(o=>o.id===src)||{}).short||src)} dan"`:"";
        cells+=`<td class="${src?"history-cell":""} ${showRed?"bodro-edited":""}"${hist} ${canEdit?'contenteditable="true" onblur="editBodroCell(\''+w.id+'\','+d+',this)"':''}>${esc(v)}</td>`;
      }
      html+=`<tr><td>${num++}</td><td><b>${esc(w.fio)}</b></td><td>${esc(w.sicil)}</td><td>${esc(w.lavozim||w.dolzhnost||"")}</td><td>${esc(w.ekip)}</td>${cells}<td><b>${total.toFixed(1)}</b></td></tr>`;
    });
  });
  body.innerHTML=html||`<tr><td colspan="${dim+6}" style="text-align:center;color:#888;padding:20px">Ma'lumot yo'q</td></tr>`;
}

function editBodroCell(wid,day,el){
  const month=document.getElementById("bodroMonth").value,monthKey=key("bodro_"+month),bodro=JSON.parse(localStorage.getItem(monthKey)||"{}");if(!bodro[wid])bodro[wid]={};const value=el.textContent.trim();bodro[wid][day]=value;localStorage.setItem(monthKey,JSON.stringify(bodro));
  const edits=JSON.parse(localStorage.getItem(key("bodro_edits_"+month))||"{}");if(!edits[wid])edits[wid]={};edits[wid][day]=true;localStorage.setItem(key("bodro_edits_"+month),JSON.stringify(edits));
  const date=`${month}-${String(day).padStart(2,"0")}`,p=getPuantaj(date);if(!p[wid])p[wid]={status:"CALISAN",hours:value,note:"Bodrodan tahrirlangan"};else p[wid].hours=value;savePuantajData(date,p);
  el.classList.add("bodro-edited");toast(`${day}.${month.split("-")[1]} bodro va puantajda yangilandi ✓`);
}

// ===== ISHCHILAR =====
function renderWorkers() {
  const tbody = document.getElementById("workersBody");
  if (!tbody) return;
  const q = (document.getElementById("searchWorker")?.value || "").toLowerCase();
  let list = getWorkers().filter(w => !w.exited);
  if (q) list = list.filter(w =>
    (w.fio||"").toLowerCase().includes(q) ||
    (w.sicil||"").toLowerCase().includes(q) ||
    (w.pasport||"").toLowerCase().includes(q) ||
    (w.inn||"").toLowerCase().includes(q) ||
    (w.snils||"").toLowerCase().includes(q) ||
    (w.lavozim||"").toLowerCase().includes(q) ||
    (w.ekip||"").toLowerCase().includes(q)
  );

  tbody.innerHTML = list.map((w, i) => {
    const daysLeft = expiryDays(w);
    const badge = patentBadge(daysLeft);
    return `<tr>
      <td>${i+1}</td>
      <td><b style="cursor:pointer;color:#1d4ed8" onclick="showProfile(currentObj,'${w.id}')">${esc(w.fio)}</b>${missingData(w).length ? ` <span title="Ma&#39;lumot to&#39;liq emas">⚠️</span>` : ""}</td>
      <td>${w.sicil||""}</td>
      <td>${w.lavozim||""}</td>
      <td>${w.ekip||""}</td>
      <td>${w.vardiya||""}</td>
      <td>${w.pasport||""}</td>
      <td>${w.patent_tugash||"—"} ${badge}</td>
      <td><span class="badge badge-green">Ishlayapti</span></td>
      <td>
        <button class="btn-sm" onclick="editWorker('${w.id}')">Tahrir</button>
        <button class="btn-sm" style="background:#fee2e2;color:#991b1b" onclick="openExit('${w.id}')">Chiqarish</button>
      </td>
    </tr>`;
  }).join("") || `<tr><td colspan="10" style="text-align:center;color:#888;padding:20px">Ishchilar yo'q</td></tr>`;
}

// Ruxsatnoma: har oy olingan sanadan hisoblanadi, to'lov kamida 2 kun oldin
function getNextPatentDue(patentBerilgan) {
  if (!patentBerilgan) return null;
  const start = new Date(patentBerilgan);
  const now = new Date();
  now.setHours(0,0,0,0);
  // keyingi to'lov sanasi = olingan kunning shu oydagi yoki keyingi oydagi sanasi
  let due = new Date(now.getFullYear(), now.getMonth(), start.getDate());
  if (due < now) {
    due = new Date(now.getFullYear(), now.getMonth() + 1, start.getDate());
  }
  return due;
}

function payDue(w) {   // keyingi to'lov sanasi: patent berilgan sanadan har 30 kunda
  if (w.doc_type && !/патент/i.test(w.doc_type)) return null;
  if (!w.patent_berilgan) return null;
  const s = pdate(w.patent_berilgan), t = today0();
  for (let n = 1; n < 400; n++) {
    const d = addDays(s, 30 * n);
    if (d >= addDays(t, -3) && (!w.paid_due || ymd(d) > w.paid_due)) return d;
  }
  return null;
}
function expiryDays(w) { return w.patent_tugash ? Math.round((pdate(w.patent_tugash) - today0()) / 864e5) : 999; }
function payDays(w) { const d = payDue(w); return d ? Math.round((d - today0()) / 864e5) - 2 : 999; }   // to'lov kamida 2 kun oldin
function patentDaysLeft(w) { const p = payDays(w); return p < 900 ? p : expiryDays(w); }

function patentBadge(days) {
  if (days >= 900) return "";
  if (days <= 7) return `<span class="badge badge-red">${days} kun</span>`;
  if (days <= 14) return `<span class="badge badge-yellow">${days} kun</span>`;
  return `<span class="badge badge-green">${days} kun</span>`;
}

// ===== QO'SHISH / TAHRIRLASH =====
function saveWorker(e) {
  e.preventDefault();
  const list = getWorkers();
  const data = {
    id: editId || ("w_" + Date.now()),
    fio: val("f_fio"),
    sicil: val("f_sicil"),
    lavozim: val("f_lavozim"),
    dolzhnost: val("f_dolzhnost"),
    tugilgan: val("f_tugilgan"),
    tur: val("f_tur") || "DIREKT",
    ekip: val("f_tur") === "ENDIREKT" ? "STAFF" : val("f_ekip"),
    vardiya: val("f_vardiya") || "GUNDUZ",
    millat: val("f_millat") || val("f_davlat"),
    davlat: val("f_davlat"),
    pasport: val("f_pasport"),
    pasport_berilgan: val("f_pasport_berilgan"),
    pasport_tugash: val("f_pasport_tugash"),
    pasport_beruvchi: val("f_pasport_beruvchi"),
    fuqarolik: val("f_fuqarolik"),
    doc_type: val("f_doc_type"),
    inn: val("f_inn"),
    snils: val("f_snils"),
    patent: val("f_patent"),
    patent_berilgan: val("f_patent_berilgan"),
    patent_tugash: val("f_patent_tugash"),
    exited: false
  };

  if (data.tur === "DIREKT" && !data.ekip) { alert("Brigadani tanlang"); return false; }
  if (!editId && isBlacklisted(data)) { alert("⛔ Bu shaxs qochib ketgan sifatida qora ro'yxatda. Firmaga qabul qilinmaydi."); return false; }
  if (editId) {
    const idx = list.findIndex(w => w.id === editId);
    if (idx >= 0) list[idx] = { ...list[idx], ...data };
  } else {
    list.push(data);
  }
  // Patent kutilmoqda: patent davlati + hujjat yo'q / raqam yo'q
  const idxSaved = editId ? list.findIndex(w => w.id === editId) : list.length - 1;
  const ww = list[idxSaved >= 0 ? idxSaved : list.length - 1];
  if (ww) {
    const kind = typeof getDocKind === "function" ? getDocKind(ww) : "";
    if ((kind === "patent" || ww.doc_type === "Патент" || ww.doc_type === "Ожидание патент") && !ww.patent) {
      ww.doc_type = "Ожидание патент";
    }
    if (!ww.doc_type && kind === "patent") ww.doc_type = ww.patent ? "Патент" : "Ожидание патент";
  }
  saveWorkers(list);
  editId = null;
  resetForm();
  // hamma joyga avtomatik
  if (typeof renderPuantaj === "function") renderPuantaj();
  if (typeof renderBodro === "function") renderBodro();
  if (typeof renderPatent === "function") renderPatent();
  if (typeof renderMalumot === "function") renderMalumot();
  if (typeof renderWorkers === "function") renderWorkers();
  if (typeof renderKunlikSon === "function") renderKunlikSon();
  if (typeof updateStats === "function") updateStats();
  alert("Saqlandi ✓ — puantaj, bodro, patent, GP ga qo'shildi");
  showSection("ishchilar");
  renderWorkers();
  updateStats();
  return false;
}

function val(id) { return document.getElementById(id)?.value.trim() || ""; }

function editWorker(id) {
  const w = getWorkers().find(x => x.id === id);
  if (!w) return;
  editId = id;
  document.getElementById("formTitle").textContent = "Ishchini tahrirlash";
  set("f_fio", w.fio); set("f_tugilgan", w.tugilgan); set("f_sicil", w.sicil); set("f_lavozim", w.lavozim); set("f_dolzhnost", w.dolzhnost);
  set("f_tur", isStaff(w) ? "ENDIREKT" : "DIREKT"); onTurChange(); set("f_ekip", w.ekip); set("f_vardiya", w.vardiya === "GECE" ? "GECE" : "GUNDUZ"); set("f_davlat", w.davlat || w.millat || ""); set("f_millat", w.millat || "");
    if (typeof fillDavlatList === "function") fillDavlatList("");
    if (typeof onDavlatChange === "function") onDavlatChange();
  set("f_pasport", w.pasport); set("f_pasport_berilgan", w.pasport_berilgan);
  set("f_pasport_tugash", w.pasport_tugash); set("f_pasport_beruvchi", w.pasport_beruvchi || ""); set("f_fuqarolik", w.fuqarolik || w.millat || "");
    const fqs = document.getElementById("f_fuqarolik_sel");
    if (fqs) {
      const v = (w.fuqarolik || w.millat || "").toLowerCase();
      if ([...fqs.options].some(o => o.value === v)) fqs.value = v;
      else if (v) fqs.value = "__other";
    }
    if (typeof onFuqarolikChange === "function") onFuqarolikChange(); set("f_doc_type", w.doc_type || ""); set("f_inn", w.inn); set("f_snils", w.snils);
  set("f_patent", w.patent); set("f_patent_berilgan", w.patent_berilgan);
  set("f_patent_tugash", w.patent_tugash);
  showSection("qoshish");
}

function set(id, v) { const el = document.getElementById(id); if (el) el.value = v || ""; }

function quickEditPosition(id){
  const w=getWorkers().find(x=>x.id===id); if(!w)return;
  const lists=getPositionLists();
  const arr=isStaff(w)?lists.staff:lists.direct;
  const hint=arr.map((x,i)=>`${i+1}. ${x.uz} — ${x.ru}`).join("\n");
  const ans=prompt(`Lavozimni tanlang (raqam):\n\n${hint}`, String(Math.max(1, arr.findIndex(x=>x.uz===w.lavozim)+1)));
  if(ans===null)return; const n=parseInt(ans,10);
  if(!Number.isInteger(n)||n<1||n>arr.length){alert("Ro‘yxatdagi raqamni tanlang.");return;}
  w.lavozim=arr[n-1].uz; w.dolzhnost=arr[n-1].ru;
  saveWorkers(getWorkers().map(x=>x.id===id?w:x)); renderWorkers(); toast("Lavozim yangilandi ✓");
}
function renderPositionManager(){
  const box=document.getElementById("positionManager"); if(!box)return;
  const lists=getPositionLists();
  const row=(x,type,i)=>`<div class="position-edit-row">
    <input id="pos_${type}_uz_${i}" value="${esc(x.uz)}" placeholder="O'zbekcha">
    <input id="pos_${type}_ru_${i}" value="${esc(x.ru)}" placeholder="Ruscha">
    <button class="btn-sm" onclick="saveOnePosition('${type}',${i})">Saqlash</button>
    <button class="btn-sm" style="background:#fee2e2;color:#991b1b" onclick="deletePosition('${type}',${i})">🗑</button>
  </div>`;
  box.innerHTML=`
    <div class="position-edit-group">
      <h3>Direkt — ishchilar</h3>
      ${lists.direct.map((x,i)=>row(x,'direct',i)).join('')}
      <div class="position-edit-row" style="margin-top:8px;background:#f0fdf4;padding:8px;border-radius:8px">
        <input id="pos_new_direct_uz" placeholder="Yangi (o'zbekcha)">
        <input id="pos_new_direct_ru" placeholder="Yangi (ruscha)">
        <button class="btn-main btn-sm" onclick="addPosition('direct')">＋ Qo'shish</button>
      </div>
    </div>
    <div class="position-edit-group">
      <h3>Endirekt — STAFF</h3>
      ${lists.staff.map((x,i)=>row(x,'staff',i)).join('')}
      <div class="position-edit-row" style="margin-top:8px;background:#f0fdf4;padding:8px;border-radius:8px">
        <input id="pos_new_staff_uz" placeholder="Yangi (o'zbekcha)">
        <input id="pos_new_staff_ru" placeholder="Yangi (ruscha)">
        <button class="btn-main btn-sm" onclick="addPosition('staff')">＋ Qo'shish</button>
      </div>
    </div>
    <button class="btn-sec btn-sm" onclick="resetPositions()">Standart lavozimlarni tiklash</button>
    <p class="section-desc" style="margin-top:8px">Bir o'zbekcha lavozimga bir nechta ruscha variant qo'shishingiz mumkin (masalan: Ambar ishchisi → Кладовщик / Кладовщик-экспедитор).</p>`;
}
function saveOnePosition(type,i){
  const lists=getPositionLists(); const uz=document.getElementById(`pos_${type}_uz_${i}`)?.value.trim(), ru=document.getElementById(`pos_${type}_ru_${i}`)?.value.trim();
  if(!uz||!ru){alert("Ikkala lavozim nomini ham kiriting.");return;} lists[type][i]={uz,ru}; localStorage.setItem("flex_position_lists",JSON.stringify(lists)); renderPositionManager(); onTurChange(); toast("Lavozim saqlandi ✓");
}
function addPosition(type){
  const uz=document.getElementById(`pos_new_${type}_uz`)?.value.trim();
  const ru=document.getElementById(`pos_new_${type}_ru`)?.value.trim();
  if(!uz||!ru){alert("Ikkala maydonni to'ldiring");return;}
  const lists=getPositionLists();
  lists[type].push({uz,ru});
  localStorage.setItem("flex_position_lists",JSON.stringify(lists));
  renderPositionManager(); onTurChange(); toast("Lavozim qo'shildi ✓");
}
function deletePosition(type,i){
  const lists=getPositionLists();
  if(lists[type].length<=1){alert("Kamida 1 ta lavozim qolishi kerak");return;}
  if(!confirm(`"${lists[type][i].uz}" o'chirilsinmi?`))return;
  lists[type].splice(i,1);
  localStorage.setItem("flex_position_lists",JSON.stringify(lists));
  renderPositionManager(); onTurChange(); toast("O'chirildi ✓");
}
function resetPositions(){ if(!confirm("Standart lavozimlar tiklansinmi?"))return; localStorage.setItem("flex_position_lists",JSON.stringify(DEFAULT_POSITIONS)); renderPositionManager(); onTurChange(); toast("Standart lavozimlar tiklandi ✓");}

function resetForm() {
  editId = null;
  document.getElementById("workerForm")?.reset();
  const sic = document.getElementById("f_sicil"); if (sic) sic.value = "Yenigiris";
  if (typeof fillDavlatList === "function") fillDavlatList("");
  onTurChange();
  document.getElementById("formTitle").textContent = "Yangi ishchi qo'shish";
}

// ===== PATENT =====
function renderPatent() {
  const tbody = document.getElementById("patentBody");
  if (!tbody) return;
  let list = getWorkers().filter(w => !w.exited && isPatentCountry(w)).map(w => ({ w, days: patentDaysLeft(w) })).sort((a, b) => a.days - b.days);
  const filt = document.getElementById("patentFilter")?.value || "all";
  if (filt === "expiring") list = list.filter(x => x.days >= 0 && x.days < 30);
  else if (filt === "expired") list = list.filter(x => x.days < 0);
  else if (filt === "ok") list = list.filter(x => x.days >= 30);
  tbody.innerHTML = list.map(({ w, days }, i) => {
    const due = payDue(w), ed = expiryDays(w), pdays = payDays(w), last = (w.pays || []).slice(-1)[0];
    return `<tr>
      <td>${i+1}</td><td><b>${esc(w.fio)}</b></td>
      <td>${esc((w.doc_type ? w.doc_type + " " : "") + (w.patent || "")) || "—"}</td>
      <td>${w.patent_berilgan || "—"}</td><td>${w.patent_tugash || "—"}</td>
      <td>${ed < 900 ? ed : "—"}</td>
      <td>${due ? ymd(addDays(due, -2)) : "—"}</td>
      <td>${pdays < 900 ? pdays : "—"}</td>
      <td>${patentBadge(days)}</td>
      <td>${due ? `<input type="date" id="pdt_${w.id}" value="${todayStr()}"> <input type="checkbox" title="To'landi" style="width:20px;height:20px;vertical-align:middle" onchange="tickPaid('${w.id}')">` : "—"}</td>
      <td>${last ? `<input type="date" value="${last.paid}" onchange="editPaidDate('${w.id}',this.value)"> <button class="btn-sm" title="Bekor qilish" onclick="undoPaid('${w.id}')">↩</button>` : "—"}</td>
    </tr>`;
  }).join("") || `<tr><td colspan="11" style="text-align:center;color:#888;padding:20px">Ma'lumot yo'q</td></tr>`;
}

function tickPaid(id) {   // ✓ bosilganda: tanlangan sana bilan to'langan deb yoziladi, keyingi to'lov +30 kun
  const list = getWorkers(), w = list.find(x => x.id === id);
  if (!w) return;
  const d = payDue(w);
  if (!d) { alert("Ruxsatnoma berilgan sanasi yo'q yoki bu hujjat ruxsatnoma emas"); renderPatent(); return; }
  const paid = document.getElementById("pdt_" + id).value || todayStr();
  (w.pays = w.pays || []).push({ due: ymd(d), paid });
  w.paid_due = ymd(d); w.last_paid = paid;
  saveWorkers(list); renderPatent(); renderWorkers();
}
function editPaidDate(id, v) {   // to'langan sanani o'zgartirish (oldinroq to'langan bo'lsa)
  const list = getWorkers(), w = list.find(x => x.id === id);
  if (!w || !w.pays?.length || !v) return;
  w.pays[w.pays.length - 1].paid = v; w.last_paid = v;
  saveWorkers(list); renderPatent();
}
function undoPaid(id) {   // adashib bosilgan bo'lsa bekor qilish
  if (!confirm("Oxirgi to'lov bekor qilinsinmi?")) return;
  const list = getWorkers(), w = list.find(x => x.id === id);
  if (!w || !w.pays?.length) return;
  w.pays.pop();
  const l = w.pays[w.pays.length - 1];
  w.paid_due = l ? l.due : ""; w.last_paid = l ? l.paid : "";
  saveWorkers(list); renderPatent(); renderWorkers();
}

// ===== CHIQISH =====
function openExit(id) {
  const w = getWorkers().find(x => x.id === id);
  if (!w) return;
  exitWorkerId = id;
  document.getElementById("exitName").textContent = w.fio;
  document.getElementById("exitDate").value = todayStr();
  document.getElementById("exitReason").value = "XOHISH"; document.getElementById("exitNote").value = "";
  document.getElementById("exitModal").classList.remove("hidden");
}

function closeExitModal() {
  document.getElementById("exitModal").classList.add("hidden");
  exitWorkerId = null;
}

function confirmExit() {
  const list = getWorkers();
  const idx = list.findIndex(w => w.id === exitWorkerId);
  if (idx < 0) return;
  const w = list[idx];
  const exitDate = document.getElementById("exitDate").value;
  const rs = document.getElementById("exitReason").value, note = document.getElementById("exitNote").value.trim();
  if (rs === "IZIN") {
    const d = exitDate || todayStr(), p = getPuantaj(d);
    p[w.id] = { status:"IZINLI", hours:0, note: note || "Izinga ketdi" };
    savePuantajData(d, p); pushToBodro(d, { [w.id]: p[w.id] });
    closeExitModal(); renderPuantaj(); renderKunlikSon(); updateStats();
    alert(w.fio + " izinga yozildi (ro'yxatda qoladi)"); return;
  }
  const reason = (EXIT_REASONS[rs] || "Boshqa") + (note ? " — " + note : "");
  const blacklisted = rs === "QOCHDI" || rs === "HIRSIZLIK";

  // move to exits
  const exits = getExits();
  exits.push({ ...w, exitDate, reason, blacklisted, exitedAt: new Date().toISOString() });
  saveExits(exits);

  // mark as exited — exitDate dan keyin puantaj/bodro/GP dan chiqadi, tarix qoladi
  list[idx].exited = true;
  list[idx].exitDate = exitDate || todayStr();
  list[idx].exitReason = reason;
  saveWorkers(list);

  // chiqish kunida status CIKIS, soat 0
  const ed = list[idx].exitDate;
  try {
    const p = getPuantaj(ed);
    p[list[idx].id] = { status: "CIKIS", hours: 0, note: reason };
    savePuantajData(ed, p);
    if (typeof pushToBodro === "function") pushToBodro(ed, { [list[idx].id]: p[list[idx].id] });
  } catch (e) {}

  closeExitModal();
  renderWorkers();
  renderChiqishlar();
  if (typeof renderPuantaj === "function") renderPuantaj();
  if (typeof renderBodro === "function") renderBodro();
  if (typeof renderPatent === "function") renderPatent();
  if (typeof renderMalumot === "function") renderMalumot();
  updateStats();
  alert(w.fio + " chiqarildi — " + ed + " dan keyin faqat chiqish listida");
}

function renderChiqishlar() {
  const tbody = document.getElementById("chiqishBody");
  if (!tbody) return;
  tbody.innerHTML = getExits().map((w, i) => `
    <tr${w.blacklisted ? ' style="background:#fee2e2"' : ''}>
      <td>${i+1}</td><td><b>${esc(w.fio)}</b></td><td>${esc(w.sicil)}</td><td>${esc(w.lavozim)}</td><td>${esc(w.exitDate)}</td>
      <td>${w.blacklisted ? '<span class="badge badge-red">⛔ ' + esc(w.reason) + '</span>' : esc(w.reason)}</td>
      <td>${w.blacklisted ? '<b style="color:#991b1b">Qabul qilinmaydi</b>' : `<button class="btn-sm" onclick="rehire('${w.id}')">Qayta kirish</button>`}</td>
    </tr>`).join("") || `<tr><td colspan="7" style="text-align:center;color:#888;padding:20px">Chiqish qilganlar yo'q</td></tr>`;
}

function rehire(id) {
  const exits = getExits();
  const idx = exits.findIndex(w => w.id === id);
  if (idx < 0) return;
  const w = exits[idx];
  if (w.blacklisted) { alert("⛔ Bu ishchi qochib ketgan — qabul qilinmaydi"); return; }
  delete w.blacklisted; delete w.exitDate; delete w.reason; delete w.exitedAt;
  w.exited = false;
  w.id = "w_" + Date.now(); // yangi id

  const list = getWorkers();
  list.push(w);
  saveWorkers(list);

  exits.splice(idx, 1);
  saveExits(exits);

  renderChiqishlar();
  renderWorkers();
  updateStats();
  alert(w.fio + " qayta kiritildi");
}

// ===== KUNLIK ODAM SONI =====
function renderKunlikSon() {   // Kunlik adam sayisi — Excel'dagi jadval ko'rinishida
  const box = document.getElementById("kunlikSonContent");
  if (!box) return;
  const date = document.getElementById("sonDate")?.value || todayStr();
  const g = dayGroups(date), stOf = {};
  Object.keys(g).forEach(s => g[s].forEach(x => { stOf[x.w.id] = { s, r: x.r }; }));
  const fmt = d => d.split("-").reverse().join(".");
  const all = getWorkers().filter(w => !w.exited), direct = all.filter(w => !isStaff(w));
  const cats = [["OFIS", all.filter(isStaff)], ...["Mexanik","Xavolandirma","Ambar"].map(n => [n, direct.filter(w => brigadeGroup(w.ekip) === n)])];
  const sum = L => { const o = { tot: L.length, work: 0, YOK: [], IZINLI: [], FMS: [], HASTA: [] };
    L.forEach(w => { const x = stOf[w.id] || { s: "CALISAN", r: {} }; if (x.s === "CALISAN") o.work++; else { const k = x.s === "KASAL" ? "HASTA" : x.s; if(o[k]) o[k].push({ w, r: x.r }); else o.YOK.push({ w, r: x.r }); } }); return o; };
  const C = ["YOK","IZINLI","FMS","HASTA"];
  const td = "border:1px solid #000;padding:4px 8px;text-align:center;font-size:13px;";
  const names = l => l.map(({ w, r }) => esc(w.fio) + (r.note ? ` — <span style="color:#c00">${esc(r.note)}</span>` : "")).join("<br>");
  let rows = "";
  cats.forEach(([name, L]) => {
    const S = sum(L), D = sum(L.filter(w => w.vardiya !== "GECE")), N = sum(L.filter(w => w.vardiya === "GECE"));
    rows += `<tr style="font-weight:bold"><td style="${td}background:#ffc000">${name}</td><td style="${td}background:#ffc000">${S.tot}</td><td style="${td}background:#ffc000">${S.work}</td>${C.map(c => `<td style="${td}background:#c6e0b4">${S[c].length}</td>`).join("")}</tr>`;
    [["Gunduz", D, "#bdd7ee"], ["Gece " + fmt(ymd(addDays(pdate(date), -1))), N, "#fff"]].forEach(([lb, X, bg]) => {
      rows += `<tr><td style="${td}background:${bg}">${lb}</td><td style="${td}background:${bg};font-weight:bold">${X.tot}</td><td style="${td}background:${bg};font-weight:bold">${X.work}</td>${C.map(c => `<td style="${td}">${names(X[c])}</td>`).join("")}</tr>`;
    });
  });
  const objName = (OBJECTS.find(o => o.id === currentObj) || {}).name || "";
  const trs = JSON.parse(localStorage.getItem(key("transfers")) || "[]").filter(t => t.date === date);
  const pendingToday = JSON.parse(localStorage.getItem("flex_pending_transfers_v3") || "[]").filter(t => t.to === currentObj && t.status === "PENDING" && t.effectiveDate === date);
  if (trs.length || pendingToday.length) {
    const counts = {};
    pendingToday.forEach(t => { const src = OBJECTS.find(o => o.id === t.from); const k = src?.short || t.from; counts[k] = (counts[k] || 0) + 1; });
    const transferCells = pendingToday.length > 10
      ? Object.entries(counts).map(([src,n]) => `${esc(src)} → ${esc(objName)}: <b>${n} kishi</b>`).join("<br>")
      : pendingToday.map(t => `${esc(t.worker?.fio || "")} → <b>${esc(objName)}</b>`).join("<br>");
    rows += `<tr style="font-weight:bold"><td style="${td}background:#ffc000">TRANSFER</td><td style="${td}background:#ffc000">${trs.length + pendingToday.length}</td><td style="${td}background:#ffc000">0</td><td colspan="4" style="${td}text-align:left">${transferCells}</td></tr>`;
  }
  const dir = sum(direct), off = sum(all.filter(isStaff));
  const foot = [["Toplam sahada calisan { Direkt }", dir.work, "#000"], ["Ofis calisan", off.work, "#000"], ["Ise cikmayan { Direkt }", dir.tot - dir.work, "#000"], ["Toplam Direkt", dir.tot, "#c00"]];
  box.innerHTML = `<div class="table-scroll"><table style="border-collapse:collapse;width:100%;min-width:900px">
    <tr><td style="${td}background:#d9d9d9;font-weight:bold">Merhaba herkese!</td><td style="${td}background:#d9d9d9;font-weight:bold;font-size:16px">${fmt(date)}</td><td colspan="5" style="${td}background:#00b0f0;font-weight:bold;font-size:15px">FLEX GROUP - GUNLUK ADAM SAYISI ${objName}</td></tr>
    <tr>${["FLEX Group","Toplam","Sahada calisan","ISE GELMEYAN ↓","IZINLE ↓","FMS ↓","HASTA ↓"].map(h => `<td style="${td}font-weight:bold">${h}</td>`).join("")}</tr>${rows}</table>
    <table style="border-collapse:collapse;margin:16px auto 0;width:75%;min-width:700px"><tr>${foot.map(f => `<td style="${td}background:#ffff66;font-weight:bold">${f[0]}</td>`).join("")}</tr>
    <tr>${foot.map(f => `<td style="${td}background:#ffff66;font-weight:bold;font-size:22px;color:${f[2]}">${f[1]}</td>`).join("")}</tr></table></div>`;
}


// ===== Tezkor soatlar =====
function getDefaultHours(dateStr) {
  const d = new Date(dateStr + "T12:00:00");
  const day = d.getDay(); // 0=Yakshanba, 6=Shanba
  if (day === 0) return 16;      // Yakshanba
  if (day === 6) return 9.5;     // Shanba
  return 11;                     // Oddiy kun
}

function fillHours(hours) {
  const workers = getWorkers().filter(w => !w.exited);
  workers.forEach(w => {
    const el = document.getElementById("hr_" + w.id);
    if (el && !el.readOnly) el.value = hours;
  });
}

function setAllStatus(status) {
  const workers = getWorkers().filter(w => !w.exited);
  workers.forEach(w => {
    const el = document.getElementById("st_" + w.id);
    if (el) { el.value = status; statusChanged(w.id); }
  });
}

// ===== EXPORT (simple CSV → Excel ochiladi) =====
function exportExcel(type) {
  let rows = [];
  if (type === "patent") {
    rows = [["№","F.I.O","Hujjat","Ruxsatnoma №","Berilgan","Tugash","Tugashgacha (kun)","To'lov muddati (2 kun oldin)","To'lovgacha (kun)","Oxirgi to'lov sanasi"]];
    getWorkers().filter(w => !w.exited && isPatentCountry(w)).map(w => ({ w, days: patentDaysLeft(w) })).sort((a, b) => a.days - b.days).forEach(({ w }, i) => {
      const due = payDue(w), ed = expiryDays(w), pdays = payDays(w);
      rows.push([i+1, w.fio, w.doc_type || "", w.patent || "", w.patent_berilgan || "", w.patent_tugash || "", ed < 900 ? ed : "", due ? ymd(addDays(due, -2)) : "", pdays < 900 ? pdays : "", w.last_paid || ""]);
    });
  } else if (type === "ishchilar") {
    const list = getWorkers().filter(w => !w.exited);
    rows = [["№","F.I.O","Sicil","Lavozim","Ekip","Vardiya","Pasport","INN","SNILS","Ruxsatnoma","Ruxsatnoma tugash"]];
    list.forEach((w,i) => rows.push([i+1, w.fio, w.sicil, w.lavozim, w.ekip, w.vardiya, w.pasport, w.inn, w.snils, w.patent, w.patent_tugash]));
  } else if (type === "chiqishlar") {
    const list = getExits();
    rows = [["№","F.I.O","Sicil","Lavozim","Chiqish sanasi","Sababi"]];
    list.forEach((w,i) => rows.push([i+1, w.fio, w.sicil, w.lavozim, w.exitDate, w.reason]));
  } else if (type === "kunlik") {
    const date = document.getElementById("puantajDate")?.value || "";
    const list = getWorkers().filter(w => !w.exited);
    const saved = getPuantaj(date);
    rows = [["№","Ekip","Sicil","F.I.O","Lavozim","Vardiya","Durum","Soat","Izoh"]];
    list.forEach((w,i) => {
      const r = saved[w.id] || {};
      rows.push([i+1, w.ekip, w.sicil, w.fio, w.lavozim, w.vardiya, r.status||"", r.hours||"", r.note||""]);
    });
  } else if (type === "bodro" || type === "bodro_staff") {
    const month = document.getElementById("bodroMonth").value, dim = new Date(+month.slice(0,4), +month.slice(5,7), 0).getDate();
    const b = JSON.parse(localStorage.getItem(key("bodro_" + month)) || "{}");
    rows = [["№","F.I.O","Sicil","Lavozim","Ekip", ...Array.from({length: dim}, (_, i) => i + 1), "Jami"]];
    getWorkers().filter(w => !w.exited && isStaff(w) === (type === "bodro_staff")).forEach((w, i) => {
      const d = b[w.id] || {}; let t = 0; const c = [];
      for (let k = 1; k <= dim; k++) { const v = d[k] ?? ""; c.push(v === "" ? "" : (isNaN(+v) ? v : +v)); t += parseFloat(v) || 0; }
      rows.push([i+1, w.fio, w.sicil, w.lavozim, w.ekip, ...c, t]);
    });
  } else if (type === "malumot") {
    rows = [["№","F.I.O","Sicil","Tug'ilgan sana","Pasport","INN","SNILS","Hujjat","Ruxsatnoma","Berilgan","Tugash"]];
    getWorkers().filter(w => !w.exited).forEach((w, i) => rows.push([i+1, w.fio, w.sicil, w.tugilgan || "", w.pasport || "", w.inn || "", w.snils || "", w.doc_type || "", w.patent || "", w.patent_berilgan || "", w.patent_tugash || ""]));
  } else if (type === "kunlik_son") {
    const g = dayGroups(document.getElementById("sonDate").value || todayStr());
    rows = [["Holat","F.I.O","Sicil","Lavozim","Ekip","Izoh"]];
    Object.keys(g).forEach(s => g[s].forEach(({w, r}) => rows.push([s, w.fio, w.sicil, w.lavozim, w.ekip, r.note || ""])));
  } else { return; }
  if (window.XLSX) {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), "Sheet1");
    XLSX.writeFile(wb, `${currentObj}_${type}_${todayStr()}.xlsx`);
    return;
  }

  const csv = rows.map(r => r.map(c => `"${(c||"").toString().replace(/"/g,'""')}"`).join(";")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${currentObj}_${type}_${todayStr()}.csv`;
  a.click();
}

// ===== LANG (placeholder) =====
function changeLang(lang) { localStorage.setItem("lang", lang); applyLang(); }


// ===== YANGI: yordamchi funksiyalar =====
const LOCK = { IZINLI: 0, YOK: 0, HASTA: 8, KASAL: 8, FMS: 8, CIKIS: 0 };   // CIKIS/YOK/IZINLI=0 qulf; HASTA/FMS=8 qulf
const EXIT_REASONS = {
  XOHISH: "Kendi istegі ile / O'z xohishi bilan",
  IZIN: "Izinga ketdi",
  QOCHDI: "Kacti / Qochib ketdi",
  EVRAK: "Evrak sikintisi (kayb etdi)",
  FORMEN: "Formeni terfinden cikis",
  HASTALIK: "Hastaligi dolayi cikis",
  HASTALIK_ISTIFA: "Hastaligi dolayi istifa",
  HIRSIZLIK: "Hirsizlik dolayi cikis",
  IS_BITIMI: "Is bitimi",
  DISIPLIN: "Is disipsizligi formeni terfinden cikis",
  GUVENLIK: "Is guvenligi terfinden cikis",
  ISTIFA_OILE: "Istifa (Ozel - Ailevi Sebepler)",
  UCRET: "Kendi istegі ile (Ucret dusuk oldiyi icin)",
  SAGLIK: "Saglik problemi",
  EV: "Ev problemleri yuzinden cikis",
  BOSHATILDI: "Ishdan bo'shatildi",
  BOSHQA: "Boshqa"
};
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function ymd(d) { return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0"); }
function todayStr() { return ymd(new Date()); }

function statusChanged(id) {
  const sel = document.getElementById("st_" + id);
  if (sel.value.startsWith("TR_")) { transferFlow(id); return; }
  sel.dataset.prev = sel.value;
  const w = getWorkers().find(x => x.id === id), hr = document.getElementById("hr_" + id), lk = lockHours(w, sel.value);
  if (lk !== undefined) { hr.value = lk; hr.readOnly = true; }
  else { hr.readOnly = false; hr.value = getDefaultHours(document.getElementById("puantajDate").value); }
}

function dayGroups(date) {
  const p = getPuantaj(date), g = { CALISAN:[], HASTA:[], KASAL:[], IZINLI:[], FMS:[], YOK:[], CIKIS:[] };
  getWorkers().filter(w => !w.exited).forEach(w => {
    const r = p[w.id] || { status:"CALISAN" };
    let st = r.status === "KASAL" ? "HASTA" : r.status;
    (g[st] || g.CALISAN).push({ w, r });
  });
  return g;
}

function activeWorkers(dateStr) {
  return getWorkers().filter(w => isActiveOn(w, dateStr || todayStr()));
}
function isActiveOn(w, dateStr) {
  if (!w) return false;
  if (!w.exited) return true;
  // chiqish kunigacha (shu kun bilan) ko'rinishi mumkin — keyin yo'q
  if (w.exitDate && dateStr && w.exitDate > dateStr) return true;
  return false;
}
function isBlacklisted(d) {
  const n = s => (s || "").toLowerCase().replace(/\s+/g, " ").trim();
  return OBJECTS.some(o => JSON.parse(localStorage.getItem("exits_" + o.id) || "[]").some(e => e.blacklisted &&
    ((d.pasport && n(e.pasport) === n(d.pasport)) || (d.inn && e.inn === d.inn) || n(e.fio) === n(d.fio))));
}

// ===== Trudovoy dogovor (fayllar IndexedDB'da) =====
let dogTarget = null;
const dogKey = id => currentObj + "_" + id;
function fileOp(mode, fn) {
  return new Promise((res, rej) => {
    const r = indexedDB.open("flex_files", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("f");
    r.onerror = () => rej(r.error);
    r.onsuccess = () => {
      const q = fn(r.result.transaction("f", mode).objectStore("f"));
      q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error);
    };
  });
}
async function renderDogovor() {
  const tbody = document.getElementById("dogovorBody");
  if (!tbody) return;
  const q = (document.getElementById("searchDogovor")?.value || "").toLowerCase();
  const keys = await fileOp("readonly", s => s.getAllKeys());
  const list = getWorkers().filter(w => !w.exited && ((w.fio || "").toLowerCase().includes(q) || (w.sicil || "").includes(q)));
  tbody.innerHTML = list.map((w, i) => {
    const has = keys.includes(dogKey(w.id));
    return `<tr><td>${i+1}</td><td><b>${esc(w.fio)}</b></td><td>${esc(w.sicil)}</td><td>${esc(w.ekip)}</td>
      <td>${has ? '<span class="badge badge-green">Yuklangan</span>' : '<span class="badge badge-red">Yo\'q</span>'}</td>
      <td><button class="btn-sm" onclick="pickDogovor('${w.id}')">${has ? "Almashtirish" : "Yuklash"}</button>
      ${has ? `<button class="btn-sm" onclick="openDogovor('${w.id}')">Ochish</button> <button class="btn-sm" style="background:#fee2e2;color:#991b1b" onclick="delDogovor('${w.id}')">O'chirish</button>` : ""}</td></tr>`;
  }).join("") || `<tr><td colspan="6" style="text-align:center;color:#888;padding:20px">Ishchilar yo'q</td></tr>`;
}
function pickDogovor(id) { dogTarget = id; const f = document.getElementById("dogFile"); f.value = ""; f.click(); }
async function uploadDogovor(inp) {
  const f = inp.files[0];
  if (!f || !dogTarget) return;
  if (!/\.(pdf|docx?)$/i.test(f.name)) { alert("Faqat Word (.doc, .docx) yoki PDF yuklang"); return; }
  await fileOp("readwrite", s => s.put({ name: f.name, blob: f }, dogKey(dogTarget)));
  renderDogovor();
}
async function openDogovor(id) {
  const r = await fileOp("readonly", s => s.get(dogKey(id)));
  if (!r) return;
  const url = URL.createObjectURL(r.blob);
  if (/\.pdf$/i.test(r.name)) window.open(url, "_blank");
  else { const a = document.createElement("a"); a.href = url; a.download = r.name; a.click(); }
}
async function delDogovor(id) {
  if (!confirm("Dogovor fayli o'chirilsinmi?")) return;
  await fileOp("readwrite", s => s.delete(dogKey(id)));
  renderDogovor();
}

const isStaff = w => w.tur === "ENDIREKT" || w.ekip === "STAFF" || w.vardiya === "STAFF";
// Staff: ishda = 8 (qulf), boshqa hamma holat = 0 (qulf). Ishchilar: KASAL/FMS = 8, IZINLI/YOK = 0, CALISAN = erkin
function lockHours(w, st) {
  if (isStaff(w)) return st === "CALISAN" ? 8 : 0;
  if (st === "CALISAN" && missingData(w).length) return 8;   // INN / SNILS / ruxsatnoma to'liq emas: soat 8 da qotadi
  return LOCK[st];
}
const pdate = s => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const today0 = () => { const t = new Date(); t.setHours(0,0,0,0); return t; };

// ===== Brigada / lavozim / forma =====
const DEFAULT_BR = [
  { name:"AMBAR", group:"Ambar", leader:"" },
  { name:"XAVOLANDIRMA", group:"Xavolandirma", leader:"" },
  { name:"MEXANIK", group:"Mexanik", leader:"" }
];
const DEFAULT_POSITIONS = {
  direct: [
    { uz:"Ambar ishchisi", ru:"Кладовщик" },
    { uz:"Xavolandirmachi", ru:"МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА" },
    { uz:"Mexanik montajchi", ru:"МОНТАЖНИК ТРУБ" }
  ],
  staff: [
    { uz:"Mexanik brigadiri", ru:"БРИГАДИР ПО МЕХАНИЧЕСКИМ РАБОТАМ (Э&М)" },
    { uz:"Xavolandirma brigadiri", ru:"БРИГАДИР ПО ВЕНТИЛЯЦИОННЫМ РАБОТАМ" },
    { uz:"Ambar sefi", ru:"ЗАВЕДУЮЩИЙ СКЛАДОМ (НАЧАЛЬНИК СКЛАДА)" }
  ]
};
function getPositionLists(){
  const raw=JSON.parse(localStorage.getItem("flex_position_lists")||"null");
  const base=raw&&Array.isArray(raw.direct)&&Array.isArray(raw.staff)?raw:JSON.parse(JSON.stringify(DEFAULT_POSITIONS));
  // Barcha mavjud STAFF lavozimlarini ham ro'yxatga qo'shamiz.
  const workers=getWorkers();
  const seen=new Set(base.staff.map(x=>String(x.uz||"").toLowerCase()));
  workers.filter(w=>isStaff(w)).forEach(w=>{
    const uz=String(w.lavozim||"").trim(), ru=String(w.dolzhnost||"").trim();
    if(uz && !seen.has(uz.toLowerCase())){ base.staff.push({uz,ru:ru||uz}); seen.add(uz.toLowerCase()); }
  });
  if(typeof PERSON_DB!=="undefined") PERSON_DB.forEach(x=>{
    const ru=String(x.dolzhnost||"").trim();
    if(!ru) return;
    if(/бригадир|начальник|заведующ|директор|инженер|руковод|мастер|прораб|менеджер/i.test(ru)){
      const uz=ru;
      if(!seen.has(uz.toLowerCase())){ base.staff.push({uz,ru}); seen.add(uz.toLowerCase()); }
    }
  });
  localStorage.setItem("flex_position_lists",JSON.stringify(base));
  return base;
}
const GROUP_POS_UZ = { Ambar:"Ambar ishchisi", Xavolandirma:"Xavolandirmachi", Mexanik:"Mexanik montajchi" };
const GROUP_POS_RU = { Ambar:"Кладовщик", Xavolandirma:"МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА", Mexanik:"МОНТАЖНИК ТРУБ" };
const STAFF_POS_UZ = DEFAULT_POSITIONS.staff.map(x=>x.uz);
const STAFF_POS_RU = DEFAULT_POSITIONS.staff.map(x=>x.ru);
const DIRECT_POS = DEFAULT_POSITIONS.direct.map(x=>x.uz);
const isPatentCountry = w => {
  const dt = (w.doc_type || "").toLowerCase();
  if (/патент|ожидание/i.test(dt)) return true;
  if (typeof getDocKind === "function" && getDocKind(w) === "patent") return true;
  return /узбек|таджик|азербайджан|uzbek|tajik|o'zbek|tojik|azerbayjan/i.test(w.millat || "");
};
function getBrigades() {
  const raw = JSON.parse(localStorage.getItem(key("brigades") || "null") || "null");
  const old = Array.isArray(raw) ? raw : [];
  const b = DEFAULT_BR.map(x => ({...x}));
  // Custom brigadalar saqlanib qoladi. Ularning group'i xodimning mos lavozimini belgilaydi.
  old.filter(x=>!DEFAULT_BR.some(d=>d.name===x.name)).forEach(x=>{
    if(x && x.name) b.push({name:String(x.name), group:x.group||"Mexanik", leader:x.leader||"", custom:true});
  });
  old.forEach(x => {
    const idx = b.findIndex(n => n.name === x.name);
    if (idx >= 0 && x.leader) {
      const leader = getWorkers().find(w => !w.exited && isStaff(w) && (normFio(w.fio) === normFio(x.leader) || w.fio === x.leader));
      if (leader) b[idx].leader = leader.fio;
    }
  });
  // Eski ma'lumotlarni asosiy 3 brigadaga moslashtirish, custom brigadalarga tegmaslik.
  const direct=getWorkers(); let changed=false;
  direct.forEach(w=>{
    if(isStaff(w)){
      if(w.ekip!=="STAFF"){w.ekip="STAFF";changed=true;}
      return;
    }
    const p=String(w.lavozim||"")+" "+String(w.dolzhnost||"");
    let target="";
    if(/вентиляц|кондиционир/i.test(p)) target="XAVOLANDIRMA";
    else if(/монтажник труб|\bтруб/i.test(p)) target="MEXANIK";
    else if(/кладов|склад/i.test(p)) target="AMBAR";
    else if(!b.some(x=>x.name===w.ekip)) target=brigadeGroup(w.ekip);
    if(target && !b.some(x=>x.name===w.ekip) && w.ekip!==target){w.ekip=target;changed=true;}
  });
  if(changed) saveWorkers(direct);
  localStorage.setItem(key("brigades"), JSON.stringify(b));
  return b;
}
function brigadeGroup(name) {
  const all = DEFAULT_BR.concat(JSON.parse(localStorage.getItem(key("brigades")||"[]")||"[]").filter(x=>x&&x.name));
  const x = all.find(x => x.name === name);
  return x ? (x.group || "Mexanik") : "Mexanik";
}
function onMillatChange() {
  const d = document.getElementById("f_davlat")?.value || document.getElementById("f_millat")?.value || "";
  onMillatChangeFromCountry(d);
}

function onDocTypeChange() {
  const dt = (document.getElementById("f_doc_type")?.value || "").toLowerCase();
  const patentFields = ["f_patent","f_patent_berilgan","f_patent_tugash"].map(id => document.getElementById(id)?.closest(".form-group")).filter(Boolean);
  const needPermit = /патент|рнр|вкс|внж|рвп|разрешение|ожидание/i.test(dt);
  const isRf = /рф|гражданство рф/i.test(dt);
  patentFields.forEach(el => { if (el) el.style.display = (needPermit && !isRf) ? "" : "none"; });
  // labels
  const isPatent = /патент|ожидание/i.test(dt);
  document.querySelectorAll("#sec-qoshish label").forEach(lb => {
    if (/Ruxsatnoma seriya|Patent seriya|Ish ruxsat|РНР seriya/i.test(lb.textContent) || lb.htmlFor === "f_patent") {
      lb.textContent = isPatent ? "Patent seriya + raqam" : "Ruxsatnoma / РНР seriya + raqam";
    }
  });
  const divs = document.querySelectorAll("#sec-qoshish .form-divider");
  divs.forEach(d => {
    if (/Ruxsatnoma|Patent|Ish ruxsat/i.test(d.textContent)) {
      d.textContent = isPatent ? "Patent ma'lumotlari" : "Ruxsatnoma / РНР ma'lumotlari";
      d.style.display = (needPermit && !isRf) ? "" : "none";
    }
  });
}
function onLavozimPick() {
  const sel = document.getElementById("f_lavozim");
  const hid = document.getElementById("f_dolzhnost");
  if (sel && hid) hid.value = sel.value;
}

function onTurChange() {

  const tur = document.getElementById("f_tur")?.value;
  if (!tur) return;
  const staff = tur === "ENDIREKT";
  const sel = document.getElementById("f_ekip"), cur = sel.value;
  document.getElementById("g_ekip").style.display = staff ? "none" : "";
  sel.innerHTML = staff ? '<option value="STAFF">STAFF (Ofis)</option>' :
    getBrigades().map(b => {
      const lab = b.leader ? `${b.name} — ${b.leader}` : b.name;
      return `<option value="${esc(b.name)}">${esc(lab)}</option>`;
    }).join("");
  if (cur && [...sel.options].some(o => o.value === cur)) sel.value = cur;
  const lists = getPositionLists();
  const pos = staff ? lists.staff.map(x=>x.uz) : lists.direct.map(x=>x.uz);
  const lavSel = document.getElementById("f_lavozim");
  if (lavSel && lavSel.tagName === "SELECT") {
    const cur = lavSel.value;
    const lists2 = getPositionLists();
    const arr = staff ? lists2.staff : lists2.direct;
    lavSel.innerHTML = '<option value="">— Tanlang —</option>' + arr.map(x => `<option value="${esc(x.ru)}">${esc(x.ru)}</option>`).join("");
    if (cur) lavSel.value = cur;
  }
  const rus = document.getElementById("f_dolzhnostList");
  if (rus) rus.innerHTML = (staff ? lists.staff : lists.direct).map(x=>`<option value="${esc(x.ru)}">`).join("");
  const lv = document.getElementById("f_lavozim");
  if (!lv.value) lv.value = staff ? STAFF_POS_UZ[0] : GROUP_POS_UZ[brigadeGroup(sel.value)];
  const rv = document.getElementById("f_dolzhnost");
  if (rv && !rv.value) rv.value = staff ? STAFF_POS_RU[0] : GROUP_POS_RU[brigadeGroup(sel.value)];
}
function onEkipChange() {
  const sel = document.getElementById("f_ekip");
  if (!sel) return;
  const lv = document.getElementById("f_lavozim"), rv = document.getElementById("f_dolzhnost");
  if (lv && !lv.value) lv.value = GROUP_POS_UZ[brigadeGroup(sel.value)] || GROUP_POS_UZ.Mexanik;
  if (rv && !rv.value) rv.value = GROUP_POS_RU[brigadeGroup(sel.value)] || GROUP_POS_RU.Mexanik;
}
function migrateWorkers() {   // eski yozuvlar: STAFF smena emas, tur
  const list = getWorkers(), seed = typeof JOIS_SEED !== "undefined" ? JOIS_SEED : [];
  let ch = false;
  list.forEach(w => {
    if (w.tur) return;
    ch = true;
    w.tur = (w.ekip === "STAFF" || w.vardiya === "STAFF") ? "ENDIREKT" : "DIREKT";
    if (w.vardiya === "STAFF") { const s = seed.find(x => normFio(x.fio) === normFio(w.fio)); w.vardiya = s ? s.vardiya : "GUNDUZ"; w.ekip = w.ekip || "STAFF"; }
  });
  if (ch) saveWorkers(list);
}

// ===== Til: uz / ru / tr / en =====
const I18N_RAW = `Personel Tizimi|Система персонала|Personel Sistemi|Personnel System
Ishchilar boshqaruvi|Управление рабочими|İşçi yönetimi|Workforce management
Email|Эл. почта|E-posta|Email
Parol|Пароль|Şifre|Password
Parolni kiriting|Введите пароль|Şifreyi girin|Enter password
Kirish|Войти|Giriş|Sign in
Demo parol:|Демо-пароль:|Demo şifre:|Demo password:
Email yoki parol noto'g'ri|Неверная почта или пароль|E-posta veya şifre hatalı|Wrong email or password
Obyektlar|Объекты|Şantiyeler|Sites
Boshqarish uchun obyektni tanlang|Выберите объект для управления|Yönetmek için şantiye seçin|Select a site to manage
Chiqish|Выход|Çıkış|Log out
Statistika|Статистика|İstatistik|Statistics
Kunlik puantaj|Дневной табель|Günlük puantaj|Daily timesheet
Oylik bodro|Месячная ведомость|Aylık bordro|Monthly payroll sheet
Ishchi ro'yxati|Список рабочих|İşçi listesi|Worker list
Ishchi qo'shish|Добавить рабочего|İşçi ekle|Add worker
Ruxsatnoma cheklari|Контроль разрешений|İzin takibi|Permit checks
Trudovoy dogovor|Трудовой договор|İş sözleşmesi|Employment contract
Kunlik odam soni|Численность за день|Günlük adam sayısı|Daily headcount
Chiqish qilganlar|Уволенные|Çıkış yapanlar|Departed workers
Kunduzgi ishchilar|Дневные рабочие|Gündüz işçileri|Day workers
Kechadagi ishchilar|Ночные рабочие|Gece işçileri|Night workers
Ofis (Staff)|Офис (Staff)|Ofis (Staff)|Office (Staff)
Jami|Всего|Toplam|Total
Ishda (bugun)|На работе (сегодня)|Çalışan (bugün)|Working (today)
Kasal|Больные|Hasta|Sick
Izinli|В отпуске|İzinli|On leave
Kelmagan|Не вышли|Gelmeyen|Absent
Excel yuklash|Скачать Excel|Excel indir|Download Excel
Tezkor soat:|Быстрые часы:|Hızlı saat:|Quick hours:
Ekip|Бригада|Ekip|Team
Sicil №|Табельный №|Sicil №|Reg. №
F.I.O|Ф.И.О|Ad Soyad|Full name
Lavozim|Должность|Görev|Position
Vardiya|Смена|Vardiya|Shift
Durum|Статус|Durum|Status
Soat|Часы|Saat|Hours
Izoh|Примечание|Açıklama|Note
Saqlash|Сохранить|Kaydet|Save
Ishchilar yo'q|Рабочих нет|İşçi yok|No workers
Excel — Ishchilar|Excel — Рабочие|Excel — İşçiler|Excel — Workers
Staff (Ofis) — alohida hisob|Staff (офис) — отдельный учёт|Staff (Ofis) — ayrı hesap|Staff (office) — separate accounting
Ishchilar|Рабочие|İşçiler|Workers
Sicil|Таб. №|Sicil|Reg. №
Ma'lumot yo'q|Нет данных|Veri yok|No data
Qidirish...|Поиск...|Ara...|Search...
Pasport|Паспорт|Pasaport|Passport
Ruxsatnoma tugashi|Окончание разрешения|İzin bitişi|Permit expiry
Holat|Состояние|Durum|State
Ishlayapti|Работает|Çalışıyor|Working
Tahrir|Изменить|Düzenle|Edit
Chiqarish|Уволить|Çıkar|Remove
Yangi ishchi qo'shish|Добавить нового рабочего|Yeni işçi ekle|Add new worker
Ishchini tahrirlash|Редактирование рабочего|İşçiyi düzenle|Edit worker
F.I.O * (ism familya)|Ф.И.О * (имя и фамилия)|Ad Soyad *|Full name *
Turi *|Тип *|Tür *|Type *
Direkt (ishchi)|Прямой (рабочий)|Direkt (işçi)|Direct (worker)
Endirekt (Staff / ofis)|Косвенный (Staff / офис)|Endirekt (Staff / ofis)|Indirect (Staff / office)
Brigada *|Бригада *|Ekip / Brigada *|Brigade *
Smena *|Смена *|Vardiya *|Shift *
Kunduz|День|Gündüz|Day
Kecha|Ночь|Gece|Night
Millat|Национальность|Uyruk|Nationality
Yangi brigada qo'shish…|Добавить новую бригаду…|Yeni ekip ekle…|Add new brigade…
Pasport ma'lumotlari|Паспортные данные|Pasaport bilgileri|Passport details
Pasport seriya + raqam|Серия и номер паспорта|Pasaport seri + no|Passport series + number
Pasport berilgan sana|Дата выдачи паспорта|Pasaport veriliş tarihi|Passport issue date
Pasport tugash sanasi|Срок действия паспорта|Pasaport bitiş tarihi|Passport expiry date
Ruxsatnoma ma'lumotlari|Данные разрешения|İzin bilgileri|Permit details
Ruxsatnoma seriya + raqam|Серия и номер разрешения|İzin seri + no|Permit series + number
Ruxsatnoma berilgan sana|Дата выдачи разрешения|İzin veriliş tarihi|Permit issue date
Ruxsatnoma tugash sanasi|Дата окончания разрешения|İzin bitiş tarihi|Permit expiry date
Tozalash|Очистить|Temizle|Clear
kun|дн.|gün|days
Berilgan|Выдан|Veriliş|Issued
Tugash|Окончание|Bitiş|Expiry
Tugashgacha (kun)|До окончания (дн.)|Bitişe kalan (gün)|Days to expiry
To'lov muddati (2 kun oldin)|Срок оплаты (за 2 дня)|Ödeme son günü (2 gün önce)|Payment deadline (2 days before)
To'lovgacha (kun)|До оплаты (дн.)|Ödemeye kalan (gün)|Days to payment
To'landi (sana + ✓)|Оплачено (дата + ✓)|Ödendi (tarih + ✓)|Paid (date + ✓)
Oxirgi to'lov|Последняя оплата|Son ödeme|Last payment
Fayl|Файл|Dosya|File
Yuklangan|Загружен|Yüklendi|Uploaded
Yo'q|Нет|Yok|None
Yuklash|Загрузить|Yükle|Upload
Almashtirish|Заменить|Değiştir|Replace
Ochish|Открыть|Aç|Open
O'chirish|Удалить|Sil|Delete
Chiqish sanasi|Дата увольнения|Çıkış tarihi|Exit date
Sababi|Причина|Sebep|Reason
Qayta kirish|Принять снова|Yeniden giriş|Rehire
Qabul qilinmaydi|Не принимается|Kabul edilmez|Not accepted
Chiqish qilganlar yo'q|Уволенных нет|Çıkış yapan yok|No departed workers
Ishchini chiqarish|Увольнение рабочего|İşçiyi çıkar|Remove worker
Bekor|Отмена|İptal|Cancel
O'z xohishi bilan|По собственному желанию|Kendi isteğiyle|Voluntarily
Izinga ketdi (ro'yxatdan chiqarilmaydi)|Ушёл в отпуск (остаётся в списке)|İzne çıktı (listeden çıkarılmaz)|On leave (stays on list)
Qochib ketdi (qora ro'yxat)|Сбежал (чёрный список)|Kaçtı (kara liste)|Absconded (blacklist)
Qochib ketdi|Сбежал|Kaçtı|Absconded
Ishdan bo'shatildi|Уволен|İşten çıkarıldı|Dismissed
Boshqa|Другое|Diğer|Other
Izoh (ixtiyoriy)|Примечание (необязательно)|Açıklama (isteğe bağlı)|Note (optional)
Sozlamalar|Настройки|Ayarlar|Settings
Parolni unutdingizmi?|Забыли пароль?|Şifrenizi mi unuttunuz?|Forgot password?
Login|Логин|Kullanıcı adı|Login
Tiklash|Восстановить|Sıfırla|Reset
Tiklash kodi|Код восстановления|Kurtarma kodu|Recovery code
Yangi parol|Новый пароль|Yeni şifre|New password
Hisob|Аккаунт|Hesap|Account
Login yoki parol noto'g'ri|Неверный логин или пароль|Kullanıcı adı veya şifre hatalı|Wrong login or password
Barcha ishchilar (Flex)|Все рабочие (Flex)|Tüm işçiler (Flex)|All workers (Flex)
Obyekt|Объект|Şantiye|Site
Hammasi|Все|Hepsi|All
Ishchi ma'lumoti|Данные рабочего|İşçi bilgisi|Worker data
Garantiyniy pismo|Гарантийное письмо|Garanti mektubu|Guarantee letter
Bazadan to'ldirish|Заполнить из базы|Veritabanından doldur|Fill from database
Word yuklab olish (.docx)|Скачать Word (.docx)|Word indir (.docx)|Download Word (.docx)
Sana|Дата|Tarih|Date
Tug'ilgan sana|Дата рождения|Doğum tarihi|Date of birth
Yopish|Закрыть|Kapat|Close
Obyektda ochish|Открыть в объекте|Şantiyede aç|Open in site
Faqat to'liq emaslar|Только неполные|Sadece eksikler|Incomplete only
Fuqarolik|Гражданство|Uyruk|Citizenship
Pasport / ruxsatnoma|Паспорт / разрешение|Pasaport / izin|Passport / permit
Keyingi to'lov|Следующая оплата|Sonraki ödeme|Next payment
Saqlandi ✓|Сохранено ✓|Kaydedildi ✓|Saved ✓
Ishchilar|Рабочие|İşçiler|Workers
Kunlik puantaj|Ежедневный табель|Günlük puantaj|Daily timesheet
Oylik bodro|Месячный расчёт|Aylık bordro|Monthly payroll
Ishchi qo'shish|Добавить рабочего|İşçi ekle|Add worker
Patent cheklari|Чеки патента|Patent çekleri|Patent payments
Trudovoy dogovor|Трудовой договор|İş sözleşmesi|Employment contract
Brigadalar|Бригады|Ekipler|Brigades
Lavozimlar|Должности|Pozisyonlar|Positions
Transferlar|Трансферы|Transferler|Transfers
Kunlik odam soni|Ежедневная численность|Günlük kişi sayısı|Daily headcount
Yoqlama qog'ozi|Лист явки|Yoklama kağıdı|Attendance sheet
Kirish/Chiqish formasi|Форма входа/выхода|Giriş/Çıkış formu|Entry/Exit form
Chiqish listi|Список уволенных|Çıkış listesi|Exit list
Davlat|Страна|Ülke|Country
Кем выдан паспорт|Кем выдан паспорт|Pasaportu veren|Passport issued by
Sicil №|Таб. №|Sicil No|Badge No
Smena|Смена|Vardiya|Shift
Kunduz|День|Gündüz|Day
Kecha|Ночь|Gece|Night
Brigada|Бригада|Ekip|Brigade
Lavozim|Должность|Pozisyon|Position
Ish hujjati|Рабочий документ|Çalışma belgesi|Work document
Hujjat raqami|Номер документа|Belge no|Document no
Berilgan|Выдан|Veriliş|Issued
Tugash|Истекает|Bitiş|Expires
Holat|Статус|Durum|Status
Saqlash|Сохранить|Kaydet|Save
Tahrirlash|Редактировать|Düzenle|Edit
Excel yuklash|Скачать Excel|Excel indir|Download Excel
Soat kartochkalari|Карточки часов|Saat kartları|Hour cards
Yangi odam|Новый человек|Yeni kişi|New person
Pasport|Паспорт|Pasaport|Passport
INN|ИНН|INN|INN
SNILS|СНИЛС|SNILS|SNILS
Ожидание патент|Ожидание патент|Patent bekleniyor|Awaiting patent
Patent|Патент|Patent|Patent
`;
const I18N = { ru:{}, tr:{}, en:{} };
I18N_RAW.trim().split("\n").forEach(l => { const [u, r, t, e] = l.split("|"); I18N.ru[u] = r; I18N.tr[u] = t; I18N.en[u] = e; });
let _tr = false, _obs = null;
function trText(s, L) {
  if (!s || L === "uz") return s;
  // exact
  if (I18N[L]?.[s]) return I18N[L][s];
  // emoji / punctuation prefix
  const m = s.match(/^([^\p{L}]*)(.*?)(\s*)$/su);
  if (m && m[2] && I18N[L]?.[m[2]]) return m[1] + I18N[L][m[2]] + m[3];
  // partial: translate longest key contained
  let out = s;
  const keys = Object.keys(I18N[L] || {}).sort((a,b) => b.length - a.length);
  for (const k of keys) {
    if (k.length < 3) continue;
    if (out.includes(k)) out = out.split(k).join(I18N[L][k]);
  }
  return out;
}
function applyLang() {
  const L = localStorage.getItem("lang") || "uz";
  if (L === "uz" && !_tr) return;
  _obs?.disconnect();
  const wk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  for (let n; (n = wk.nextNode());) {
    if (/^(SCRIPT|STYLE)$/.test(n.parentNode.nodeName)) continue;
    if (n.__t !== n.nodeValue) n.__o = n.nodeValue;
    const out = L === "uz" ? n.__o : trText(n.__o, L);
    if (out !== n.nodeValue) { n.nodeValue = out; _tr = true; }
    n.__t = out;
  }
  document.querySelectorAll("[placeholder],[title]").forEach(el => ["placeholder", "title"].forEach(a => {
    const v = el.getAttribute(a);
    if (v === null) return;
    if (el.dataset["o_" + a] === undefined || el.dataset["t_" + a] !== v) el.dataset["o_" + a] = v;
    const out = L === "uz" ? el.dataset["o_" + a] : trText(el.dataset["o_" + a], L);
    if (out !== v) el.setAttribute(a, out);
    el.dataset["t_" + a] = out;
  }));
  _obs?.observe(document.body, { childList: true, subtree: true, characterData: true });
}
document.addEventListener("DOMContentLoaded", () => {
  const sel = document.getElementById("langSelect");
  if (sel) sel.value = localStorage.getItem("lang") || "uz";
  let q = 0;
  _obs = new MutationObserver(() => { cancelAnimationFrame(q); q = requestAnimationFrame(applyLang); });
  _obs.observe(document.body, { childList: true, subtree: true, characterData: true });
  applyLang();
});
