(function(){
'use strict';
// Brigada boshqaruvi endi app.js/extra.js dagi haqiqiy personel ma'lumotlari bilan ishlaydi.
// Eski v5 generic jadval boshqaruvi olib tashlandi: tanlov, lavozim mosligi va saqlash real worker obyektiga yoziladi.
window.FlexBrigadeManagerV5={init:function(){if(typeof renderBrigades==='function')renderBrigades();}};
})();
