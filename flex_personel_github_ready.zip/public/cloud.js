// Flex Personel Cloud bridge: central server state + role enforcement.
(function(){
  const originalSet=Storage.prototype.setItem.bind(Storage.prototype);
  const originalRemove=Storage.prototype.removeItem.bind(Storage.prototype);
  const nativeSet=originalSet;
  const nativeRemove=originalRemove;
  let hydrated=false;
  let syncing=false;
  const isCloudKey=k=>/^(workers|exits|puantaj_|bodro_|brigades_|positions_|transfers_|kunlik_|garantiya_|dogovor_|workerfiles_|files_|v11_|dbfill_|seed_).*_(jois|nagatino|nagatino2|preobrejenka)$/.test(k)
    || /^(workers|exits)_(jois|nagatino|nagatino2|preobrejenka)$/.test(k)
    || /_(jois|nagatino|nagatino2|preobrejenka)$/.test(k);
  async function push(key, value, remove=false){
    if(!hydrated || syncing || !isCloudKey(key)) return;
    try{ await fetch('/api/state',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,value,remove})}); }
    catch(e){ console.warn('Cloud sync failed:',e); }
  }
  Storage.prototype.setItem=function(k,v){ originalSet(this,k,v); if(this===localStorage) push(k,v,false); };
  Storage.prototype.removeItem=function(k){ originalRemove(this,k); if(this===localStorage) push(k,null,true); };
  window.flexCloudReady=(async function(){
    try{
      const r=await fetch('/api/bootstrap',{credentials:'same-origin'});
      if(!r.ok){hydrated=true;return null;}
      const data=await r.json();
      syncing=true;
      Object.entries(data.state||{}).forEach(([k,v])=>{try{nativeSet(localStorage,k,JSON.parse(v));}catch{nativeSet(localStorage,k,v);}});
      if(data.accounts) nativeSet(localStorage,'cloud_accounts',JSON.stringify(data.accounts));
      nativeSet(localStorage,'cloud_user',JSON.stringify(data.user));
      nativeSet(localStorage,'cloud_objects',JSON.stringify(data.objects||[]));
      syncing=false; hydrated=true; return data;
    }catch(e){ syncing=false; hydrated=true; console.warn('Cloud bootstrap failed:',e); return null; }
  })();
})();
