// ===== Yordamchi: toast, sana =====
const dmy = iso => (iso && /^\d{4}-\d\d-\d\d$/.test(iso)) ? iso.split("-").reverse().join(".") : "";
function toast(msg) {
  const d = document.createElement("div");
  d.textContent = msg;
  d.style.cssText = "position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#065f46;color:#fff;padding:10px 18px;border-radius:8px;z-index:9999;font-size:14px";
  document.body.appendChild(d); setTimeout(() => d.remove(), 2800);
}

// ===== Ma'lumot to'liqligi (INN, SNILS, ruxsatnoma) =====
// Millat bo'yicha: UZ/TJ/AZ → Patent; TR/TM/KZ/KG → Ish ruxsatnomasi; RU → faqat pasport+INN+SNILS
function getDocKind(w) {
  const m = (w.millat || "").toLowerCase();
  // Rossiya, Qozog'iston, Qirg'iziston — faqat pasport + INN + SNILS
  if (/росси|russia|рус|қазақ|qozoq|kazakh|казах|кыргыз|qirg|kyrgyz/i.test(m) || w.doc_type === "РФ" || w.doc_type === "ВНЖ") return "none";
  // O'zbek, Tojik, Ozarbayjon — Patent
  if (/узбек|o'zbek|uzbek|таджик|tojik|tajik|азербайджан|azerbayjan|azerbaijan/i.test(m)) return "patent";
  // Turkiya, Turkmaniston — Ish ruxsatnomasi (РНР)
  if (/турк|turk|türk|туркмен|turkmen/i.test(m)) return "permit";
  return "patent"; // boshqa millat default patent, keyin o'zgartirish mumkin
}
const needsPermit = w => getDocKind(w) !== "none";
function missingData(w) {
  const m = [];
  const kind = getDocKind(w);
  if (kind !== "none" && (!w.patent || !w.patent_berilgan || !w.patent_tugash)) {
    m.push(kind === "patent" ? "Patent ma'lumoti" : "Ish ruxsatnomasi ma'lumoti");
  }
  if (!w.inn) m.push("INN");
  if (!w.snils) m.push("SNILS");
  if (!w.pasport) m.push("Pasport");
  return m;
}
function lockMsg(id) {
  const w = getWorkers().find(x => x.id === id);
  if (!w || isStaff(w)) return;
  const m = missingData(w);
  if (!m.length) return;
  const what = m.length === 3 ? "INN, SNILS va ruxsatnoma ma'lumotlari kiritilmagan." : m.join(", ") + " kiritilmagan.";
  alert(what + "\nIltimos, kerakli ma'lumotlarni kiritishingizni so'raymiz.\n(Ular to'ldirilmaguncha soat 8 da qoladi va o'zgartirib bo'lmaydi.)");
}
function setShift(id, v) {
  const list = getWorkers(), w = list.find(x => x.id === id);
  if (!w) return;
  const m = missingData(w);
  if (v === "GUNDUZ" && m.length) { alert("Kunduz smenasiga o'tkazish uchun avval ma'lumotlarni to'ldiring:\n" + m.join(", ")); renderPuantaj(); return; }
  w.vardiya = v; saveWorkers(list);
}

// ===== Bazadan avtomatik to'ldirish (ИБД + КИГ) =====
const FILL_KEYS = ["tugilgan","dolzhnost","millat","pasport","pasport_berilgan","pasport_tugash","inn","snils","patent","patent_berilgan","patent_tugash","doc_type"];
let _dbMap = null;
const dbKey = s => normFio(s).replace(/й/g, "и");
function dbMap() { if (!_dbMap) { _dbMap = new Map(); (typeof PERSON_DB !== "undefined" ? PERSON_DB : []).forEach(e => _dbMap.set(dbKey(e.fio), e)); } return _dbMap; }
function dbFind(fio) { return dbMap().get(dbKey(fio)); }
function lev(a, b) {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1] + (a[i-1] === b[j-1] ? 0 : 1));
  return d[a.length][b.length];
}
function dbSimilar(fio) {
  const k = dbKey(fio); let best = null, bs = 1;
  dbMap().forEach((e, key) => { const s = lev(k, key) / Math.max(k.length, key.length); if (s < bs) { bs = s; best = e; } });
  return bs <= 0.3 ? best : null;
}
function fillWorker(w, e) { let n = 0; FILL_KEYS.forEach(k => { if (!w[k] && e[k]) { w[k] = e[k]; n++; } }); return n; }
function autoFillAll() {   // faqat bo'sh maydonlar to'ldiriladi
  const list = getWorkers(); let n = 0;
  list.filter(w => !w.exited).forEach(w => { const e = dbFind(w.fio); if (e) n += fillWorker(w, e); });
  saveWorkers(list); return n;
}
function fillFromDB() {
  let n = autoFillAll();
  const list = getWorkers();
  list.filter(w => !w.exited && !dbFind(w.fio) && missingData(w).length).forEach(w => {
    const c = dbSimilar(w.fio);
    if (c && confirm(`"${w.fio}" bazada aniq topilmadi.\nShu odammi?\n${c.fio} (${c.millat || ""}, ${c.pasport || ""})`)) n += fillWorker(w, c);
  });
  saveWorkers(list); renderMalumot(); toast(`Bazadan to'ldirildi: ${n} ta maydon`);
}
function findPastWorker(fio) {
  const k = normFio(fio);
  if (!k) return null;
  // 1) PERSON_DB
  const e = typeof dbFind === "function" ? dbFind(fio) : null;
  if (e) return { ...e, source: "db" };
  // 2) current object workers (including exited)
  const local = JSON.parse(localStorage.getItem(key("workers")) || "[]");
  let hit = local.find(w => normFio(w.fio) === k);
  if (hit) return { ...hit, source: "local" };
  // 3) exits of current object
  if (typeof getExits === "function") {
    hit = getExits().find(w => normFio(w.fio) === k);
    if (hit) return { ...hit, source: "exit" };
  }
  // 4) all objects
  if (typeof OBJECTS !== "undefined") {
    for (const o of OBJECTS) {
      const list = JSON.parse(localStorage.getItem("workers_" + o.id) || "[]");
      hit = list.find(w => normFio(w.fio) === k);
      if (hit) return { ...hit, source: o.short || o.id };
      const ex = JSON.parse(localStorage.getItem("exits_" + o.id) || "[]");
      hit = ex.find(w => normFio(w.fio) === k);
      if (hit) return { ...hit, source: "exit:" + (o.short || o.id) };
    }
  }
  return null;
}
function autoFillFromDB() {   // yangi ishchi: ism yozilgach — oldingi ishchi / baza
  if (editId) return;
  const fio = document.getElementById("f_fio")?.value || "";
  if (fio.trim().length < 4) return;
  const e = findPastWorker(fio);
  if (!e) return;
  const setIf = (id, v) => { const el = document.getElementById(id); if (el && v != null && v !== "") { el.value = v; return 1; } return 0; };
  let n = 0;
  n += setIf("f_tugilgan", e.tugilgan);
  n += setIf("f_pasport", e.pasport);
  n += setIf("f_pasport_berilgan", e.pasport_berilgan);
  n += setIf("f_pasport_tugash", e.pasport_tugash);
  n += setIf("f_pasport_beruvchi", e.pasport_beruvchi || e.pasport_kim || "");
  n += setIf("f_inn", e.inn);
  n += setIf("f_snils", e.snils);
  // davlat / millat
  const dav = e.davlat || e.millat || "";
  n += setIf("f_davlat", dav);
  n += setIf("f_millat", e.millat || "");
  n += setIf("f_fuqarolik", e.fuqarolik || "");
  n += setIf("f_doc_type", e.doc_type || "");
  // sicil: agar bor bo'lsa yoz, yo'q bo'lsa Yenigiris qoldir
  const sic = document.getElementById("f_sicil");
  if (sic) {
    if (e.sicil && e.sicil !== "Yenigiris") { sic.value = e.sicil; n++; }
    else if (!sic.value || sic.value === "Yenigiris") sic.value = "Yenigiris";
  }
  // brigada taklif (o'zgartirish mumkin)
  if (e.ekip && e.ekip !== "STAFF") {
    const ek = document.getElementById("f_ekip");
    if (ek && [...ek.options].some(o => o.value === e.ekip)) { ek.value = e.ekip; n++; }
  }
  // patent — yangi bo'lishi mumkin, faqat bo'sh bo'lsa to'ldiramiz
  n += setIf("f_patent", e.patent);
  n += setIf("f_patent_berilgan", e.patent_berilgan);
  n += setIf("f_patent_tugash", e.patent_tugash);
  if (typeof onDavlatChange === "function") onDavlatChange();
  else if (typeof onDocTypeChange === "function") onDocTypeChange();
  if (n) toast("Oldingi ma'lumot topildi (" + (e.source || "baza") + ") — tekshirib saqlang ✓");
}

// ===== Ishchi ma'lumoti (tahrirlash mumkin) =====
const statusCell = w => { const m = missingData(w); return m.length ? `<span class="badge badge-red">⚠ ${esc(m.join(", "))}</span>` : `<span class="badge badge-green">✓</span>`; };
function setField(id, k, v) {
  const list = getWorkers(), w = list.find(x => x.id === id);
  if (!w) return;
  w[k] = v.trim(); saveWorkers(list);
  const c = document.getElementById("ms_" + id); if (c) c.innerHTML = statusCell(w);
}
function renderMalumot() {
  const tb = document.getElementById("malumotBody");
  if (!tb) return;
  const q = (document.getElementById("searchMalumot")?.value || "").toLowerCase(), inc = document.getElementById("fltMalumot")?.value === "inc";
  let list = getWorkers().filter(w => !w.exited);
  if (q) list = list.filter(w => (w.fio || "").toLowerCase().includes(q) || (w.sicil || "").includes(q) || (w.inn || "").includes(q));
  if (inc) list = list.filter(w => missingData(w).length);
  const inp = (w, k, type = "text", wd = 120) => `<input type="${type}" value="${esc(w[k])}" style="width:${wd}px" onchange="setField('${w.id}','${k}',this.value)">`;
  tb.innerHTML = list.map((w, i) => `<tr id="mr_${w.id}"><td>${i+1}</td>
    <td><b style="cursor:pointer;color:#1d4ed8" onclick="showProfile(currentObj,'${w.id}')">${esc(w.fio)}</b></td>
    <td>${inp(w,"tugilgan","date",135)}</td><td>${inp(w,"pasport")}</td><td>${inp(w,"inn")}</td><td>${inp(w,"snils")}</td>
    <td>${inp(w,"patent")}</td><td>${inp(w,"patent_berilgan","date",135)}</td><td>${inp(w,"patent_tugash","date",135)}</td>
    <td id="ms_${w.id}">${statusCell(w)}</td></tr>`).join("") || `<tr><td colspan="10" style="text-align:center;color:#888;padding:20px">Ma'lumot yo'q</td></tr>`;
}

// ===== Transfer (obyektlar orasida) =====
const trOptions = () => OBJECTS.filter(o => o.id !== currentObj).map(o => `<option value="TR_${o.id}">TRANSFER → ${o.short}</option>`).join("");
function brigadesOf(objId) { const p = currentObj; currentObj = objId; const b = getBrigades(); currentObj = p; return b; }
function addBrigadeTo(objId, name, group) {
  const p = currentObj; currentObj = objId;
  const b = getBrigades();
  if (!b.some(x => x.name === name)) b.push({ name, group });
  localStorage.setItem(key("brigades"), JSON.stringify(b)); currentObj = p;
}
function transferFlow(id) {
  const sel = document.getElementById("st_" + id), destId = sel.value.slice(3);
  sel.value = sel.dataset.prev || "CALISAN";
  const list = getWorkers(), idx = list.findIndex(x => x.id === id);
  if (idx < 0) return;
  const w = list[idx], dest = OBJECTS.find(o => o.id === destId), src = OBJECTS.find(o => o.id === currentObj);
  if (!confirm(`${w.fio}\n${src.short} → ${dest.short}\n\nQo'shishni tasdiqlaysizmi?`)) return;
  let ekip = "STAFF";
  if (!isStaff(w)) {
    const br = brigadesOf(destId);
    const ans = (prompt("Qaysi brigadaga qo'shamiz?\n" + br.map((b, i) => `${i+1} — ${b.name}`).join("\n") + "\n\nRaqamni yozing yoki yangi brigada nomini kiriting:") || "").trim();
    if (!ans) return;
    const n = parseInt(ans, 10);
    if (String(n) === ans && n >= 1 && n <= br.length) ekip = br[n-1].name;
    else { ekip = ans.toUpperCase(); addBrigadeTo(destId, ekip, brigadeGroup(w.ekip)); }
  }
  const night = !confirm("Smena: Kunduzga qo'shamizmi?\nOK — Kunduz, Cancel — Kecha");
  const moved = { ...w, id: "w_" + Date.now() + Math.floor(Math.random() * 1000), ekip, vardiya: night ? "GECE" : "GUNDUZ", transferFrom: currentObj };
  delete moved.exited;
  const dl = JSON.parse(localStorage.getItem("workers_" + destId) || "[]"); dl.push(moved);
  localStorage.setItem("workers_" + destId, JSON.stringify(dl));
  const date = document.getElementById("puantajDate")?.value || todayStr();
  const tl = JSON.parse(localStorage.getItem(key("transfers")) || "[]");
  tl.push({ fio: w.fio, date, to: dest.short, cat: isStaff(w) ? "OFIS" : brigadeGroup(w.ekip) });
  localStorage.setItem(key("transfers"), JSON.stringify(tl));
  list.splice(idx, 1); saveWorkers(list);
  sel.closest("tr")?.remove(); updateStats();
  alert(`✓ ${w.fio} → ${dest.short} (${ekip}, ${night ? "Kecha" : "Kunduz"})`);
}

// ===== Garantiyniy pismo (Word) =====
const MONTHS_RU = ["Января","Февраля","Марта","Апреля","Мая","Июня","Июля","Августа","Сентября","Октября","Ноября","Декабря"];
const sentence = s => s ? s.charAt(0) + s.slice(1).toLowerCase() : "";
function gpWorkers() {
  return getWorkers().filter(w => !w.exited).sort((a, b) => (isStaff(b) - isStaff(a)) || (a.ekip || "").localeCompare(b.ekip || "") || (a.fio || "").localeCompare(b.fio || ""));
}
function gpCells(w, i) {
  const hasP = needsPermit(w) && w.patent;
  const mil = (w.millat || "").trim();
  return [String(i + 1), w.fio || "", w.dolzhnost || sentence(w.lavozim || ""), dmy(w.tugilgan), mil.charAt(0) + mil.slice(1).toLowerCase(),
    hasP ? `${w.pasport || ""}/№${w.patent}` : (w.pasport || ""), hasP ? dmy(w.patent_berilgan) : "-", hasP ? dmy(w.patent_tugash) : "-"];
}
function renderGarantiya() {
  const tb = document.getElementById("gpBody");
  if (!tb) return;
  const dt = document.getElementById("gpDate"); if (dt && !dt.value) dt.value = todayStr();
  let list = gpWorkers();
  const filt = document.getElementById("gpFilter")?.value || "all";
  if (filt === "incomplete") list = list.filter(w => missingData(w).length);
  else if (filt === "complete") list = list.filter(w => !missingData(w).length);
  const incomplete = gpWorkers().filter(w => missingData(w).length).length;
  const info = document.getElementById("gpInfo");
  if (info) info.textContent = `Xatga kiradigan: ${list.length} ta | Ma'lumoti to'liq emas: ${incomplete} ta. Chiqqan/transfer avtomatik chiqariladi.`;
  tb.innerHTML = list.map((w, i) => `<tr class="${missingData(w).length?'row-warn':''}">${gpCells(w, i).map(c => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")
    || `<tr><td colspan="8" style="text-align:center;color:#888">Ro'yxat bo'sh</td></tr>`;
}
async function makeGuarantee() {
  try {
    if (!window.JSZip) { alert("JSZip kutubxonasi yuklanmadi — internet kerak yoki sahifani yangilang."); return; }
    if (typeof GP_TEMPLATE_B64 === "undefined" || !GP_TEMPLATE_B64) { alert("Garantiyniy pismo shabloni topilmadi (gp_template.js)."); return; }
    const W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main", XML = "http://www.w3.org/XML/1998/namespace";
    const zip = await JSZip.loadAsync(GP_TEMPLATE_B64, { base64: true });
    const xmlFile = zip.file("word/document.xml");
    if (!xmlFile) { alert("Shablon ichida word/document.xml yo'q."); return; }
    const doc = new DOMParser().parseFromString(await xmlFile.async("string"), "application/xml");
    const parseErr = doc.getElementsByTagName("parsererror");
    if (parseErr.length) { alert("XML parse xatosi"); return; }
    const date = (document.getElementById("gpDate") && document.getElementById("gpDate").value) || todayStr();
    const [y, m, d] = date.split("-");
    [...doc.getElementsByTagNameNS(W, "t")].forEach(t => {
      if (t.textContent && t.textContent.includes("{DD}")) t.textContent = t.textContent.replace("{DD}", d).replace("{MONTH}", MONTHS_RU[+m - 1] || m).replace("{YYYY}", y);
    });
    const tbl = doc.getElementsByTagNameNS(W, "tbl")[0];
    if (!tbl) { alert("Shablonda jadval topilmadi."); return; }
    const rows = tbl.getElementsByTagNameNS(W, "tr");
    if (rows.length < 2) { alert("Shablonda namuna qator yo'q."); return; }
    const sample = rows[1];
    const workers = gpWorkers();
    workers.forEach((w, i) => {
      const tr = sample.cloneNode(true), tcs = tr.getElementsByTagNameNS(W, "tc");
      gpCells(w, i).forEach((v, j) => {
        if (!tcs[j]) return;
        let t = tcs[j].getElementsByTagNameNS(W, "t")[0];
        if (!t) {
          const r = tcs[j].getElementsByTagNameNS(W, "r")[0] || tcs[j].appendChild(doc.createElementNS(W, "r"));
          t = doc.createElementNS(W, "t");
          r.appendChild(t);
        }
        t.textContent = v || "";
        try { t.setAttributeNS(XML, "xml:space", "preserve"); } catch(e) {}
      });
      tbl.insertBefore(tr, sample);
    });
    tbl.removeChild(sample);
    const ser = new XMLSerializer().serializeToString(doc);
    const finalXml = ser.startsWith("<?xml") ? ser : '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' + ser;
    zip.file("word/document.xml", finalXml);
    const blob = await zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "Garantiyniy_pismo_" + ((OBJECTS.find(o => o.id === currentObj) || {}).short || "") + "_" + date + ".docx";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    if (typeof toast === "function") toast("Garantiyniy pismo yuklandi ✓");
  } catch (err) {
    console.error(err);
    alert("Garantiyniy pismo xatosi: " + (err.message || String(err)));
  }
}

// ===== Ishchi kartochkasi (modal) =====
function showProfile(objId, id) {
  const w = JSON.parse(localStorage.getItem("workers_" + objId) || "[]").find(x => x.id === id);
  if (!w) return;
  const o = OBJECTS.find(x => x.id === objId), m = missingData(w);
  const rows = [["Obyekt", o.name], ["Turi", isStaff(w) ? "Endirekt (Staff)" : "Direkt"], ["Brigada", w.ekip], ["Lavozim", w.lavozim || w.dolzhnost || "—"],
    ["Smena", w.vardiya === "GECE" ? "Kecha" : "Kunduz"], ["Sicil №", w.sicil], ["Davlat", w.davlat || "—"], ["Fuqarolik", w.fuqarolik || w.millat || "—"], ["Tug'ilgan sana", dmy(w.tugilgan)], ["Pasport", w.pasport],
    ["Pasport berilgan", dmy(w.pasport_berilgan)], ["Pasport tugash", dmy(w.pasport_tugash)], ["Кем выдан паспорт", w.pasport_beruvchi || "—"], ["INN", w.inn], ["SNILS", w.snils],
    ["Hujjat turi", w.doc_type || "—"], ...(getDocKind(w) === "none" ? [] : [["Hujjat raqami", w.patent], ["Berilgan", dmy(w.patent_berilgan)], ["Tugash", dmy(w.patent_tugash)]])];
  const ov = document.createElement("div");
  ov.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9998;display:flex;align-items:center;justify-content:center;padding:16px";
  ov.onclick = e => { if (e.target === ov) ov.remove(); };
  ov.innerHTML = `<div style="background:#fff;border-radius:12px;max-width:520px;width:100%;max-height:90vh;overflow:auto;padding:20px">
    <h3 style="margin:0 0 10px">${esc(w.fio)}</h3>
    ${m.length ? `<div style="background:#fee2e2;color:#991b1b;padding:8px 10px;border-radius:8px;margin-bottom:10px">⚠ Ma'lumot to'liq emas: ${esc(m.join(", "))}</div>` : ""}
    <table style="width:100%;border-collapse:collapse">${rows.map(([k, v]) => `<tr><td style="padding:4px 6px;color:#666;border-bottom:1px solid #eee;width:42%">${k}</td><td style="padding:4px 6px;border-bottom:1px solid #eee"><b>${esc(v) || "—"}</b></td></tr>`).join("")}</table>
    <div style="margin-top:12px;padding:10px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0">
      <b style="font-size:13px">📎 Fayllar (skaner / patent cheki / hujjat)</b>
      <div id="wfiles_${w.id}" style="margin:8px 0;font-size:12px"></div>
      <input type="file" id="wfile_inp_${w.id}" multiple accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" style="font-size:12px">
      <button class="btn-sm btn-main" style="margin-top:6px" onclick="uploadWorkerFiles('${objId}','${w.id}')">Yuklash</button>
    </div>
    <div style="margin-top:14px;text-align:right"><button class="btn-sm" onclick="location.href='object.html?id=${objId}'" ${currentObj === objId ? 'style="display:none"' : ""}>Obyektda ochish</button> <button class="btn-main btn-sm" onclick="this.closest('div[style*=fixed]').remove()">Yopish</button></div></div>`;
  setTimeout(() => renderWorkerFilesUI(objId, w.id), 50);
  document.body.appendChild(ov);
}

// ===== Dashboard: umumiy ro'yxat =====
function ensureData() {
  const prev = currentObj;
  OBJECTS.forEach(o => { currentObj = o.id; if (o.id === "jois") seedJoisData(); migrateWorkers(); });
  currentObj = prev;
}
function renderGlobal() {
  const tb = document.getElementById("globalBody");
  if (!tb) return;
  const q = (document.getElementById("gSearch")?.value || "").toLowerCase().trim(), f = document.getElementById("gObj")?.value || "";
  let rows = [];
  OBJECTS.forEach(o => { if (f && f !== o.id) return; JSON.parse(localStorage.getItem("workers_" + o.id) || "[]").filter(w => !w.exited).forEach(w => rows.push({ o, w })); });
  if (q) rows = rows.filter(({ w }) => (w.fio || "").toLowerCase().includes(q) || (w.sicil || "").includes(q) || (w.inn || "").includes(q) || (w.pasport || "").toLowerCase().includes(q));
  document.getElementById("gCount").textContent = rows.length;
  tb.innerHTML = rows.slice(0, 400).map(({ o, w }, i) => `<tr><td>${i+1}</td>
    <td><b style="cursor:pointer;color:#1d4ed8" onclick="showProfile('${o.id}','${w.id}')">${esc(w.fio)}</b>${missingData(w).length ? ' <span title="Ma&#39;lumot to&#39;liq emas">⚠️</span>' : ""}</td>
    <td>${esc(w.sicil)}</td><td><span class="badge badge-green">${o.short}</span></td><td>${esc(w.lavozim)}</td><td>${esc(w.ekip)}</td><td>${w.vardiya === "GECE" ? "Kecha" : "Kunduz"}</td></tr>`).join("")
    || `<tr><td colspan="7" style="text-align:center;color:#888;padding:20px">Ma'lumot yo'q</td></tr>`;
}

// ===== Sozlamalar (login / parol) =====
function toggleSettings() {
  const p = document.getElementById("settingsPanel");
  p.style.display = p.style.display === "none" ? "block" : "none";
  if (p.style.display === "block") renderSettings();
}
const ACCOUNTS = () => [["admin", "Admin (hamma obyektlar)"], ...OBJECTS.map(o => [o.id, o.name])];
function renderSettings() {
  const c = getCreds();
  document.getElementById("settingsBody").innerHTML = ACCOUNTS().map(([id, name]) => `<tr><td><b>${name}</b></td>
    <td><input type="text" id="sl_${id}" value="${esc(c[id]?.login||"")}"></td><td><input type="password" id="sp_${id}" placeholder="O'zgartirish uchun yangi parol"></td></tr>`).join("")
    + `<tr><td><b>Tiklash kodi</b></td><td colspan="2">Serverdagi recovery code environment variable orqali boshqariladi.</td></tr>`;
}
async function saveSettings() {
  const accounts={}; const logins=[];
  for (const [id] of ACCOUNTS()) {
    const l=document.getElementById("sl_"+id).value.trim(), p=document.getElementById("sp_"+id).value;
    if(!l){alert("Login bo'sh bo'lmasin");return;}
    accounts[id]={login:l}; if(p) accounts[id].password=p; logins.push(l.toLowerCase());
    if(p && p.length<4){alert("Parol kamida 4 belgi bo'lsin");return;}
  }
  if(new Set(logins).size!==logins.length){alert("Har bir hisobning logini har xil bo'lishi kerak");return;}
  try{
    const r=await fetch('/api/accounts',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({accounts})});
    const j=await r.json(); if(!r.ok) throw new Error(j.error||'Xatolik');
    const old=getCreds(); Object.entries(accounts).forEach(([id,a])=>{old[id]={...(old[id]||{}),login:a.login};}); localStorage.setItem('cloud_accounts',JSON.stringify(old));
    toast("Saqlandi ✓"); renderSettings();
  }catch(e){alert(e.message);}
}

// ===== BRIGADA BOSHQARUVI =====
function saveBrigadesForCurrent(list){localStorage.setItem(key("brigades"),JSON.stringify(list))}
function brigadeAllowedGroup(w){
  const p=(String(w.lavozim||"")+" "+String(w.dolzhnost||"")).toLowerCase();
  if(/вентиляц|кондиционир|xavoland/.test(p)) return "Xavolandirma";
  if(/монтажник труб|\bтруб|mexanik/.test(p)) return "Mexanik";
  if(/кладов|склад|ambar/.test(p)) return "Ambar";
  const g=brigadeGroup(w.ekip);
  return g||"Mexanik";
}
function brigadeMembers(b){return getWorkers().filter(w=>!w.exited&&!isStaff(w)&&w.ekip===b.name)}
function renderBrigades(){
  const box=document.getElementById("brigadeCards"); if(!box)return;
  const br=getBrigades();
  box.innerHTML=`<div class="brigade-admin-bar"><button class="btn-main btn-sm" onclick="addBrigadeUI()">＋ Yangi brigada qo‘shish</button><span class="muted">Brigadir faqat STAFF. Ishchi faqat lavozimiga mos brigadaga qo‘shiladi.</span></div>`+
  br.map((b,i)=>{
    const members=brigadeMembers(b), leader=b.leader||"Tayinlanmagan";
    return `<div class="brigade-card fixed-brigade-card"><div class="brigade-top"><div><span class="brigade-group">${esc(b.group||"")}</span><h3>${esc(b.name)}</h3></div><span class="brigade-count">${members.length} kishi</span></div>
      <div class="brigade-leader">👤 Brigadir (faqat STAFF): <b>${esc(leader)}</b></div>
      <div class="brigade-members">${members.slice(0,6).map(w=>`<span>${esc(w.fio)}</span>`).join("")||'<span class="muted">Hali ishchi qo‘shilmagan</span>'}${members.length>6?`<span class="muted">+${members.length-6} ta</span>`:""}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn-sec btn-sm" onclick="editBrigadeUI(${i})">Brigadir</button><button class="btn-main btn-sm" onclick="manageBrigadeMembers(${i})">Odamlarni boshqarish</button><button class="btn-sec btn-sm" style="background:#fee2e2;color:#991b1b" onclick="deleteBrigade(${i})">🗑 O'chirish</button></div>
    </div>`;
  }).join("");
}
function deleteBrigade(i){
  const list=getBrigades(); const b=list[i]; if(!b) return;
  const members=brigadeMembers(b);
  const msg = members.length
    ? `"${b.name}" brigadasida ${members.length} ta odam bor. O'chirsangiz ular "Boshqa" guruhiga o'tkaziladi. Davom etasizmi?`
    : `"${b.name}" brigadasini o'chirishni tasdiqlaysizmi? (Keyin qayta qo'shishingiz mumkin)`;
  if(!confirm(msg)) return;
  const workers=getWorkers();
  workers.forEach(w=>{ if(w.ekip===b.name) w.ekip="Boshqa"; });
  saveWorkers(workers);
  // if default, mark as deleted in storage by saving custom list without it
  const all = list.filter((_,idx)=>idx!==i);
  saveBrigadesForCurrent(all);
  renderBrigades();
  if (typeof renderPuantaj==="function") renderPuantaj();
  toast("Brigada o'chirildi ✓ — qayta qo'shishingiz mumkin"); if(typeof onTurChange==="function") onTurChange();
}
function addBrigadeUI(){
  const name=(prompt("Yangi brigada nomi:","MEXANIK-2")||"").trim(); if(!name)return;
  const type=(prompt("Qaysi lavozim guruhi? 1-AMBAR, 2-XAVOLANDIRMA, 3-MEXANIK","3")||"").trim();
  const group={"1":"Ambar","2":"Xavolandirma","3":"Mexanik"}[type]||null;
  if(!group){alert("Faqat 1, 2 yoki 3 ni tanlang.");return;}
  const list=getBrigades(); if(list.some(x=>x.name.toLowerCase()===name.toLowerCase())){alert("Bu brigada allaqachon bor.");return;}
  const candidates=getWorkers().filter(w=>!w.exited&&isStaff(w));
  if(!candidates.length){alert("Brigadir tayinlash uchun STAFF xodimi yo‘q.");return;}
  const hint=candidates.map((x,n)=>`${n+1}. ${x.fio} — ${x.lavozim||x.dolzhnost||"STAFF"}`).join("\n");
  const ans=prompt(`Brigadirni faqat STAFFdan tanlang:\n\n${hint}\n\nRaqami:`,"1"); if(ans===null)return;
  const n=parseInt(ans,10); if(!(String(n)===ans&&n>=1&&n<=candidates.length)){alert("Faqat ro‘yxatdagi STAFF xodimini tanlang.");return;}
  list.push({name,group,leader:candidates[n-1].fio,custom:true}); saveBrigadesForCurrent(list); renderBrigades();
  toast("Yangi brigada qo‘shildi ✓"); if(typeof onTurChange==="function") onTurChange();
}
function editBrigadeUI(i){
  const b=getBrigades()[i]; if(!b)return;
  const candidates=getWorkers().filter(w=>!w.exited&&isStaff(w));
  if(!candidates.length){alert("Brigadir tayinlash uchun STAFF xodimi mavjud emas.");return}
  const hint=candidates.map((x,n)=>`${n+1}. ${x.fio} — ${x.lavozim||x.dolzhnost||"STAFF"}`).join("\n");
  const ans=prompt(`“${b.name}” brigadirini faqat STAFF xodimlaridan tanlang.\n\n${hint}\n\nRaqamini kiriting:`,String(Math.max(1,candidates.findIndex(x=>x.fio===b.leader)+1)));
  if(ans===null)return; const n=parseInt(ans,10);
  if(!(String(n)===ans&&n>=1&&n<=candidates.length)){alert("Faqat ro‘yxatdagi STAFF xodimini tanlang.");return}
  const list=getBrigades(); list[i].leader=candidates[n-1].fio; saveBrigadesForCurrent(list); renderBrigades(); toast("Brigadir tayinlandi ✓");
}
function manageBrigadeMembers(i){
  const br=getBrigades(), target=br[i]; if(!target)return;
  const workers=getWorkers().filter(w=>!w.exited&&!isStaff(w));
  const eligible=workers.filter(w=>brigadeAllowedGroup(w)===target.group || w.ekip===target.name);
  const incompatible=workers.filter(w=>brigadeAllowedGroup(w)!==target.group && w.ekip!==target.name);
  const wrap=document.createElement("div"); wrap.className="bm-members-modal";
  wrap.innerHTML=`<div class="bm-members-card"><div class="bm-members-head"><div><h3>${esc(target.name)} — odamlarni boshqarish</h3><p>Faqat <b>${esc(target.group)}</b> lavozimiga mos ishchilar ko‘rsatiladi. Boshqa yo‘nalishdagi ishchini avval lavozimini o‘zgartirsangiz, keyin shu yerda tanlash mumkin.</p></div><button onclick="this.closest('.bm-members-modal').remove()">✕</button></div>
    <div class="bm-members-tools"><label>Tanlanganlarni brigadaga:</label><select id="bmTargetBr"><option value="${esc(target.name)}">${esc(target.name)}</option>${br.filter(x=>x.name!==target.name&&x.group===target.group).map(x=>`<option value="${esc(x.name)}">${esc(x.name)}</option>`).join("")}</select><button class="btn-sec btn-sm" id="bmCheckAll">Hammasini tanlash</button><button class="btn-sec btn-sm" id="bmClear">Tozalash</button></div>
    <div class="bm-members-list">${eligible.map(w=>`<label class="bm-person-row"><input type="checkbox" value="${esc(w.id)}" ${w.ekip===target.name?'checked':''}><span><b>${esc(w.fio)}</b><small>${esc(w.lavozim||w.dolzhnost||"")} · hozir: ${esc(w.ekip||"—")}</small></span></label>`).join("")||'<div class="muted">Mos keladigan ishchi yo‘q.</div>'}</div>
    <details><summary>Mos kelmaydiganlar (${incompatible.length})</summary><div class="bm-incompatible">${incompatible.slice(0,80).map(w=>`<div>${esc(w.fio)} — ${esc(w.lavozim||w.dolzhnost||"")} <span>→ ${esc(brigadeAllowedGroup(w))}</span></div>`).join("")||'Yo‘q'}</div></details>
    <div class="bm-members-actions"><button class="btn-sec" onclick="this.closest('.bm-members-modal').remove()">Bekor qilish</button><button class="btn-main" id="bmSaveMembers">Saqlash</button></div></div>`;
  document.body.appendChild(wrap);
  wrap.querySelector('#bmCheckAll').onclick=()=>wrap.querySelectorAll('.bm-person-row input').forEach(x=>x.checked=true);
  wrap.querySelector('#bmClear').onclick=()=>wrap.querySelectorAll('.bm-person-row input').forEach(x=>x.checked=false);
  wrap.querySelector('#bmSaveMembers').onclick=()=>{
    const selected=new Set([...wrap.querySelectorAll('.bm-person-row input:checked')].map(x=>x.value));
    const dest=wrap.querySelector('#bmTargetBr').value;
    const list=getWorkers(); let moved=0;
    list.forEach(w=>{
      if(selected.has(w.id)){
        if(brigadeAllowedGroup(w)!==brigadeGroup(dest)){alert(`${w.fio}: lavozimi ${brigadeAllowedGroup(w)} guruhiga tegishli. ${dest}ga qo‘shib bo‘lmaydi.`);return;}
        if(w.ekip!==dest){w.ekip=dest;moved++;}
      } else if(w.ekip===target.name){w.ekip=target.name;}
    });
    saveWorkers(list); renderBrigades(); wrap.remove(); toast(`${moved} ta ishchi brigadaga joylashtirildi ✓`);
  };
}

/* ===== Hujjat nazorati: Trudovoy + UVD 655 ===== */
const DOC_DB="flex_files";
const uvdKey=id=>currentObj+"_"+id+"__uvd655";
async function getDocRecord(id){
  const r=await fileOp("readonly",s=>s.get(dogKey(id)));
  if(!r)return {files:[]};
  if(Array.isArray(r.files))return r;
  return {files:[{name:r.name||"fayl",blob:r.blob,uploadedAt:r.uploadedAt||Date.now()}]};
}
async function renderDogovor(){
  const tbody=document.getElementById("dogovorBody"); if(!tbody)return;
  const q=(document.getElementById("searchDogovor")?.value||"").toLowerCase().trim();
  const filter=document.getElementById("dogUvdFilter")?.value||"";
  const workers=getWorkers().filter(w=>!w.exited && ((w.fio||"").toLowerCase().includes(q)||(w.sicil||"").toLowerCase().includes(q)));
  const rows=[];
  let urgent=0;
  for(const w of workers){
    const rec=await getDocRecord(w.id), uv=await fileOp("readonly",s=>s.get(uvdKey(w.id)));
    const files=rec.files||[], contractAt=files.length?Math.min(...files.map(f=>f.uploadedAt||Date.now())):null;
    const age=contractAt?Math.floor((Date.now()-contractAt)/86400000):null;
    const missing=!uv;
    const overdue=missing&&age!==null&&age>=3;
    if(overdue)urgent++;
    if((filter==="yes"&&!uv)||(filter==="no"&&uv)||(filter==="urgent"&&!overdue))continue;
    rows.push({w,files,uv,age,overdue});
  }
  const alert=document.getElementById("dogovorAlert");
  if(alert) alert.innerHTML=urgent
    ? `<b>⚠️ QATTIQ NAZORAT:</b> ${urgent} ta ishchida Trudovoy fayli yuklanganiga 3 kun yoki undan ko‘p bo‘lgan, lekin UVD 655 fayli hali yo‘q.`
    : `<span class="doc-ok">✓ UVD 655 nazorati: kechikkan hujjatlar yo‘q.</span>`;
  tbody.innerHTML=rows.map((x,i)=>{
    const names=x.files.map((f,j)=>`<span class="file-chip">📄 ${esc(f.name)} <button onclick="openDogovor('${x.w.id}',${j})">↗</button> <button onclick="delDogovor('${x.w.id}',${j})">×</button></span>`).join(" ")||'<span class="badge badge-red">Fayl yo‘q</span>';
    const u=x.uv?`<span class="badge badge-green">✓ ${esc(x.uv.name)}</span> <button class="btn-sm" onclick="openUvd655('${x.w.id}')">Ochish</button>`:'<span class="badge badge-red">UVD 655 yo‘q</span>';
    const control=x.overdue?`<span class="doc-overdue">3+ kun — darhol yuklang</span>`:x.uv?'<span class="doc-ok">Nazorat OK</span>':x.age===null?'<span class="muted">Trudovoy fayli kutilmoqda</span>':`<span class="doc-wait">${3-x.age} kun qoldi</span>`;
    return `<tr><td>${i+1}</td><td><b class="worker-link" onclick="showProfile(currentObj,'${x.w.id}')">${esc(x.w.fio)}</b></td><td>${esc(x.w.sicil)}</td><td>${esc(x.w.lavozim)}</td><td>${names}</td><td>${u}</td><td>${control}</td><td><button class="btn-sm" onclick="pickDogovor('${x.w.id}')">＋ Fayl</button><button class="btn-sm ${x.uv?'':'btn-warning'}" onclick="pickUvd655('${x.w.id}')">UVD 655</button></td></tr>`;
  }).join("")||`<tr><td colspan="8" style="text-align:center;color:#888;padding:20px">Mos ishchi yo‘q</td></tr>`;
}
function pickDogovor(id){dogTarget=id;const f=document.getElementById("dogFile");f.value="";f.click()}
async function uploadDogovor(inp){
  if(!dogTarget)return;
  const fs=[...inp.files]; if(!fs.length)return;
  const rec=await getDocRecord(dogTarget);
  for(const f of fs){
    rec.files.push({name:f.name,blob:f,uploadedAt:Date.now()});
  }
  await fileOp("readwrite",s=>s.put(rec,dogKey(dogTarget)));
  dogTarget=null; renderDogovor();
}
function pickUvd655(id){dogTarget=id;const f=document.getElementById("uvdFile");f.value="";f.click()}
async function uploadUvd655(inp){
  const f=inp.files[0]; if(!f||!dogTarget)return;
  await fileOp("readwrite",s=>s.put({name:f.name,blob:f,uploadedAt:Date.now()},uvdKey(dogTarget)));
  dogTarget=null; renderDogovor(); toast("UVD 655 fayli saqlandi ✓");
}
async function openDogovor(id,index){
  const rec=await getDocRecord(id),r=rec.files?.[index]; if(!r)return;
  const url=URL.createObjectURL(r.blob);
  if(/\.pdf$/i.test(r.name))window.open(url,"_blank");else{const a=document.createElement("a");a.href=url;a.download=r.name;a.click()}
}
async function delDogovor(id,index){
  const rec=await getDocRecord(id); if(!rec.files?.[index])return;
  if(!confirm("Bu fayl o‘chirilsinmi?"))return;
  rec.files.splice(index,1); await fileOp("readwrite",s=>s.put(rec,dogKey(id))); renderDogovor();
}

async function openUvd655(id){
  const r=await fileOp("readonly",s=>s.get(uvdKey(id))); if(!r)return;
  const url=URL.createObjectURL(r.blob);
  if(/\\.pdf$/i.test(r.name)) window.open(url,"_blank"); else {const a=document.createElement("a");a.href=url;a.download=r.name;a.click()}
}
async function delUvd655(id){
  if(!confirm("UVD 655 fayli o‘chirilsinmi?"))return;
  await fileOp("readwrite",s=>s.delete(uvdKey(id))); renderDogovor();
}
/* ===== FLEX transfer workflow: brigade + date + time + history ===== */
const FLEX_PENDING_KEY="flex_pending_transfers_v3";
function getPendingTransfers(){try{let v=JSON.parse(localStorage.getItem(FLEX_PENDING_KEY)||"null");if(Array.isArray(v))return v;const old=JSON.parse(localStorage.getItem("flex_pending_transfers_v2")||"[]");if(Array.isArray(old)&&old.length){v=old.map(t=>({...t,sentDate:t.sentAt?t.sentAt.slice(0,10):todayStr(),effectiveDate:todayStr(),mode:"TODAY",status:t.status||"PENDING"}));localStorage.setItem(FLEX_PENDING_KEY,JSON.stringify(v));return v}return []}catch(e){return []}}
function savePendingTransfers(list){localStorage.setItem(FLEX_PENDING_KEY,JSON.stringify(list))}
function transferId(){return "tr_"+Date.now()+"_"+Math.random().toString(36).slice(2,8)}
function transferDateTime(){return new Date().toISOString()}
function localDate(d=new Date()){const x=new Date(d.getTime()-d.getTimezoneOffset()*60000);return x.toISOString().slice(0,10)}
function nextDate(s){const d=new Date((s||todayStr())+"T12:00:00");d.setDate(d.getDate()+1);return localDate(d)}
function transferDestOptions(){return OBJECTS.filter(o=>o.id!==currentObj).map(o=>`<option value="${o.id}">${esc(o.name)}</option>`).join("")}
function brigadesOf(objId){const old=currentObj;currentObj=objId;const b=getBrigades();currentObj=old;return b}
function syncTodayHoursForTransfer(w){
  const date=todayStr(),p=getPuantaj(date),rec=p[w.id]||{status:"CALISAN",hours:getDefaultHours(date),note:""};
  const h=document.getElementById("hr_"+w.id)?.value,st=document.getElementById("st_"+w.id)?.value,note=document.getElementById("nt_"+w.id)?.value;
  if(h!==undefined)rec.hours=lockHours(w,st||rec.status)??h;if(st)rec.status=st;if(note!==undefined)rec.note=note;
  p[w.id]=rec;savePuantajData(date,p);pushToBodro(date,{[w.id]:rec});return rec;
}
function startTransfer(id,destId){
  if(!destId||destId===currentObj)return;const list=getWorkers(),idx=list.findIndex(w=>w.id===id&&!w.exited);if(idx<0)return;
  const w=list[idx],dest=OBJECTS.find(o=>o.id===destId);if(!dest)return;const pending=getPendingTransfers();
  if(pending.some(t=>t.status==="PENDING"&&t.worker&&(t.worker.id===w.id||(t.worker.sicil&&t.worker.sicil===w.sicil)||t.worker.fio===w.fio)&&t.to===destId)){toast("Bu odam shu obyektga allaqachon transferga yuborilgan.");return}
  syncTodayHoursForTransfer(w);
  const when=confirm(`Transfer qachondan?\n\nOK — BUGUN (${todayStr()})\nCancel — ERTAGA (${nextDate()})\n\nBugungi soati va transfer vaqti saqlanadi.`)?"TODAY":"TOMORROW";
  const effectiveDate=when==="TODAY"?todayStr():nextDate();
  pending.push({id:transferId(),from:currentObj,to:destId,sentAt:transferDateTime(),sentDate:todayStr(),effectiveDate,mode:when,worker:{...w,exited:false},status:"PENDING"});savePendingTransfers(pending);
  if(when==="TODAY"){list.splice(idx,1);saveWorkers(list)}
  renderPuantaj();renderWorkers();updateStats();updateTransferBadge();toast(`${w.fio} → ${dest.short}: ${when==="TODAY"?"bugun":"ertaga"} transferga yuborildi ✓`);
}
let activeTransferId=null;
function refreshTransferBrigades(){
  const sel=document.getElementById("transferBrigade"),type=document.getElementById("transferType")?.value||"DIREKT";if(!sel)return;
  if(type==="ENDIREKT"){sel.innerHTML='<option value="STAFF">STAFF / Ofis</option>';return}
  const br=brigadesOf(currentObj);sel.innerHTML=br.map(x=>`<option value="${esc(x.name)}">${esc(x.name)} — ${esc(x.group||"Mekanik")}${x.leader?` · Brigadir: ${esc(x.leader)}`:""}</option>`).join("")||'<option value="">Brigada topilmadi</option>';
}
function openTransferModal(id){
  const item=getPendingTransfers().find(t=>t.id===id&&t.to===currentObj&&t.status==="PENDING");if(!item)return;
  if(item.effectiveDate>todayStr()){toast(`Bu transfer ${dmy(item.effectiveDate)} dan kuchga kiradi.`);return}
  activeTransferId=id;const w=item.worker||{},src=OBJECTS.find(o=>o.id===item.from),dst=OBJECTS.find(o=>o.id===item.to);
  document.getElementById("transferName").innerHTML=`<b>${esc(w.fio||"")}</b><br><span class="transfer-route">${esc(src?.short||item.from)} → ${esc(dst?.short||item.to)} · ${item.mode==="TOMORROW"?"Ertadan":"Bugundan"} · ${new Date(item.sentAt).toLocaleString("uz-UZ")}</span>`;
  document.getElementById("transferType").value=isStaff(w)?"ENDIREKT":"DIREKT";document.getElementById("transferShift").value=w.vardiya==="GECE"?"GECE":"GUNDUZ";refreshTransferBrigades();
  if(!isStaff(w)){const sel=document.getElementById("transferBrigade"),br=brigadesOf(currentObj);if(w.ekip&&br.some(x=>x.name===w.ekip))sel.value=w.ekip}
  document.getElementById("transferModal").classList.remove("hidden");
}
function closeTransferModal(){document.getElementById("transferModal")?.classList.add("hidden");activeTransferId=null}
function confirmTransfer(){
  if(!activeTransferId)return;const pending=getPendingTransfers(),idx=pending.findIndex(t=>t.id===activeTransferId&&t.to===currentObj);if(idx<0){closeTransferModal();return}
  const item=pending[idx];if(item.effectiveDate>todayStr()){toast(`Avval ${dmy(item.effectiveDate)} sanasi kelishi kerak.`);return}
  const w={...(item.worker||{})},type=document.getElementById("transferType").value,shift=document.getElementById("transferShift").value,brigade=document.getElementById("transferBrigade").value;
  if(type==="DIREKT"&&!brigade){alert("Brigadani tanlang.");return}
  w.exited=false;w.tur=type;w.vardiya=shift;w.ekip=type==="ENDIREKT"?"STAFF":brigade;w.transferFrom=item.from;w.transferAcceptedAt=transferDateTime();w.transferEffectiveDate=item.effectiveDate;
  const history=Array.isArray(w.transferHistory)?w.transferHistory:[];history.push({from:item.from,to:item.to,effectiveDate:item.effectiveDate,sentAt:item.sentAt});w.transferHistory=history;
  const list=getWorkers().filter(x=>x.id!==w.id);list.push(w);saveWorkers(list);
  const p=getPuantaj(item.effectiveDate);p[w.id]={status:"CALISAN",hours:0,note:"Transfer bilan keldi — soat 0"};savePuantajData(item.effectiveDate,p);pushToBodro(item.effectiveDate,{[w.id]:p[w.id]});
  pending[idx]={...item,status:"ACCEPTED",acceptedAt:transferDateTime(),acceptedBy:currentObj,worker:w};savePendingTransfers(pending);
  closeTransferModal();renderTransfers();renderPuantaj();renderWorkers();renderBodro();updateStats();toast(`${w.fio} → ${OBJECTS.find(o=>o.id===currentObj)?.short||""} ✓ Soat 0 dan boshlandi`);
}
function rejectTransfer(id){const pending=getPendingTransfers(),idx=pending.findIndex(t=>t.id===id&&t.to===currentObj);if(idx<0)return;const item=pending[idx];if(!confirm(`${item.worker?.fio||"Ishchi"} transferi bekor qilinsinmi?`))return;pending[idx]={...item,status:"REJECTED",rejectedAt:transferDateTime()};savePendingTransfers(pending);if(item.mode==="TODAY"){const old=JSON.parse(localStorage.getItem("workers_"+item.from)||"[]");if(!old.some(w=>w.id===item.worker.id))old.push(item.worker);localStorage.setItem("workers_"+item.from,JSON.stringify(old))}renderTransfers();updateTransferBadge();toast("Transfer bekor qilindi.")}
function processScheduledTransfers(){
  const today=todayStr(),pending=getPendingTransfers();OBJECTS.forEach(o=>{let list=JSON.parse(localStorage.getItem("workers_"+o.id)||"[]"),dirty=false;pending.filter(t=>t.status==="PENDING"&&t.mode==="TOMORROW"&&t.effectiveDate<=today&&t.from===o.id).forEach(t=>{if(list.some(w=>w.id===t.worker.id)){list=list.filter(w=>w.id!==t.worker.id);dirty=true}});if(dirty)localStorage.setItem("workers_"+o.id,JSON.stringify(list))});if(currentObj){renderWorkers();renderPuantaj();updateStats()}}
function renderTransfers(){
  const body=document.getElementById("transferBody");if(!body)return;processScheduledTransfers();const pending=getPendingTransfers().filter(t=>t.to===currentObj&&t.status==="PENDING"),summary=document.getElementById("transferSummary");
  if(summary)summary.innerHTML=pending.length?`<span class="transfer-summary-icon">↔</span><b>${pending.length} ta</b> transfer kutmoqda`:`<span class="transfer-summary-ok">✓ Transferlar yo‘q</span>`;
  body.innerHTML=pending.map((t,i)=>{const w=t.worker||{},src=OBJECTS.find(o=>o.id===t.from),ready=t.effectiveDate<=todayStr();return `<tr><td>${i+1}</td><td><b>${esc(w.fio)}</b></td><td>${esc(w.sicil||"")}</td><td><span class="badge badge-blue">${esc(src?.short||t.from)}</span></td><td>${esc(w.lavozim||"")}</td><td>${esc(w.ekip||"")}</td><td>${dmy(t.effectiveDate)}<br><small>${new Date(t.sentAt).toLocaleTimeString("uz-UZ",{hour:"2-digit",minute:"2-digit"})}</small></td><td><div class="transfer-actions"><button class="btn-main btn-sm" ${ready?"":"disabled"} onclick="openTransferModal('${t.id}')">${ready?"Tasdiqlash":"Kutilmoqda"}</button><button class="btn-sec btn-sm" onclick="rejectTransfer('${t.id}')">Qaytarish</button></div></td></tr>`}).join("")||`<tr><td colspan="8" class="transfer-empty">Hozircha kelgan transfer yo‘q</td></tr>`;updateTransferBadge();
}
function updateTransferBadge(){const el=document.getElementById("transferBadge");if(!el)return;const n=getPendingTransfers().filter(t=>t.to===currentObj&&t.status==="PENDING").length;el.textContent=n;el.classList.toggle("is-zero",!n)}

/* Puantaj is redesigned so the worker list is the only scrolling area and has a transfer action. */
function renderPuantaj() {
  const tbody=document.getElementById("puantajBody"); if(!tbody) return;
  const date=document.getElementById("puantajDate")?.value||todayStr();
  const workers=getWorkers().filter(w=>!w.exited);
  const saved=getPuantaj(date), defH=getDefaultHours(date);

  // Sort order: STAFF first, then by brigade group (Mexanik, Xavolandirma, Ambar), then name
  const groupOrder = { "STAFF": 0, "Mexanik": 1, "Xavolandirma": 2, "Ambar": 3 };
  const getOrder = w => {
    if (isStaff(w)) return 0;
    const g = brigadeGroup(w.ekip || "");
    return (groupOrder[g] != null ? groupOrder[g] : 9);
  };

  // Split day / night within each brigade, day alpha, night alpha at bottom of brigade
  const brigades = getBrigades();
  const brigadeNames = ["STAFF", ...brigades.map(b => b.name)];
  // also include any orphan ekips
  workers.forEach(w => { const e = isStaff(w) ? "STAFF" : (w.ekip || "Boshqa"); if (!brigadeNames.includes(e)) brigadeNames.push(e); });

  let html = "", globalNum = 1;
  brigadeNames.forEach(gName => {
    let list = workers.filter(w => (isStaff(w) ? "STAFF" : (w.ekip || "Boshqa")) === gName);
    if (!list.length) return;
    // day first (alpha), then night (alpha)
    const day = list.filter(w => w.vardiya !== "GECE").sort((a,b) => (a.fio||"").localeCompare(b.fio||"", "uz"));
    const night = list.filter(w => w.vardiya === "GECE").sort((a,b) => (a.fio||"").localeCompare(b.fio||"", "uz"));
    const ordered = [...day, ...night];
    const brInfo = getBrigades().find(b => b.name === gName);
    const grpLabel = gName === "STAFF" ? "STAFF (Ofis) / ENDIREKT" : (brInfo && brInfo.leader ? `${gName} — ${brInfo.leader}` : gName);
    html += `<tr class="group-row"><td colspan="10"><span class="group-dot"></span><b>${esc(grpLabel)}</b><span class="group-count">${ordered.length} (K:${day.length} / G:${night.length})</span></td></tr>`;
    let num = 1;
    ordered.forEach(w => {
      const rec = saved[w.id] || { status:"CALISAN", hours: defH, note:"" };
      const lk = lockHours(w, rec.status);
      if (lk !== undefined) rec.hours = lk;
      else if (rec.hours === "" || rec.hours == null) rec.hours = defH;
      const opts = OBJECTS.filter(o => o.id !== currentObj).map(o => `<option value="${o.id}">${esc(o.short)}</option>`).join("");
      const isNight = w.vardiya === "GECE";
      html += `<tr class="${isNight ? "night-row" : ""}">
        <td>${esc(w.ekip || "STAFF")}</td>
        <td>${num++}</td>
        <td>${esc(w.sicil || "")}</td>
        <td><b class="worker-link" onclick="showProfile(currentObj,'${w.id}')">${esc(w.fio)}</b>${missingData(w).length ? ' ⚠️' : ""}</td>
        <td>${esc(w.lavozim || "")}</td>
        <td><select onchange="setShift('${w.id}',this.value)"><option value="GUNDUZ" ${!isNight?"selected":""}>Kunduz</option><option value="GECE" ${isNight?"selected":""}>Kecha</option></select></td>
        <td><select id="st_${w.id}" data-prev="${rec.status}" onchange="statusChanged('${w.id}')">
          <option value="CALISAN" ${rec.status==="CALISAN"?"selected":""}>CALISAN</option>
          <option value="IZINLI" ${rec.status==="IZINLI"?"selected":""}>IZINLI</option>
          <option value="HASTA" ${rec.status==="HASTA"||rec.status==="KASAL"?"selected":""}>HASTA</option>
          <option value="FMS" ${rec.status==="FMS"?"selected":""}>FMS</option>
          <option value="YOK" ${rec.status==="YOK"?"selected":""}>YOK</option>
          <option value="CIKIS" ${rec.status==="CIKIS"?"selected":""}>CIKIS</option>
        </select></td>
        <td>
          <div class="hours-quick">
            <input type="number" id="hr_${w.id}" value="${rec.hours}" min="0" max="24" step="0.5" ${lk!==undefined?'readonly':''} style="width:56px">
            <button type="button" class="hq-btn" onclick="setOneHour('${w.id}',11)" title="Oddiy">11</button>
            <button type="button" class="hq-btn" onclick="setOneHour('${w.id}',15.5)" title="Qo'shimcha">15.5</button>
            <button type="button" class="hq-btn" onclick="setOneHour('${w.id}',9.5)">9.5</button>
            <button type="button" class="hq-btn" onclick="setOneHour('${w.id}',0)">0</button>
          </div>
        </td>
        <td><input type="text" id="nt_${w.id}" value="${esc(rec.note||"")}" class="note-input" placeholder="Izoh"></td>
        <td><div class="inline-transfer"><select id="tr_${w.id}"><option value="">Transfer...</option>${opts}</select>
          <button class="transfer-send" onclick="startTransfer('${w.id}',document.getElementById('tr_${w.id}').value)">→</button></div></td>
      </tr>`;
    });
  });
  tbody.innerHTML = html || `<tr><td colspan="10" style="text-align:center;color:#888;padding:20px">Ishchi yo'q</td></tr>`;
}
function setOneHour(id, h) {
  const el = document.getElementById("hr_" + id);
  if (el && !el.readOnly) { el.value = h; el.dispatchEvent(new Event("change")); }
  // also save if savePuantaj exists on blur - trigger save
  if (typeof saveCurrentPuantajRow === "function") saveCurrentPuantajRow(id);
  else if (typeof statusChanged === "function") { /* hours saved on global save */ }
}


function renderGlobal() {
  const tb=document.getElementById("globalBody"); if(!tb) return;
  const q=(document.getElementById("gSearch")?.value||"").toLowerCase().trim();
  const f=document.getElementById("gObj")?.value||"", sh=document.getElementById("gShift")?.value||"";
  let rows=[];
  OBJECTS.forEach(o=>{
    if(f&&f!==o.id)return;
    JSON.parse(localStorage.getItem("workers_"+o.id)||"[]").filter(w=>!w.exited).forEach(w=>rows.push({o,w}));
  });
  if(sh) rows=rows.filter(({w})=>w.vardiya===sh);
  if(q) rows=rows.filter(({w})=>(w.fio||"").toLowerCase().includes(q)||(w.sicil||"").includes(q)||(w.inn||"").includes(q)||(w.pasport||"").toLowerCase().includes(q));
  document.getElementById("gCount").textContent=rows.length;
  tb.innerHTML=rows.map(({o,w},i)=>`<tr><td>${i+1}</td><td><b class="worker-link" onclick="showProfile('${o.id}','${w.id}')">${esc(w.fio)}</b>${missingData(w).length?' ⚠️':''}</td><td>${esc(w.sicil||"")}</td><td><span class="object-chip">${esc(o.short)}</span></td><td>${esc(w.lavozim||"")}</td><td>${esc(w.ekip||"")}</td><td>${w.vardiya==="GECE"?"Kecha":"Kunduz"}</td></tr>`).join("")||`<tr><td colspan="7" class="transfer-empty">Ma'lumot yo‘q</td></tr>`;
}


(function(){
  const _showSection = window.showSection;
  window.showSection = function(name){
    _showSection(name);
    if(name==="transfer") renderTransfers();
    updateTransferBadge();
  };
  const _initObject = window.initObject;
  window.initObject = function(){
    _initObject();
    getBrigades();
    renderPositionManager();
    renderTransfers();
    updateTransferBadge();
  };
})();



// ===== YOQLAMA QOG'OZI =====
function renderYoqlama() {
  const box = document.getElementById("yoqlamaContent");
  if (!box) return;
  const from = document.getElementById("yoqFrom")?.value || todayStr().slice(0,8)+"01";
  const to = document.getElementById("yoqTo")?.value || todayStr();
  const days = [];
  let d = new Date(from + "T12:00:00");
  const endD = new Date(to + "T12:00:00");
  while (d <= endD) {
    days.push(d.toISOString().slice(0,10));
    d.setDate(d.getDate() + 1);
  }
  if (days.length > 14) { box.innerHTML = "<p style='color:#c00'>Yoqlama uchun maksimum 14 kun tanlang (qog'ozga sig'ishi uchun).</p>"; return; }
  const workers = getWorkers().filter(w => !w.exited);
  const brigades = getBrigades();
  // Group by brigade leader if available, else by ekip name
  const names = ["STAFF", ...brigades.map(b => b.name)];
  workers.forEach(w => { const e = isStaff(w) ? "STAFF" : (w.ekip||"Boshqa"); if (!names.includes(e)) names.push(e); });
  const objName = (OBJECTS.find(o => o.id === currentObj)||{}).short || currentObj || "";
  let html = `<div style="text-align:center;margin-bottom:8px;font-size:14px"><b>${esc(objName)} — YOQLAMA</b><br><small>${from} — ${to}</small></div>`;
  names.forEach(gName => {
    let list = workers.filter(w => (isStaff(w)?"STAFF":(w.ekip||"Boshqa")) === gName)
      .sort((a,b) => (a.fio||"").localeCompare(b.fio||"","uz"));
    if (!list.length) return;
    const leader = brigades.find(b => b.name === gName)?.leader || "";
    const title = gName === "STAFF" ? "STAFF (Ofis)" : (leader ? `${gName} — ${leader}` : gName);
    html += `<div style="font-weight:800;margin:12px 0 4px;font-size:12px;border-bottom:1px solid #333;padding-bottom:2px">${esc(title)} <span style="font-weight:500;color:#666">(${list.length})</span></div>`;
    html += `<table class="yoq-table"><thead><tr><th style="width:28px">№</th><th style="width:70px">Sicil</th><th class="fio">Soyadi / F.I.O</th>${days.map(ds => `<th colspan="2" style="min-width:48px">${ds.slice(8)}.${ds.slice(5,7)}</th>`).join("")}</tr>
    <tr><th></th><th></th><th></th>${days.map(() => `<th style="font-size:9px">±</th><th style="font-size:9px">F.M</th>`).join("")}</tr></thead><tbody>`;
    list.forEach((w,i) => {
      html += `<tr><td>${i+1}</td><td>${esc(w.sicil||"")}</td><td class="fio">${esc(w.fio)}</td>`;
      days.forEach(() => { html += `<td class="yoq-empty"></td><td class="yoq-empty"></td>`; });
      html += `</tr>`;
    });
    html += `</tbody></table>`;
  });
  box.innerHTML = html || "<p>Ishchi yo'q</p>";
}

function printYoqlama() {
  renderYoqlama();
  const content = document.getElementById("yoqlamaContent")?.innerHTML || "";
  // split tables for separate pages if possible
  const w = window.open("", "_blank");
  w.document.write(`<!DOCTYPE html><html><head><title>Yoqlama</title><style>
    body{font-family:Arial,sans-serif;font-size:11px;padding:8px}
    .yoq-table{border-collapse:collapse;width:100%;margin-bottom:16px;page-break-after:always}
    .yoq-table:last-child{page-break-after:auto}
    .yoq-table th,.yoq-table td{border:1px solid #000;padding:2px 4px;text-align:center}
    .yoq-table .fio{text-align:left;font-size:10px}
    h3,div[style*="font-weight:800"]{margin:6px 0 2px;page-break-after:avoid}
  </style></head><body>${content}<script>window.onload=()=>window.print()</script></body></html>`);
  w.document.close();
}

function fillKCFWorkers() {
  const sel = document.getElementById("kcfWorker");
  if (!sel) return;
  const active = getWorkers().filter(w => !w.exited);
  const exited = getExits();
  sel.innerHTML = `<option value="">— Tanlang —</option>` +
    active.map(w => `<option value="a_${w.id}">${esc(w.fio)} (faol)</option>`).join("") +
    exited.map(w => `<option value="e_${w.id}">${esc(w.fio)} (chiqqan)</option>`).join("");
  renderKCF();
}
function renderKCF() {
  const box = document.getElementById("kcfContent");
  if (!box) return;
  const v = document.getElementById("kcfWorker")?.value || "";
  if (!v) { box.innerHTML = "<p style='color:#888'>Ishchini tanlang</p>"; return; }
  let w = null, isExit = false;
  if (v.startsWith("a_")) w = getWorkers().find(x => x.id === v.slice(2));
  else { w = getExits().find(x => x.id === v.slice(2)); isExit = true; }
  if (!w) { box.innerHTML = "<p>Topilmadi</p>"; return; }
  const obj = OBJECTS.find(o => o.id === currentObj) || {};
  const today = todayStr();
  box.innerHTML = `<div class="kcf-sheet" id="kcfPrintArea">
    <h2>PERSONEL İŞE GİRİŞ / ÇIKIŞ FORMU — ${esc(obj.short || obj.name || "")}</h2>
    <div class="kcf-grid">
      <div><label>Ad Soyad:</label> <span>${esc(w.fio)}</span></div>
      <div><label>Sicil No:</label> <span>${esc(w.sicil || "")}</span></div>
      <div><label>Görevi:</label> <span>${esc(w.lavozim || w.dolzhnost || "")}</span></div>
      <div><label>İşe Başlama Tarihi:</label> <span>${esc(w.startDate || w.pasport_berilgan || "—")}</span></div>
      <div><label>Pasaport Seri No:</label> <span>${esc(w.pasport || "")}</span></div>
      <div><label>İsten Çıkış Tarihi:</label> <span>${isExit ? esc(w.exitDate || today) : "—"}</span></div>
      <div><label>Pasaportu Veren Ülke:</label> <span>${esc(w.millat || "")}</span></div>
      <div><label>Saat Ücreti:</label> <span></span></div>
      <div><label>Grubu:</label> <span>${esc(w.ekip || "")}</span></div>
      <div><label>Tekrar İşe Girilebilirlik:</label> <span>${w.blacklisted ? "❌ HAYIR (qora ro'yxat)" : "✓ Evet"}</span></div>
      <div style="grid-column:1/-1"><label>İsten Ayrılma Sebebi:</label> <span>${esc(w.reason || "")}</span></div>
      <div style="grid-column:1/-1"><label>Кем выдан паспорт:</label> <span>${esc(w.pasport_beruvchi || "")}</span></div>
      <div><label>INN:</label> <span>${esc(w.inn || "")}</span></div>
      <div><label>SNILS:</label> <span>${esc(w.snils || "")}</span></div>
      <div><label>Ruxsatnoma/Patent:</label> <span>${esc(w.patent || "")}</span></div>
      <div><label>Patent tugash:</label> <span>${esc(w.patent_tugash || "")}</span></div>
    </div>
    <div class="kcf-sign">
      <div>Kamp Amiri Giriş Onayı<br><br>İmza / Not</div>
      <div>Ambar Şefi Giriş Onayı<br><br>İmza / Not</div>
      <div>Personel Soft Giriş Onayı<br><br>İmza / Not</div>
      <div>Doktor<br><br></div>
      <div>Narkotik Kontrol<br><br></div>
      <div>Cilt Kontrol<br><br></div>
      <div>Giriş Kartı Onayı<br><br></div>
      <div>Güvenlik Onayı<br><br></div>
      <div>Çıkış Onayı<br><br></div>
    </div>
  </div>`;
}
function printKCF() {
  renderKCF();
  const area = document.getElementById("kcfPrintArea");
  if (!area) return;
  const w = window.open("", "_blank");
  w.document.write(`<!DOCTYPE html><html><head><title>Giriş/Çıkış Formu</title><style>
    body{font-family:Arial,sans-serif;padding:12px}
    .kcf-sheet{border:2px solid #1e3a5f;padding:16px}
    h2{text-align:center;font-size:15px}
    .kcf-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;margin-bottom:12px;font-size:12px}
    .kcf-grid label{font-weight:700}
    .kcf-grid span{border-bottom:1px solid #666;min-height:16px;display:inline-block;min-width:100px}
    .kcf-sign{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:16px}
    .kcf-sign div{border:1px dashed #666;min-height:55px;padding:4px;text-align:center;font-size:10px}
  </style></head><body>${area.outerHTML}<script>window.onload=()=>window.print()</script></body></html>`);
  w.document.close();
}

// Auto-open KCF after exit
const _origConfirmExit = typeof confirmExit === "function" ? confirmExit : null;

// ===== Ishchi fayllari (IndexedDB) =====
const WFILE_DB = "flex_worker_files";
function openWFileDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(WFILE_DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore("files", { keyPath: "key" });
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function getWorkerFiles(objId, wid) {
  try {
    const db = await openWFileDB();
    return new Promise((res) => {
      const tx = db.transaction("files", "readonly");
      const req = tx.objectStore("files").get(objId + "_" + wid);
      req.onsuccess = () => res((req.result && req.result.items) || []);
      req.onerror = () => res([]);
    });
  } catch(e) { return []; }
}
async function saveWorkerFiles(objId, wid, items) {
  const db = await openWFileDB();
  return new Promise((res, rej) => {
    const tx = db.transaction("files", "readwrite");
    tx.objectStore("files").put({ key: objId + "_" + wid, items });
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
  });
}
async function uploadWorkerFiles(objId, wid) {
  const inp = document.getElementById("wfile_inp_" + wid);
  if (!inp || !inp.files.length) { alert("Fayl tanlang"); return; }
  const items = await getWorkerFiles(objId, wid);
  for (const f of [...inp.files]) {
    const buf = await f.arrayBuffer();
    items.push({ name: f.name, type: f.type, size: f.size, data: buf, at: Date.now() });
  }
  await saveWorkerFiles(objId, wid, items);
  inp.value = "";
  toast(items.length + " ta fayl saqlandi ✓");
  renderWorkerFilesUI(objId, wid);
}
async function renderWorkerFilesUI(objId, wid) {
  const box = document.getElementById("wfiles_" + wid);
  if (!box) return;
  const items = await getWorkerFiles(objId, wid);
  box.innerHTML = items.map((f,i) => `<div style="display:flex;gap:6px;align-items:center;margin:2px 0">
    <span>📄 ${esc(f.name)}</span>
    <button class="btn-sm" onclick="downloadWorkerFile('${objId}','${wid}',${i})">Ochish</button>
    <button class="btn-sm" style="color:#c00" onclick="delWorkerFile('${objId}','${wid}',${i})">×</button>
  </div>`).join("") || "<span style='color:#888'>Fayl yo'q</span>";
}
async function downloadWorkerFile(objId, wid, i) {
  const items = await getWorkerFiles(objId, wid);
  const f = items[i]; if (!f) return;
  const blob = new Blob([f.data], { type: f.type || "application/octet-stream" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = f.name; a.click();
}
async function delWorkerFile(objId, wid, i) {
  if (!confirm("Fayl o'chirilsinmi?")) return;
  const items = await getWorkerFiles(objId, wid);
  items.splice(i, 1);
  await saveWorkerFiles(objId, wid, items);
  renderWorkerFilesUI(objId, wid);
}

// ===== Soat kartochkalari (kesib tarqatish uchun) =====
function printHourCards(month) {
  month = month || document.getElementById("bodroMonth")?.value || todayStr().slice(0,7);
  const [y,m] = month.split("-").map(Number);
  const dim = new Date(y, m, 0).getDate();
  const workers = getWorkers().filter(w => !w.exited);
  const bodro = JSON.parse(localStorage.getItem(key("bodro_"+month)) || "{}");
  const obj = (OBJECTS.find(o => o.id === currentObj)||{}).short || currentObj || "";
  // group by brigade
  const groups = {};
  workers.forEach(w => {
    const g = isStaff(w) ? "STAFF" : (w.ekip || "Boshqa");
    (groups[g] = groups[g] || []).push(w);
  });
  let cards = "";
  Object.keys(groups).forEach(gName => {
    const list = groups[gName].sort((a,b)=>(a.fio||"").localeCompare(b.fio||"","uz"));
    list.forEach((w, idx) => {
      const days = bodro[w.id] || {};
      let total = 0;
      let cells = "";
      for (let d = 1; d <= dim; d++) {
        const v = parseFloat(days[d]) || 0;
        total += v;
        const ds = String(d).padStart(2,"0") + "." + String(m).padStart(2,"0");
        // highlight if 8 or special (like photo red)
        const hl = (v === 8 || v === 16) ? "background:#fecaca;" : "";
        cells += `<td style="border:1px solid #999;padding:2px 4px;text-align:center;font-size:10px;${hl}"><div style="font-size:8px;color:#666">${ds}</div><b>${v || ""}</b></td>`;
      }
      cards += `<div class="hour-card" style="page-break-inside:avoid;border:1px solid #333;padding:6px 8px;margin:4px 0;font-family:Arial,sans-serif;font-size:11px">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px">
          <span><b>Таб. №:</b> ${esc(w.sicil||"")} / <b>Ф.И.О.:</b> ${esc(w.fio)}</span>
          <span><b>${esc(obj)}</b> · ${esc(gName)}</span>
        </div>
        <table style="border-collapse:collapse;width:100%"><tr>${cells}</tr></table>
        <div style="text-align:right;margin-top:3px;font-weight:700">TOPLAM SAAT: ${total.toFixed(1)}</div>
      </div>`;
    });
  });
  const w = window.open("", "_blank");
  w.document.write(`<!DOCTYPE html><html><head><title>Soat kartochkalari ${month}</title>
  <style>body{margin:8px} .hour-card{break-inside:avoid} @media print{.hour-card{margin:2px 0}}</style>
  </head><body>${cards}<script>window.onload=()=>window.print()</script></body></html>`);
  w.document.close();
}
