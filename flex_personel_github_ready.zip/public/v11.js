/* =====================================================================
   v11 — JOIS puantaj brigadalari, faqat ruscha lavozimlar, davlat/hujjat
   tanlovi, patent cheklari, zamonaviy bodro, soat kartochkalari, yoqlama
   (extra.js dan keyin yuklanadi, eski funksiyalarni almashtiradi)
   ===================================================================== */
const V11_ROSTER = [["Айдын Эрсин","400028","НАЧАЛЬНИК ГРУППЫ ПО МЕХАНИЧЕСКИМ РАБОТАМ","STAFF","GUNDUZ"],["Уроков Фаррух Исматович","400651","БРИГАДИР ПО МЕХАНИЧЕСКИМ РАБОТАМ (Э&М)","STAFF","GUNDUZ"],["Маматалиев Бахтиёр Бобирджонович","300012","ТАБЕЛЬЩИК","STAFF","GUNDUZ"],["Аношкин Владислав Алексеевич","200725","ИНЖЕНЕР ПТО","STAFF","GUNDUZ"],["Лютько Дарья Константиновна","200735","ИНЖЕНЕР ПТО","STAFF","GUNDUZ"],["Матросова Юлия Николаевна","200742","ИНЖЕНЕР ПТО","STAFF","GUNDUZ"],["Сары Назлы","200705","ИНЖЕНЕР-ПРОЕКТИРОВЩИК МЕХАНИЧЕСКИХ СИСТЕМ","STAFF","GUNDUZ"],["Каландаров Абутжон Худайберганович","200723","БРИГАДИР ПО МЕХАНИЧЕСКИМ РАБОТАМ (Э&М)","STAFF","GUNDUZ"],["Эроглу Камбер","200731","ТЕХНИК-МЕХАНИК УЧАСТКА","STAFF","GUNDUZ"],["Чарыев Сердар","400755","БРИГАДИР ПО МЕХАНИЧЕСКИМ РАБОТАМ (Э&М)","STAFF","GUNDUZ"],["Чакмак Салих","200082","НАЧАЛЬНИК ГРУППЫ ПО МЕХАНИЧЕСКИМ РАБОТАМ","STAFF","GUNDUZ"],["Чакмак Фарук","200086","БРИГАДИР ПО МЕХАНИЧЕСКИМ РАБОТАМ (Э&М)","STAFF","GUNDUZ"],["Жураев Зохид Абдухалил Угли","200721","НАЧАЛЬНИК ГРУППЫ СКЛАДА","STAFF","GUNDUZ"],["Дурягин Антон Анатольевич","300549","РУКОВОДИТЕЛЬ ОТДЕЛА СНАБЖЕНИЯ","STAFF","GUNDUZ"],["Мишина Ольга Ивановна","200000","НАЧАЛЬНИК ГРУППЫ ЗАКУПОК","STAFF","GUNDUZ"],["Сельчук Сезер","200728","ТЕХНИК ОТДЕЛА ПРОЕКТИРОВАНИЯ (МЕХАНИКА)","STAFF","GUNDUZ"],["Бабаева Рена Айдын кызы","Yenigiris","РУКОВОДИТЕЛЬ ОТДЕЛА СНАБЖЕНИЯ","STAFF","GUNDUZ"],["Абдураупов Сахобиддин Шерали Угли","200750","ТАБЕЛЬЩИК","STAFF","GECE"],["Аминов Давлатёр Олимбоевич","401613","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Жураев Акбар Абдикаюм Угли","400995","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Кадирбердиев Шерзодбек Алишер Угли","400723","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Кузиев Жамшид Фарход Угли","401552","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Кутибаев Оралбай Кеунимжаевич","400806","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Мадрахимов Жушкин Умарбек Угли","401250","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Режапов Рузибой Кулмумин Угли","401528","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Хусинов Пулатбек Рузибой Угли","401274","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Хушназаров Тура Ачилович","400298","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Шаназаров Худояр Ихтиёр Угли","401412","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Ярматов Сардорбек Махмарежаб Угли","400609","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Мардаев Халим Абзаирович","400335","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Эщанов Бекзод Бабажонович","400927","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Ибрагимов Асадбек Ахмаджон Угли","400808","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Холмаматов Рамазон Норкул Угли","401622","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Авезимбетов Расул Ачилович","401144","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Примкулов Самандар Ашир Угли","401623","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Юлдашев Сапарбой Олланазар Угли","400792","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Айитбаев Сардор Сабурбаевич","401660","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Буриев Борат Холмамат Угли","401621","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Кадирбердиев Хушнудбек Алишер Угли","400809","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Донияров Канатбек Абай угли","401684","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Донияров Бекзодбек Абай угли","401685","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GUNDUZ"],["Кадирбердиев Исроил Улугбекович","400847","МОНТАЖНИК ТРУБ","КАЛАНДАРОВ АБУТЖОН","GECE"],["Абдуллаев Мансур","401264","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Какаев Довран","400802","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Алламырадов Шаназар","401060","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Алламырадов Шатлык","401061","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Алтыев Мерген","401178","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Аразов Тагангелди","401236","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Атаев Мердан","401064","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Атаназаров Мурад","401107","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Ахмедов Юсупбай","401265","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Бабаев Бабамырат","401067","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Байрамгелдиев Сулейман","401198","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Байрамгылыджов Байрамгылыч","401239","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Байрамгылыджов Мухаммет","401244","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Бараков Тагандурды","401068","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Башимов Хайдар","401192","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Бегмурадов Нургелди","401258","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Бекманов Ихлас","400760","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Гарлыев Ашырмухаммет","400821","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Гелдимырадов Шатлык","401459","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Гурбанязов Сапармырат","401257","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Гутлыев Кервен","400797","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Дадебаев Перман","401261","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Дайханов Жовхер","401260","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Джумагелдиев Гурбангелди","401197","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Джумагелдиев Гурбанмырат","401193","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Джумагелдиев Сапар","401199","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Джумаев Айытмырат","401070","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Дурдыев Новрузгелди","401194","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Илалыев Новруз","401195","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Исмайилов Давранбек","400754","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Ишметов Фархад","400765","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Ишметов Шихибай","400764","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Какаджанов Джелил","401072","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Какаджанов Довлетгелди","401073","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Матиев Дурдыбай","401077","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Матюсупов Какаджан","401103","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Мередов Акмырат","401243","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Мухамметмырадов Ханджар","401494","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Нурметов Алишер","401085","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Нурягдыев Полат","401475","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Ораев Башим","401179","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Ораздурдыев Гарлы","401230","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Оразмухаммедов Даянч","401086","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Отузов Гелдимурат","401256","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Пендилиев Азат","401241","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Пендилиев Мекан","401111","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Поладов Ныязберди","400798","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Полатов Тойлы","400800","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Раметов Ихтияр","400767","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Розметов Азимбай","400753","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Сабуров Бахтияр","401263","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Сапаров Айдо","401221","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Татыков Бердибай","401255","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Туйлиев Ашырмырат","401259","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Улджаев Довран","401453","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Халлыев Тойлы","401242","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Хошаев Мырат","401102","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Хыдыров Бабамырат","401112","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Чарыев Бегенч","400772","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Матиев Махмут","400763","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Маммедов Омар","400770","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Матдурдыев Бегенч","401268","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Оразгулыев Дурдымырат","401481","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Атаев Язмухаммет","401238","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Тогсаев Мейлис","401109","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Чарыев Гуванч","401094","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Чарыев Дортгулы","401515","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Чашемов Ыхлас","401096","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Шапиев Ашыр","401097","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Шахымерданов Хемра","401113","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Шерапов Рамиль","401098","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Эсенов Нурмырат","401105","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Юлдашов Махмуд","401104","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Рейимбаев Хамиджан","401089","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Эркинбаев Жуманияз","401099","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GUNDUZ"],["Эсенов Оразгелди","400759","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GECE"],["Аймырадов Айназар","401058","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GECE"],["Аллакулыев Атамырат","400771","МОНТАЖНИК ТРУБ","ЧАРЫЕВ СЕРДАР","GECE"],["Абдирахимов Эргаш Ботир Угли","400593","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Хидиров Икромжон Рузимурод Угли","401143","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Араббоев Арабшох Азимбек Угли","401172","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Буриев Курбанмурат Исламович","401149","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Бердиеров Анвар Тоштемурович","400860","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Одилов Бекмурод Туйчиевич","400708","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Караев Панжи Азизхонович","400814","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Кузиев Эркин Туропович","400655","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Милтиков Фахриддин Халимжонович","401568","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Ниёзов Илхом Турсунбоевич","401018","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Рузиев Журабек Шодиевич","401564","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Сайидкулов Бешим Рахматович","401171","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Сафаров Уткиржон Хуррамович","401046","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Темиров Шариф Бухорович","401215","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Уроков Асилбек Нортура Угли","400936","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Чуянов Алишер Нурали Угли","401173","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Шодиев Жавохир Бобир Угли","401630","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Хамроев Илхом Фахриддинович","401671","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Шодмонов Зокиржон Шозотович","400813","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Сайитмуродов Бехруз Зойиржон Угли","400928","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Собиров Байрамали Саидкул Угли","400664","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Абраев Феруз Хакбердиевич","400827","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Абдирахимов Илхом Ботир Угли","401658","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Нодиров Ёдгор Хакберди Угли","401673","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Уринов Дониёр Кахрамон Угли","401672","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GUNDUZ"],["Хидиров Шохрух Деконбой угли","Yenigiris","МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА","УРОКОВ ФАРРУХ","GECE"],["Жураев Зокир Абдухалилович","400741","РАЗДАТЧИК МАТЕРИАЛОВ СКЛАДА","ЖУРАЕВ ЗОХИД","GUNDUZ"],["Номозов Аброр Турдимуротович","401027","РАЗДАТЧИК МАТЕРИАЛОВ СКЛАДА","ЖУРАЕВ ЗОХИД","GUNDUZ"],["Эржонов Болтабой Давлатбоевич","400994","РАЗДАТЧИК МАТЕРИАЛОВ СКЛАДА","ЖУРАЕВ ЗОХИД","GECE"]];   // [F.I.O, sicil, lavozim, ekip, vardiya] — 05.10.2026 puantaji
const V11_BR = [
  { name:"КАЛАНДАРОВ АБУТЖОН", group:"Mexanik",      leader:"Каландаров Абутжон Худайберганович", def:"abut" },
  { name:"ЧАРЫЕВ СЕРДАР",      group:"Mexanik",      leader:"Чарыев Сердар",                       def:"serd" },
  { name:"УРОКОВ ФАРРУХ",      group:"Xavolandirma", leader:"Уроков Фаррух Исматович",             def:"farr" },
  { name:"ЖУРАЕВ ЗОХИД",       group:"Ambar",        leader:"Жураев Зохид Абдухалил Угли",         def:"zohi" }
];
const V11_OLD_BR = ["AMBAR","XAVOLANDIRMA","MEXANIK"];
const V11_POS = {
  Mexanik:"МОНТАЖНИК ТРУБ",
  Xavolandirma:"МОНТАЖНИК СИСТЕМ ВЕНТИЛЯЦИИ И КОНДИЦИОНИРОВАНИЯ ВОЗДУХА",
  Ambar:"РАЗДАТЧИК МАТЕРИАЛОВ СКЛАДА"
};
const V11_STAFF_POS = [
  "НАЧАЛЬНИК ГРУППЫ ПО МЕХАНИЧЕСКИМ РАБОТАМ","БРИГАДИР ПО МЕХАНИЧЕСКИМ РАБОТАМ (Э&М)","ТАБЕЛЬЩИК","ИНЖЕНЕР ПТО",
  "ИНЖЕНЕР-ПРОЕКТИРОВЩИК МЕХАНИЧЕСКИХ СИСТЕМ","ТЕХНИК-МЕХАНИК УЧАСТКА","НАЧАЛЬНИК ГРУППЫ СКЛАДА",
  "РУКОВОДИТЕЛЬ ОТДЕЛА СНАБЖЕНИЯ","НАЧАЛЬНИК ГРУППЫ ЗАКУПОК","ТЕХНИК ОТДЕЛА ПРОЕКТИРОВАНИЯ (МЕХАНИКА)"
];
const V11_MAIN_COUNTRIES = ["УЗБЕКИСТАН","ТАДЖИКИСТАН","АЗЕРБАЙДЖАН","ТУРКМЕНИСТАН","ТУРЦИЯ","КАЗАХСТАН","КЫРГЫЗСТАН","БЕЛАРУСЬ","АРМЕНИЯ","РОССИЯ"];
const V11_MILLAT = { "УЗБЕКИСТАН":"o'zbek","ТАДЖИКИСТАН":"tojik","АЗЕРБАЙДЖАН":"ozarbayjon","ТУРКМЕНИСТАН":"turkman","ТУРЦИЯ":"turk","КАЗАХСТАН":"qozoq","КЫРГЫЗСТАН":"qirg'iz","БЕЛАРУСЬ":"belorus","АРМЕНИЯ":"arman","РОССИЯ":"rus" };
const V11_DOCS = [["Миграционный учёт","Миграционный учёт"],["Патент","Патент"],["РВП","РВП"],["ВНЖ","ВНЖ"],["ВКС","ВКС"],["РНР","Разрешение на работу"],["Гражданство РФ","Гражданство РФ"]];
const V11_NODOC = ["","РФ","ПАСПОРТ","Гражданство РФ"];
const V11_DOCNAME = { "Патент":"Patent","Ожидание патент":"Patent (kutilmoqda)","РНР":"Разрешение на работу","ВКС":"ВКС","ВНЖ":"ВНЖ","РВП":"РВП","Миграционный учёт":"Migratsion uchyot" };
const v11pad = n => String(n).padStart(2, "0");
const v11Num = v => { const x = parseFloat(v); return isNaN(x) ? 0 : x; };

// GROUP_POS_* const obyektlari — faqat ruscha lavozim
GROUP_POS_UZ.Ambar = GROUP_POS_RU.Ambar = V11_POS.Ambar;
GROUP_POS_UZ.Xavolandirma = GROUP_POS_RU.Xavolandirma = V11_POS.Xavolandirma;
GROUP_POS_UZ.Mexanik = GROUP_POS_RU.Mexanik = V11_POS.Mexanik;

/* ---------- Davlat turini aniqlash ---------- */
function v11Country(c) {
  c = String(c || "").toLowerCase().trim();
  if (!c) return "";
  if (/росси|russia|^рф$|^rus$|русский/.test(c)) return "RU";
  if (/казах|qozoq|kazakh|кыргыз|qirg|kyrgyz|беларус|belar|белорус|армен|armen|belarus|arman/.test(c)) return "EAEU";
  if (/узбек|uzbek|o'zbek|oʻzbek|таджик|tajik|tojik|азербайджан|azerbay|ozarbay/.test(c)) return "PATENT";
  if (/туркмен|turkmen|turkman/.test(c)) return "PERMIT";
  if (/турк|turk|türk|турц/.test(c)) return "PERMIT";
  return "OTHER";
}
function v11IsPatent(w) {
  if (w.exited) return false;
  const dt = w.doc_type || "";
  if (dt === "Патент" || dt === "Ожидание патент") return true;
  if (dt && dt !== "Патент" && dt !== "Ожидание патент") return false;
  if (v11Country(w.fuqarolik) === "RU") return false;
  return v11Country(w.fuqarolik || w.davlat || w.millat) === "PATENT";
}
function getDocKind(w) {
  const dt = w.doc_type || "";
  if (dt === "Патент" || dt === "Ожидание патент") return "patent";
  if (["РНР","ВКС","ВНЖ","РВП","Миграционный учёт"].includes(dt)) return "permit";
  if (dt === "РФ" || dt === "ПАСПОРТ" || dt === "Гражданство РФ") return "none";
  if (dt) return "none";
  // Fuqarolik ustun: RF fuqarosi bo'lsa — faqat pasport
  const fq = v11Country(w.fuqarolik || "");
  if (fq === "RU") return "none";
  if (fq === "EAEU") return "none";
  const c = v11Country(w.fuqarolik || w.davlat || w.millat);
  if (c === "RU" || c === "EAEU") return "none";
  if (c === "PERMIT") return "permit";
  return "patent";
}
function missingData(w) {
  const m = [], kind = getDocKind(w);
  if (kind !== "none") {
    if (w.doc_type === "Миграционный учёт") { if (!w.patent_berilgan || !w.patent_tugash) m.push("Uchyot sanalari"); }
    else if (!w.patent || !w.patent_berilgan || !w.patent_tugash) m.push((V11_DOCNAME[w.doc_type] || (kind === "patent" ? "Patent" : "Hujjat")) + " ma'lumoti");
  }
  if (!w.inn) m.push("INN");
  if (!w.snils) m.push("SNILS");
  if (!w.pasport) m.push("Pasport");
  return m;
}

/* ---------- Lavozimlar (faqat ruscha, bitta ro'yxat) ---------- */
function getPositionLists() {
  let r = null;
  try { r = JSON.parse(localStorage.getItem("flex_position_lists_v11") || "null"); } catch (e) {}
  if (!r || !Array.isArray(r.direct) || !Array.isArray(r.staff)) {
    const mk = ru => ({ uz: ru, ru });
    r = { direct: Object.values(V11_POS).map(mk), staff: V11_STAFF_POS.map(mk) };
    localStorage.setItem("flex_position_lists_v11", JSON.stringify(r));
  }
  return r;
}
function v11SavePos(r) { localStorage.setItem("flex_position_lists_v11", JSON.stringify(r)); }
function renderPositionManager() {
  const box = document.getElementById("positionManager"); if (!box) return;
  const L = getPositionLists();
  const row = (x, t, i) => `<div class="position-edit-row v11-pos-row"><input id="pos_${t}_ru_${i}" value="${esc(x.ru)}"><button class="btn-sm" onclick="saveOnePosition('${t}',${i})">Saqlash</button><button class="btn-sm" style="background:#fee2e2;color:#991b1b" onclick="deletePosition('${t}',${i})">🗑</button></div>`;
  const grp = (t, title) => `<div class="position-edit-group"><h3>${title}</h3>${L[t].map((x, i) => row(x, t, i)).join("")}
      <div class="position-edit-row v11-pos-row" style="margin-top:8px;background:#f0fdf4;padding:8px;border-radius:8px"><input id="pos_new_${t}_ru" placeholder="Yangi lavozim (ruscha)"><button class="btn-main btn-sm" onclick="addPosition('${t}')">＋ Qo'shish</button></div></div>`;
  box.innerHTML = grp("direct", "Direkt — ishchilar") + grp("staff", "Endirekt — STAFF") +
    `<button class="btn-sec btn-sm" onclick="resetPositions()">Standart lavozimlarni tiklash</button>
     <p class="section-desc" style="margin-top:8px">Lavozimlar faqat ruscha yoziladi (puantajdagidek). Nomini o'zgartirsangiz, shu lavozimdagi ishchilarda ham almashadi.</p>`;
}
function saveOnePosition(type, i) {
  const L = getPositionLists(), ru = document.getElementById(`pos_${type}_ru_${i}`)?.value.trim();
  if (!ru) { alert("Lavozim nomini kiriting."); return; }
  const old = L[type][i].ru; L[type][i] = { uz: ru, ru }; v11SavePos(L);
  if (old !== ru) { const ws = getWorkers(); ws.forEach(w => { if (w.lavozim === old) { w.lavozim = ru; w.dolzhnost = ru; } }); saveWorkers(ws); }
  renderPositionManager(); onTurChange(); toast("Lavozim saqlandi ✓");
}
function addPosition(type) {
  const ru = document.getElementById(`pos_new_${type}_ru`)?.value.trim();
  if (!ru) { alert("Lavozim nomini kiriting"); return; }
  const L = getPositionLists(); if (L[type].some(x => x.ru.toLowerCase() === ru.toLowerCase())) { alert("Bu lavozim bor"); return; }
  L[type].push({ uz: ru, ru }); v11SavePos(L); renderPositionManager(); onTurChange(); toast("Lavozim qo'shildi ✓");
}
function deletePosition(type, i) {
  const L = getPositionLists();
  if (L[type].length <= 1) { alert("Kamida 1 ta lavozim qolishi kerak"); return; }
  if (!confirm(`"${L[type][i].ru}" o'chirilsinmi?`)) return;
  L[type].splice(i, 1); v11SavePos(L); renderPositionManager(); onTurChange(); toast("O'chirildi ✓");
}
function resetPositions() {
  if (!confirm("Standart lavozimlar tiklansinmi?")) return;
  localStorage.removeItem("flex_position_lists_v11"); getPositionLists(); renderPositionManager(); onTurChange(); toast("Standart lavozimlar tiklandi ✓");
}
function quickEditPosition(id) {
  const w = getWorkers().find(x => x.id === id); if (!w) return;
  const L = getPositionLists(), arr = isStaff(w) ? L.staff : L.direct;
  const ans = prompt("Lavozimni tanlang (raqam):\n\n" + arr.map((x, i) => `${i + 1}. ${x.ru}`).join("\n"), String(Math.max(1, arr.findIndex(x => x.ru === w.lavozim) + 1)));
  if (ans === null) return; const n = parseInt(ans, 10);
  if (!(n >= 1 && n <= arr.length)) { alert("Ro'yxatdagi raqamni tanlang."); return; }
  const list = getWorkers(), t = list.find(x => x.id === id); t.lavozim = arr[n - 1].ru; t.dolzhnost = arr[n - 1].ru;
  saveWorkers(list); renderWorkers(); toast("Lavozim yangilandi ✓");
}

/* ---------- Brigadalar ---------- */
function getBrigades() {
  let raw = null;
  try { raw = JSON.parse(localStorage.getItem(key("brigades")) || "null"); } catch (e) {}
  if (!Array.isArray(raw)) raw = [];
  if (!localStorage.getItem(key("v11_br"))) {
    const defs = (currentObj === "jois" ? V11_BR : DEFAULT_BR).map(x => ({ ...x }));
    const names = new Set(defs.map(x => x.name)), act = getWorkers().filter(w => !w.exited);
    raw.forEach(x => {
      if (!x || !x.name) return;
      if (names.has(x.name)) { const d = defs.find(y => y.name === x.name); if (d && x.leader && currentObj !== "jois") d.leader = x.leader; return; }
      if (currentObj === "jois" && V11_OLD_BR.includes(x.name) && !act.some(w => w.ekip === x.name)) return;
      defs.push({ name:String(x.name), group:x.group || "Mexanik", leader:x.leader || "", custom:true }); names.add(x.name);
    });
    localStorage.setItem(key("brigades"), JSON.stringify(defs));
    localStorage.setItem(key("v11_br"), "1");
    return defs;
  }
  return raw.filter(x => x && x.name).map(x => ({ name:String(x.name), group:x.group || "Mexanik", leader:x.leader || "", custom:!!x.custom, def:x.def }));
}
function brigadeGroup(name) {
  const x = getBrigades().find(b => b.name === name);
  return x ? (x.group || "Mexanik") : "Mexanik";
}
function v11Migrate() {
  if (currentObj !== "jois" || localStorage.getItem(key("v11_mig"))) return;
  const list = getWorkers(), map = new Map();
  list.filter(w => !w.exited).forEach(w => map.set(normFio(w.fio), w));
  V11_ROSTER.forEach(([fio, sicil, lav, ekip, vard], idx) => {
    const staff = ekip === "STAFF"; let w = map.get(normFio(fio));
    if (!w) {
      w = { id:"p" + String(sicil).replace(/\W/g, "") + "_" + idx, fio, sicil:String(sicil), lavozim:lav, dolzhnost:lav, ekip, vardiya:vard, tur:staff ? "ENDIREKT" : "DIREKT", exited:false };
      const e = typeof dbFind === "function" ? dbFind(fio) : null; if (e) fillWorker(w, e);
      list.push(w);
    } else {
      w.lavozim = lav; w.tur = staff ? "ENDIREKT" : "DIREKT"; w.ekip = staff ? "STAFF" : ekip;
      if (!w.sicil) w.sicil = String(sicil);
    }
  });
  saveWorkers(list);
  localStorage.setItem(key("v11_mig"), "1");
}

const V11_UZ2RU = { "ambar ishchisi":V11_POS.Ambar, "kladovchik":V11_POS.Ambar, "кладовщик":V11_POS.Ambar, "xavolandirmachi":V11_POS.Xavolandirma, "mexanik montajchi":V11_POS.Mexanik,
  "mexanik brigadiri":"БРИГАДИР ПО МЕХАНИЧЕСКИМ РАБОТАМ (Э&М)", "xavolandirma brigadiri":"БРИГАДИР ПО ВЕНТИЛЯЦИОННЫМ РАБОТАМ", "ambar sefi":"НАЧАЛЬНИК ГРУППЫ СКЛАДА" };
function v11NormLavozim() {   // eski o'zbekcha lavozim nomlari -> ruscha (har obyektda bir marta)
  if (localStorage.getItem(key("v11_lav"))) return;
  const ws = getWorkers(); let ch = false;
  ws.forEach(w => { const r = V11_UZ2RU[String(w.lavozim || "").toLowerCase().trim()]; if (r) { w.lavozim = r; w.dolzhnost = r; ch = true; } });
  if (ch) saveWorkers(ws);
  localStorage.setItem(key("v11_lav"), "1");
}
function v11Groups(workers) {
  const brs = getBrigades(), map = new Map();
  workers.forEach(w => { const g = isStaff(w) ? "STAFF" : (w.ekip || "Boshqa"); if (!map.has(g)) map.set(g, []); map.get(g).push(w); });
  const names = ["STAFF", ...brs.map(b => b.name)]; map.forEach((_, k) => { if (!names.includes(k)) names.push(k); });
  const cmp = (a, b) => (a.fio || "").localeCompare(b.fio || "", "ru");
  return names.filter(n => map.has(n) && map.get(n).length).map(n => {
    const l = map.get(n), day = l.filter(w => w.vardiya !== "GECE").sort(cmp), night = l.filter(w => w.vardiya === "GECE").sort(cmp), b = brs.find(x => x.name === n);
    return { name:n, title:n === "STAFF" ? "STAFF (Ofis)" : n, leader:b ? b.leader : "", pos:b ? (V11_POS[b.group] || "") : "", day, night, list:[...day, ...night] };
  });
}
function renderBrigades() {
  const box = document.getElementById("brigadeCards"); if (!box) return;
  const br = getBrigades(), missing = currentObj === "jois" ? V11_BR.filter(d => !br.some(b => b.def === d.def)) : [];
  box.innerHTML = `<div class="brigade-admin-bar"><button class="btn-main btn-sm" onclick="addBrigadeUI()">＋ Yangi brigada qo‘shish</button>${missing.length ? `<button class="btn-sec btn-sm" onclick="v11RestoreBrigades()">↺ O‘chirilgan brigadalarni tiklash (${missing.length})</button>` : ""}<span class="muted">Brigada nomini ✏️ bilan o‘zgartirish mumkin. Brigadir faqat STAFF xodimlaridan.</span></div>` +
    br.map((b, i) => {
      const mem = brigadeMembers(b), leader = b.leader || "Tayinlanmagan";
      return `<div class="brigade-card fixed-brigade-card"><div class="brigade-top"><div><span class="brigade-group">${esc(V11_POS[b.group] || b.group || "")}</span><h3>${esc(b.name)}</h3></div><span class="brigade-count">${mem.length} kishi</span></div>
      <div class="brigade-leader">👤 Brigadir: <b>${esc(leader)}</b></div>
      <div class="brigade-members">${mem.slice(0, 8).map(w => `<span>${esc(w.fio)}</span>`).join("") || '<span class="muted">Hali ishchi qo‘shilmagan</span>'}${mem.length > 8 ? `<span class="muted">+${mem.length - 8} ta</span>` : ""}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn-sec btn-sm" onclick="v11RenameBrigade(${i})">✏️ Nomi</button><button class="btn-sec btn-sm" onclick="editBrigadeUI(${i})">Brigadir</button><button class="btn-main btn-sm" onclick="manageBrigadeMembers(${i})">Odamlarni boshqarish</button><button class="btn-sec btn-sm" style="background:#fee2e2;color:#991b1b" onclick="deleteBrigade(${i})">🗑</button></div></div>`;
    }).join("");
}
function v11RenameBrigade(i) {
  const list = getBrigades(), b = list[i]; if (!b) return;
  const nn = (prompt("Brigada yangi nomi:", b.name) || "").trim(); if (!nn || nn === b.name) return;
  if (list.some((x, k) => k !== i && x.name.toLowerCase() === nn.toLowerCase())) { alert("Bunday brigada nomi bor."); return; }
  const old = b.name; b.name = nn; saveBrigadesForCurrent(list);
  const ws = getWorkers(); ws.forEach(w => { if (w.ekip === old) w.ekip = nn; }); saveWorkers(ws);
  renderBrigades(); if (typeof renderPuantaj === "function") renderPuantaj(); toast("Brigada nomi o‘zgartirildi ✓");
}
function v11RestoreBrigades() {
  const list = getBrigades(), ws = getWorkers(); let n = 0;
  V11_BR.forEach(d => {
    if (list.some(b => b.def === d.def || b.name === d.name)) return;
    list.push({ ...d }); n++;
    V11_ROSTER.forEach(([fio, , , ekip]) => { if (ekip === d.name) { const w = ws.find(x => !x.exited && normFio(x.fio) === normFio(fio)); if (w) w.ekip = d.name; } });
  });
  saveBrigadesForCurrent(list); saveWorkers(ws); renderBrigades(); toast(n + " ta brigada tiklandi ✓");
}

/* ---------- Ishchi qo'shish formasi ---------- */
function v11EnsureOption(id, v) {
  const el = document.getElementById(id); if (!el || !v) return;
  if (![...el.options].some(o => o.value === v)) { const o = document.createElement("option"); o.value = v; o.textContent = V11_DOCNAME[v] || v; el.appendChild(o); }
}
function v11FillCountryLists() {
  const sel = document.getElementById("f_davlat_sel");
  if (sel && !sel.options.length) sel.innerHTML = '<option value="">— Tanlang —</option>' + V11_MAIN_COUNTRIES.map(c => `<option value="${c}">${c}</option>`).join("") + '<option value="__other">Boshqa… (barcha davlatlar)</option>';
  const dl = document.getElementById("davlatList");
  if (dl && !dl.options.length) dl.innerHTML = [...new Set(ALL_COUNTRIES)].sort((a, b) => a.localeCompare(b, "ru")).map(c => `<option value="${c}">`).join("");
}
function fillDavlatList() { v11FillCountryLists(); }
function onDavlatInput() {}
function v11DavlatTyping() {}
function v11DavlatPick() {
  const sel = document.getElementById("f_davlat_sel"), inp = document.getElementById("f_davlat");
  if (sel.value === "__other") { inp.style.display = ""; inp.value = ""; inp.focus(); }
  else { inp.style.display = "none"; inp.value = sel.value; }
  onDavlatChange();
}
function onDavlatChange() {
  v11FillCountryLists();
  const inp = document.getElementById("f_davlat"), sel = document.getElementById("f_davlat_sel"); if (!inp || !sel) return;
  const d = (inp.value || "").trim(), up = d.toUpperCase();
  if (!d) { if (sel.value !== "__other") sel.value = ""; }
  else if (V11_MAIN_COUNTRIES.includes(up)) { sel.value = up; inp.value = up; inp.style.display = "none"; }
  else { sel.value = "__other"; inp.style.display = ""; }
  // fuqarolik bo'sh bo'lsa — qisqa shaklni taklif qil
  const fq = document.getElementById("f_fuqarolik");
  if (fq && !fq.value && V11_MILLAT[up]) {
    fq.value = V11_MILLAT[up];
    const fqs = document.getElementById("f_fuqarolik_sel");
    if (fqs) {
      const opt = [...fqs.options].find(o => o.value === V11_MILLAT[up]);
      if (opt) fqs.value = V11_MILLAT[up];
    }
  }
  v11BuildDocOptions();
}
function v11FuqarolikPick() {
  const sel = document.getElementById("f_fuqarolik_sel"), inp = document.getElementById("f_fuqarolik");
  if (!sel || !inp) return;
  if (sel.value === "__other") { inp.value = ""; inp.focus(); }
  else if (sel.value) inp.value = sel.value;
  onFuqarolikChange();
}
function onFuqarolikChange() {
  const fq = (document.getElementById("f_fuqarolik")?.value || "").trim().toLowerCase();
  const sel = document.getElementById("f_fuqarolik_sel");
  if (sel) {
    const hit = [...sel.options].find(o => o.value === fq);
    if (hit) sel.value = fq;
    else if (fq) sel.value = "__other";
  }
  // millat hidden = fuqarolik (compatibility)
  const mil = document.getElementById("f_millat");
  if (mil) mil.value = fq;
  v11BuildDocOptions();
}
function onMillatChangeFromCountry() { v11BuildDocOptions(); }
function v11BuildDocOptions() {
  const dsel = document.getElementById("f_doc_type"); if (!dsel) return;
  // Fuqarolik ustun (RF fuqarosi — patent yo'q)
  const fqVal = document.getElementById("f_fuqarolik")?.value || "";
  const davVal = document.getElementById("f_davlat")?.value || "";
  const clsFq = v11Country(fqVal);
  const cls = clsFq || v11Country(davVal);
  const cur = dsel.value;
  let opts;
  if (cls === "RU") opts = [["РФ", "Rossiya fuqarosi — faqat pasport"]];
  else {
    opts = [["", "— Tanlang —"]];
    if (cls === "EAEU") opts.push(["ПАСПОРТ", "Faqat pasport (hujjat shart emas)"]);
    V11_DOCS.forEach(x => opts.push(x));
  }
  if (cur && !["РФ", "ПАСПОРТ"].includes(cur) && !opts.some(o => o[0] === cur)) opts.push([cur, V11_DOCNAME[cur] || cur]);
  dsel.innerHTML = opts.map(o => `<option value="${esc(o[0])}">${esc(o[1])}</option>`).join("");
  const def = cls === "EAEU" ? "ПАСПОРТ" : cls === "PATENT" ? "Патент" : cls === "PERMIT" ? "РНР" : "";
  let want = cur;
  if (cls === "RU") want = "РФ";
  else if (!cur || cur === dsel.dataset.auto || cur === "РФ") want = def;
  dsel.dataset.auto = cls === "RU" ? "" : def;
  dsel.value = want; if (dsel.value !== want) dsel.value = "";
  onDocTypeChange();
}
function onDocTypeChange() {
  const dt = document.getElementById("f_doc_type")?.value || "", none = V11_NODOC.includes(dt), nm = V11_DOCNAME[dt] || dt || "Hujjat";
  ["f_patent", "f_patent_berilgan", "f_patent_tugash"].forEach(id => { const g = document.getElementById(id)?.closest(".form-group"); if (g) g.style.display = none ? "none" : ""; });
  const dv = document.getElementById("d_permit"); if (dv) { dv.style.display = none ? "none" : ""; dv.textContent = nm + " ma'lumotlari"; }
  const L = (id, t) => { const e = document.getElementById(id); if (e) e.textContent = t; };
  if (dt === "Миграционный учёт") { L("l_patent", "Uchyot raqami (agar bo'lsa)"); L("l_patent_berilgan", "Uchyotga olingan sana"); L("l_patent_tugash", "Uchyot tugash sanasi"); }
  else { L("l_patent", nm + " seriya + raqam"); L("l_patent_berilgan", nm + " olingan (berilgan) sana"); L("l_patent_tugash", nm + " tugash sanasi"); }
}
function onTurChange() {
  const tur = document.getElementById("f_tur")?.value; if (!tur) return;
  const staff = tur === "ENDIREKT", sel = document.getElementById("f_ekip"), curE = sel.value;
  document.getElementById("g_ekip").style.display = staff ? "none" : "";
  sel.innerHTML = staff ? '<option value="STAFF">STAFF (Ofis)</option>' : getBrigades().map(b => `<option value="${esc(b.name)}">${esc(b.name)} — ${esc(V11_POS[b.group] || "")}</option>`).join("");
  if (curE && [...sel.options].some(o => o.value === curE)) sel.value = curE;
  const L = getPositionLists(), arr = staff ? L.staff : L.direct, lav = document.getElementById("f_lavozim"), curL = lav.value;
  lav.innerHTML = '<option value="">— Tanlang —</option>' + arr.map(x => `<option value="${esc(x.ru)}">${esc(x.ru)}</option>`).join("");
  if (curL && [...lav.options].some(o => o.value === curL)) lav.value = curL;
  if (!lav.value && !staff) lav.value = V11_POS[brigadeGroup(sel.value)] || "";
  onLavozimPick();
}
function onEkipChange() {
  const sel = document.getElementById("f_ekip"), lav = document.getElementById("f_lavozim"); if (!sel || !lav) return;
  const defs = Object.values(V11_POS), want = V11_POS[brigadeGroup(sel.value)];
  if (want && (!lav.value || defs.includes(lav.value))) lav.value = want;
  onLavozimPick();
}
(function () {
  const _sw = window.saveWorker, _ew = window.editWorker, _rf = window.resetForm, _af = window.autoFillFromDB;
  window.saveWorker = function (e) {
    const dav = document.getElementById("f_davlat").value.trim();
    if (!dav) { e.preventDefault(); alert("Davlatni tanlang"); return false; }
    if (!document.getElementById("f_lavozim").value) { e.preventDefault(); alert("Lavozimni tanlang"); return false; }
    const dt = document.getElementById("f_doc_type").value;
    if (!dt && v11Country(dav) !== "RU") { e.preventDefault(); alert("Ish hujjatini tanlang (nima bilan ishlaydi)"); return false; }
    if (V11_NODOC.includes(dt)) ["f_patent", "f_patent_berilgan", "f_patent_tugash"].forEach(id => { document.getElementById(id).value = ""; });
    return _sw(e);
  };
  window.editWorker = function (id) {
    _ew(id);
    const w = getWorkers().find(x => x.id === id); if (!w) return;
    v11EnsureOption("f_lavozim", w.lavozim); set("f_lavozim", w.lavozim); set("f_dolzhnost", w.lavozim);
    v11EnsureOption("f_doc_type", w.doc_type); set("f_doc_type", w.doc_type || ""); document.getElementById("f_doc_type").dataset.auto = "";
    onDocTypeChange();
  };
  window.resetForm = function () {
    _rf(); v11FillCountryLists();
    const inp = document.getElementById("f_davlat"); if (inp) { inp.value = ""; inp.style.display = "none"; }
    document.getElementById("f_doc_type").dataset.auto = ""; onDavlatChange();
  };
  window.autoFillFromDB = function () {
    if (editId) return;
    const fio = document.getElementById("f_fio")?.value || "", e = fio.trim().length >= 4 ? findPastWorker(fio) : null;
    _af();
    if (e && e.doc_type) { v11EnsureOption("f_doc_type", e.doc_type); const d = document.getElementById("f_doc_type"); d.value = e.doc_type; d.dataset.auto = ""; onDocTypeChange(); }
  };
})();

/* ---------- Fayl oynalari (umumiy) ---------- */
function v11Modal(id, html) {
  document.getElementById(id)?.remove();
  const ov = document.createElement("div"); ov.id = id; ov.className = "v11-modal";
  ov.onclick = e => { if (e.target === ov) ov.remove(); };
  ov.innerHTML = `<div class="v11-modal-card">${html}</div>`; document.body.appendChild(ov); return ov;
}
function v11OpenBlob(f) {
  const blob = new Blob([f.data], { type: f.type || "application/octet-stream" }), url = URL.createObjectURL(blob);
  if (/pdf|image/.test(f.type || "")) window.open(url, "_blank"); else { const a = document.createElement("a"); a.href = url; a.download = f.name; a.click(); }
}
function openFilesModal(wid) {
  const w = getWorkers().find(x => x.id === wid); if (!w) return;
  v11Modal("v11FilesModal", `<div class="v11-modal-head"><div><h3>${esc(w.fio)}</h3><small>Hujjatlar skaneri (pasport, ruxsatnoma va h.k.)</small></div><button class="btn-sm" onclick="this.closest('.v11-modal').remove();v11MalumotCounts()">✕</button></div>
    <div id="wfiles_${wid}" style="margin:10px 0"></div>
    <input type="file" id="wfile_inp_${wid}" multiple accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"> <button class="btn-main btn-sm" onclick="uploadWorkerFiles(currentObj,'${wid}')">Yuklash</button>`);
  renderWorkerFilesUI(currentObj, wid);
}
async function v11MalumotCounts() {
  for (const el of document.querySelectorAll("[data-fcount]")) {
    const items = await getWorkerFiles(currentObj, el.dataset.fcount); el.textContent = items.length ? items.length : "";
  }
}

/* ---------- Ishchi ma'lumoti jadvali ---------- */
function v11DocSelect(w) {
  const opts = [["", "— tanlang —"], ["ПАСПОРТ", "Faqat pasport"], ...V11_DOCS, ["РФ", "РФ (pasport)"]];
  if (w.doc_type && !opts.some(o => o[0] === w.doc_type)) opts.push([w.doc_type, V11_DOCNAME[w.doc_type] || w.doc_type]);
  return `<select class="v11-sel" onchange="v11SetDoc('${w.id}',this.value)">${opts.map(o => `<option value="${esc(o[0])}" ${o[0] === (w.doc_type || "") ? "selected" : ""}>${esc(o[1])}</option>`).join("")}</select>`;
}
function v11SetDoc(id, v) {
  const list = getWorkers(), w = list.find(x => x.id === id); if (!w) return;
  w.doc_type = v; if (V11_NODOC.includes(v)) { w.patent = ""; w.patent_berilgan = ""; w.patent_tugash = ""; }
  saveWorkers(list); renderMalumot(); renderPatent();
}
function renderMalumot() {
  const tb = document.getElementById("malumotBody"); if (!tb) return;
  const th = tb.closest("table").querySelector("thead");
  if (th && th.dataset.v11 !== "v12") {
    th.dataset.v11 = "v12";
    th.innerHTML = "<tr>" + ["№", "F.I.O", "Brigada", "Lavozim", "Davlat", "Fuqarolik", "Tug'ilgan sana", "Pasport seriya + raqam", "Кем выдан паспорт", "Pasport berilgan", "Pasport tugash", "INN", "SNILS", "Ish hujjati", "Hujjat raqami", "Berilgan", "Tugash", "Holat", "📎 Fayllar"].map(x => `<th>${x}</th>`).join("") + "</tr>";
  }
  v11FillCountryLists();
  const q = (document.getElementById("searchMalumot")?.value || "").toLowerCase(), inc = document.getElementById("fltMalumot")?.value === "inc";
  let list = getWorkers().filter(w => !w.exited);
  if (q) list = list.filter(w => (w.fio || "").toLowerCase().includes(q) || (w.sicil || "").includes(q) || (w.inn || "").includes(q) || (w.ekip || "").toLowerCase().includes(q));
  if (inc) list = list.filter(w => missingData(w).length);
  list = v11Groups(list).flatMap(g => g.list);
  const inp = (w, k, type = "text", wd = 120, extra = "") => `<input type="${type}" value="${esc(w[k])}" style="width:${wd}px" ${extra} onchange="setField('${w.id}','${k}',this.value)">`;
  tb.innerHTML = list.map((w, i) => {
    const none = getDocKind(w) === "none", night = w.vardiya === "GECE";
    const dash = '<td class="v11-na">—</td>';
    return `<tr id="mr_${w.id}" class="${night ? "v11-night" : ""}"><td>${i + 1}</td>
    <td><b style="cursor:pointer;color:#1d4ed8" onclick="showProfile(currentObj,'${w.id}')">${esc(w.fio)}</b>${night ? " 🌙" : ""}</td>
    <td>${esc(isStaff(w) ? "STAFF" : w.ekip || "")}</td><td style="min-width:170px">${esc(w.lavozim || "")}</td>
    <td>${inp(w, "davlat", "text", 120, 'list="davlatList"').replace(`value="${esc(w.davlat)}"`, `value="${esc(w.davlat || "")}"`)}</td>
    <td>${inp(w, "fuqarolik", "text", 100)}</td>
    <td>${inp(w, "tugilgan", "date", 135)}</td><td>${inp(w, "pasport")}</td><td>${inp(w, "pasport_beruvchi", "text", 190)}</td>
    <td>${inp(w, "pasport_berilgan", "date", 135)}</td><td>${inp(w, "pasport_tugash", "date", 135)}</td>
    <td>${inp(w, "inn")}</td><td>${inp(w, "snils")}</td>
    <td>${v11DocSelect(w)}</td>
    ${none ? dash + dash + dash : `<td>${inp(w, "patent")}</td><td>${inp(w, "patent_berilgan", "date", 135)}</td><td>${inp(w, "patent_tugash", "date", 135)}</td>`}
    <td id="ms_${w.id}">${statusCell(w)}</td>
    <td><button class="btn-sm" onclick="openFilesModal('${w.id}')">📎 <b data-fcount="${w.id}"></b></button></td></tr>`;
  }).join("") || `<tr><td colspan="20" style="text-align:center;color:#888;padding:20px">Ma'lumot yo'q</td></tr>`;
  v11MalumotCounts();
}

/* ---------- Patent cheklari (faqat patent bilan ishlaydiganlar) ---------- */
const v11GetChecks = wid => getWorkerFiles(currentObj, wid + "__chek");
const v11SaveChecks = (wid, items) => saveWorkerFiles(currentObj, wid + "__chek", items);
function renderPatent() {
  const tbody = document.getElementById("patentBody"); if (!tbody) return;
  const hr = document.querySelector("#sec-patent thead tr");
  if (hr && !hr.dataset.v11) { hr.dataset.v11 = "1"; hr.insertAdjacentHTML("beforeend", "<th>📎 Cheklar (12 oy)</th>"); }
  let list = getWorkers().filter(w => !w.exited && v11IsPatent(w)).map(w => ({ w, days: patentDaysLeft(w) })).sort((a, b) => a.days - b.days);
  const filt = document.getElementById("patentFilter")?.value || "all";
  if (filt === "expiring") list = list.filter(x => x.days >= 0 && x.days < 30);
  else if (filt === "expired") list = list.filter(x => x.days < 0);
  else if (filt === "ok") list = list.filter(x => x.days >= 30);
  tbody.innerHTML = list.map(({ w, days }, i) => {
    const due = payDue(w), ed = expiryDays(w), pdays = payDays(w), last = (w.pays || []).slice(-1)[0];
    return `<tr><td>${i + 1}</td><td><b>${esc(w.fio)}</b></td>
      <td>${esc((w.doc_type ? w.doc_type + " " : "") + (w.patent || "")) || "—"}</td>
      <td>${w.patent_berilgan || "—"}</td><td>${w.patent_tugash || "—"}</td><td>${ed < 900 ? ed : "—"}</td>
      <td>${due ? ymd(addDays(due, -2)) : "—"}</td><td>${pdays < 900 ? pdays : "—"}</td><td>${patentBadge(days)}</td>
      <td>${due ? `<input type="date" id="pdt_${w.id}" value="${todayStr()}"> <input type="checkbox" title="To'landi" style="width:20px;height:20px;vertical-align:middle" onchange="tickPaid('${w.id}')">` : "—"}</td>
      <td>${last ? `<input type="date" value="${last.paid}" onchange="editPaidDate('${w.id}',this.value)"> <button class="btn-sm" title="Bekor qilish" onclick="undoPaid('${w.id}')">↩</button>` : "—"}</td>
      <td><button class="btn-sm v11-chk-btn" onclick="openPatentChecks('${w.id}')">📎 Cheklar <b id="chkn_${w.id}"></b></button></td></tr>`;
  }).join("") || `<tr><td colspan="12" style="text-align:center;color:#888;padding:20px">Patent bilan ishlaydigan ishchi yo'q</td></tr>`;
  list.forEach(async ({ w }) => {
    const it = await v11GetChecks(w.id), el = document.getElementById("chkn_" + w.id);
    if (el) el.textContent = `${new Set(it.map(f => f.slot)).size}/12`;
  });
}
async function openPatentChecks(wid) {
  const w = getWorkers().find(x => x.id === wid); if (!w) return;
  v11Modal("v11ChkModal", `<div class="v11-modal-head"><div><h3>${esc(w.fio)}</h3><small>Patent: ${esc(w.patent || "—")} · ${dmy(w.patent_berilgan) || "—"} → ${dmy(w.patent_tugash) || "—"}</small></div><button class="btn-sm" onclick="this.closest('.v11-modal').remove();renderPatent()">✕</button></div><div id="v11ChkBody"></div>`);
  await v11RenderChecks(wid);
}
async function v11RenderChecks(wid) {
  const w = getWorkers().find(x => x.id === wid), box = document.getElementById("v11ChkBody"); if (!w || !box) return;
  if (!w.patent_berilgan) { box.innerHTML = '<div class="v11-note">Avval «Ishchi ma\'lumoti»da patent berilgan sanasini kiriting — shu sanadan 12 oylik to\'lov jadvali tuziladi.</div>'; return; }
  const items = await v11GetChecks(wid), s = pdate(w.patent_berilgan), t = today0(), pays = w.pays || [];
  let rows = "", paidN = 0, fileN = 0;
  for (let n = 1; n <= 12; n++) {
    const due = addDays(s, 30 * n), dueS = ymd(due), dl = addDays(due, -2), paid = pays.find(p => p.due === dueS);
    const left = Math.round((dl - t) / 864e5), fs = items.map((f, i) => ({ f, i })).filter(x => x.f.slot === n);
    if (paid) paidN++; if (fs.length) fileN++;
    const st = paid ? `<span class="badge badge-green">✓ To'langan ${dmy(paid.paid)}</span>` : left < 0 ? `<span class="badge badge-red">⚠ ${-left} kun o'tgan</span>` : left <= 7 ? `<span class="badge badge-yellow">⏳ ${left} kun qoldi</span>` : `<span class="badge">${left} kun qoldi</span>`;
    rows += `<tr class="${paid ? "v11-paid" : ""}"><td><b>${n}</b></td><td>${dmy(ymd(dl))}</td><td>${st}</td>
      <td style="white-space:nowrap"><input type="checkbox" ${paid ? "checked" : ""} style="width:18px;height:18px;vertical-align:middle" onchange="v11TogglePaid('${wid}','${dueS}',this.checked,${n})"> <input type="date" id="chk_dt_${n}" value="${paid ? paid.paid : todayStr()}" style="width:128px"></td>
      <td>${fs.map(x => `<div class="v11-file"><span>📄 ${esc(x.f.name)}</span><button class="btn-sm" onclick="v11OpenCheck('${wid}',${x.i})">Ochish</button><button class="btn-sm" style="color:#c00" onclick="v11DelCheck('${wid}',${x.i})">×</button></div>`).join("")}
        <input type="file" id="chk_inp_${n}" accept=".pdf,.jpg,.jpeg,.png" multiple hidden onchange="v11UploadCheck('${wid}',${n},this)"><button class="btn-sm" onclick="document.getElementById('chk_inp_${n}').click()">📎 Chek yuklash</button></td></tr>`;
  }
  const arch = (w.patent_archives || []);
  let archHtml = "";
  if (arch.length) {
    archHtml = `<details style="margin-top:10px"><summary style="cursor:pointer;font-weight:700">📦 Arxiv — ${arch.length} ta sikl</summary>` +
      arch.map((a,i) => `<div style="padding:8px;margin:6px 0;background:#f8fafc;border-radius:8px;font-size:12px">
        <b>Sikl ${i+1}</b>: ${esc(a.from||"")} → ${esc(a.to||"")} · to'lovlar: ${(a.pays||[]).length} · cheklar: ${(a.checks||[]).length}
        <button class="btn-sm" onclick="v11ViewArchive('${wid}',${i})">Ko'rish</button>
      </div>`).join("") + `</details>`;
  }
  const canArch = paidN >= 12;
  box.innerHTML = `<div class="v11-chk-sum"><span>To'langan: <b>${paidN}/12</b></span><span>Chek yuklangan: <b>${fileN}/12</b></span>
    <small>To'lov muddati — patent berilgan sanadan har 30 kunda, kamida 2 kun oldin.</small>
    ${canArch ? `<button class="btn-main btn-sm" style="margin-left:8px" onclick="v11ArchivePatentCycle('${wid}')">📦 12 oy yakunlandi — arxivga olish</button>` : ""}
    </div>
    <div class="table-scroll"><table class="tbl tbl-sm"><thead><tr><th>Oy</th><th>To'lov muddati</th><th>Holat</th><th>To'landi (✓ + sana)</th><th>Chek (PDF / rasm)</th></tr></thead><tbody>${rows}</tbody></table></div>
    ${archHtml}`;
}
async function v11ArchivePatentCycle(wid) {
  const list = getWorkers(), w = list.find(x => x.id === wid); if (!w) return;
  if ((w.pays || []).length < 12) { alert("12 ta to'lov to'liq emas"); return; }
  if (!confirm("12 oylik cheklar arxivga olinadi va yangi sikl boshlanadi. Davom etasizmi?")) return;
  const checks = await v11GetChecks(wid);
  w.patent_archives = w.patent_archives || [];
  w.patent_archives.push({
    from: w.patent_berilgan || "",
    to: w.patent_tugash || "",
    patent: w.patent || "",
    pays: [...(w.pays || [])],
    checks: checks.map(c => ({ name: c.name, type: c.type, size: c.size, at: c.at, slot: c.slot })),
    archivedAt: new Date().toISOString()
  });
  // yangi sikl: pays tozalash, cheklar tozalash; patent sanalari qo'lda yangilanadi
  w.pays = [];
  w.paid_due = "";
  w.last_paid = "";
  await v11SaveChecks(wid, []);
  saveWorkers(list);
  toast("Arxivlandi — yangi 12 oy boshlandi. Patent sanalarini yangilang.");
  v11RenderChecks(wid);
  renderPatent();
}
function v11ViewArchive(wid, i) {
  const w = getWorkers().find(x => x.id === wid); if (!w) return;
  const a = (w.patent_archives || [])[i]; if (!a) return;
  alert(`Arxiv sikl ${i+1}\nPatent: ${a.patent || "—"}\n${a.from} → ${a.to}\nTo'lovlar: ${(a.pays||[]).length}\nCheklar: ${(a.checks||[]).length}\nArxiv: ${a.archivedAt || ""}`);
}
async function v11UploadCheck(wid, n, inp) {
  if (!inp.files.length) return;
  const items = await v11GetChecks(wid);
  for (const f of [...inp.files]) items.push({ name: f.name, type: f.type, size: f.size, data: await f.arrayBuffer(), at: Date.now(), slot: n });
  await v11SaveChecks(wid, items); toast(n + "-oy cheki saqlandi ✓"); v11RenderChecks(wid);
}
async function v11OpenCheck(wid, i) { const f = (await v11GetChecks(wid))[i]; if (f) v11OpenBlob(f); }
async function v11DelCheck(wid, i) {
  if (!confirm("Chek o'chirilsinmi?")) return;
  const items = await v11GetChecks(wid); items.splice(i, 1); await v11SaveChecks(wid, items); v11RenderChecks(wid);
}
function v11TogglePaid(wid, dueS, on, n) {
  const list = getWorkers(), w = list.find(x => x.id === wid); if (!w) return;
  w.pays = (w.pays || []).filter(p => p.due !== dueS);
  if (on) w.pays.push({ due: dueS, paid: document.getElementById("chk_dt_" + n)?.value || todayStr() });
  w.pays.sort((a, b) => a.due.localeCompare(b.due));
  const l = w.pays[w.pays.length - 1]; w.paid_due = l ? l.due : ""; w.last_paid = l ? l.paid : "";
  saveWorkers(list); v11RenderChecks(wid); renderWorkers();
}

/* ---------- Oylik bodro: har brigada alohida, zamonaviy ---------- */
const V11_WK = ["Ya", "Du", "Se", "Ch", "Pa", "Ju", "Sh"];
let v11BodroFilter = "ALL";
function v11SetBodroFilter(n) { v11BodroFilter = n; renderBodro(); }
function v11Val(w, month, d, b) {
  let v = (b[w.id] || {})[d] ?? "";
  if (v === "") { const src = transferSourceForDay(w, `${month}-${v11pad(d)}`); if (src) v = sourceBodroValue(src, w.id, month, d); }
  return v;
}
function renderBodro() {
  const box = document.getElementById("bodroCards"); if (!box) return;
  const month = document.getElementById("bodroMonth")?.value || todayStr().slice(0, 7), [y, m] = month.split("-").map(Number), dim = new Date(y, m, 0).getDate();
  const b = JSON.parse(localStorage.getItem(key("bodro_" + month)) || "{}"), edits = JSON.parse(localStorage.getItem(key("bodro_edits_" + month)) || "{}");
  const groups = v11Groups(bodroWorkers(month));
  if (v11BodroFilter !== "ALL" && !groups.some(g => g.name === v11BodroFilter)) v11BodroFilter = "ALL";
  document.getElementById("bodroTabs").innerHTML = [["ALL", "Hammasi"], ...groups.map(g => [g.name, g.title])].map(([k, t]) =>
    `<button class="v11-tab ${v11BodroFilter === k ? "on" : ""}" data-k="${esc(k)}" onclick="v11SetBodroFilter(this.dataset.k)">${esc(t)}${k === "ALL" ? "" : ` <i>${groups.find(g => g.name === k).list.length}</i>`}</button>`).join("");
  const now = new Date(); now.setHours(12, 0, 0, 0);
  let head = `<th class="v11-c1">№</th><th class="v11-c2">F.I.O</th>`;
  for (let d = 1; d <= dim; d++) { const wd = new Date(y, m - 1, d).getDay(); head += `<th class="${wd === 0 || wd === 6 ? "we" : ""}"><div>${d}</div><small>${V11_WK[wd]}</small></th>`; }
  head += `<th class="v11-tot">Jami</th>`;
  const row = (w, i) => {
    let total = 0, cells = "";
    for (let d = 1; d <= dim; d++) {
      const ds = `${month}-${v11pad(d)}`, src = transferSourceForDay(w, ds), v = v11Val(w, month, d, b); total += v11Num(v);
      const wd = new Date(y, m - 1, d).getDay(), ed = (edits[w.id] || {})[d], ago = Math.floor((now - new Date(ds + "T12:00:00")) / 864e5);
      const canEdit = bodroEditMode && ago <= 3, cls = [src ? "history-cell" : "", ed && ago > 3 ? "bodro-edited" : "", wd === 0 || wd === 6 ? "we" : "", v === "" ? "" : (v11Num(v) > 0 ? "has" : "zero")].join(" ");
      cells += `<td class="${cls}" ${src ? `title="${esc((OBJECTS.find(o => o.id === src) || {}).short || src)} dan"` : ""} ${canEdit ? `contenteditable="true" onblur="editBodroCell('${w.id}',${d},this)"` : ""}>${esc(v)}</td>`;
    }
    return { total, html: `<tr class="${w.vardiya === "GECE" ? "v11-night" : ""}"><td class="v11-c1">${i}</td><td class="v11-c2"><b>${esc(w.fio)}</b>${w.vardiya === "GECE" ? " 🌙" : ""}<small>${esc(w.sicil || "")}</small></td>${cells}<td class="v11-tot"><b>${total % 1 ? total.toFixed(1) : total}</b></td></tr>` };
  };
  let html = "";
  groups.filter(g => v11BodroFilter === "ALL" || g.name === v11BodroFilter).forEach(g => {
    let grand = 0, body = "", n = 0;
    g.day.forEach(w => { const r = row(w, ++n); grand += r.total; body += r.html; });
    if (g.night.length) body += `<tr class="v11-sep"><td colspan="${dim + 3}">🌙 Kecha smenasi (${g.night.length})</td></tr>`;
    g.night.forEach(w => { const r = row(w, ++n); grand += r.total; body += r.html; });
    let foot = `<td class="v11-c1"></td><td class="v11-c2">Ishlaganlar soni</td>`;
    for (let d = 1; d <= dim; d++) foot += `<td>${g.list.filter(w => v11Num(v11Val(w, month, d, b)) > 0).length || ""}</td>`;
    html += `<div class="v11-card"><div class="v11-card-head"><div><span class="brigade-group">${esc(g.pos || (g.name === "STAFF" ? "Ofis / Endirekt" : "Brigada"))}</span><h3>${esc(g.title)}</h3>${g.leader ? `<small>Brigadir: ${esc(g.leader)}</small>` : ""}</div>
      <div class="v11-stats"><span><b>${g.list.length}</b> kishi</span><span><b>${grand % 1 ? grand.toFixed(1) : grand}</b> soat</span><button class="btn-sec btn-sm" data-g="${esc(g.name)}" onclick="printHourCards(null,this.dataset.g)">🖨 Kartochkalar</button></div></div>
      <div class="table-scroll"><table class="v11-bodro"><thead><tr>${head}</tr></thead><tbody>${body}</tbody><tfoot><tr>${foot}<td class="v11-tot"></td></tr></tfoot></table></div></div>`;
  });
  box.innerHTML = html || `<div class="v11-note">Ma'lumot yo'q</div>`;
}

/* ---------- Soat kartochkalari: qaychida kesish uchun (har birida sana + soat + jami) ---------- */
function printHourCards(month, only) {
  month = month || document.getElementById("bodroMonth")?.value || todayStr().slice(0, 7);
  const sel = typeof only === "string" && only ? only : (v11BodroFilter === "ALL" ? "" : v11BodroFilter);
  const [y, m] = month.split("-").map(Number), dim = new Date(y, m, 0).getDate();
  const b = JSON.parse(localStorage.getItem(key("bodro_" + month)) || "{}"), obj = (OBJECTS.find(o => o.id === currentObj) || {}).short || currentObj || "";
  const groups = v11Groups(bodroWorkers(month)).filter(g => !sel || g.name === sel);
  if (!groups.length) { alert("Chop etish uchun ma'lumot yo'q"); return; }
  let html = "";
  groups.forEach((g, gi) => {
    html += `<section class="grp" style="${gi ? "page-break-before:always" : ""}"><table class="st"><colgroup><col style="width:46mm">${'<col>'.repeat(dim)}<col style="width:15mm"></colgroup>`;
    g.list.forEach(w => {
      let tot = 0, dates = "", hrs = "";
      for (let d = 1; d <= dim; d++) {
        const wd = new Date(y, m - 1, d).getDay(), v = v11Val(w, month, d, b), x = v11Num(v); tot += x;
        dates += `<td class="dt ${wd === 0 || wd === 6 ? "we" : ""}">${v11pad(d)}.${v11pad(m)}</td>`;
        hrs += `<td class="hr ${wd === 0 || wd === 6 ? "we" : ""}">${v === "" ? "" : esc(v)}</td>`;
      }
      const night = w.vardiya === "GECE";
      html += `<tbody class="strip ${night ? "night" : ""}"><tr><td class="nm" rowspan="2"><b>${esc(w.fio)}</b>${night ? " 🌙" : ""}<small>Таб. № ${esc(w.sicil || "")} · ${esc(g.title)} · ${v11pad(m)}.${y}</small></td>${dates}<td class="tt" rowspan="2"><small>Jami soat</small><b>${tot % 1 ? tot.toFixed(1) : tot}</b></td></tr><tr>${hrs}</tr></tbody>`;
    });
    html += `</table><div class="ft">${esc(obj)} · ${esc(g.title)} · ${g.list.length} kishi · punktir chiziq bo'ylab kesing</div></section>`;
  });
  const win = window.open("", "_blank"); if (!win) { alert("Chop etish oynasi bloklandi. Brauzerda pop-up'ga ruxsat bering."); return; }
  win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Soat kartochkalari ${month}</title><style>
  @page{size:A4 landscape;margin:6mm}*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .st{width:100%;border-collapse:collapse;table-layout:fixed}.strip{break-inside:avoid;page-break-inside:avoid}
  .strip td{border:1px solid #444;text-align:center;padding:0;height:4.6mm;line-height:1}
  .strip tr:last-child td{border-bottom:1.6px dashed #111}
  .strip .nm{text-align:left;padding:1mm 1.5mm;font-size:8.5pt}.nm small{display:block;font-size:6pt;color:#555;font-weight:400;margin-top:.6mm}
  .dt{font-size:5.6pt;color:#555;background:#f3f4f6}.hr{font-size:9pt;font-weight:700}.we{background:#fee2e2!important;color:#b91c1c}
  .tt{background:#eef2ff;font-size:11pt}.tt small{display:block;font-size:5.5pt;color:#555;font-weight:400}.strip.night .nm{background:#e0e7ff}
  .ft{font-size:6.5pt;color:#777;margin-top:1.5mm;text-align:right}
  </style></head><body>${html}<script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`);
  win.document.close();
}

/* ---------- Yoqlama qog'ozi: har brigada alohida ---------- */
function v11YoqDays() {
  const from = document.getElementById("yoqFrom")?.value || todayStr().slice(0, 8) + "01", to = document.getElementById("yoqTo")?.value || todayStr();
  const days = []; let d = new Date(from + "T12:00:00"); const e = new Date(to + "T12:00:00");
  while (d <= e) { days.push(ymd(d)); d.setDate(d.getDate() + 1); }
  return { from, to, days };
}
function v11YoqHTML(sel, print) {
  const { from, to, days } = v11YoqDays();
  if (days.length > 14) return `<p style="color:#c00">Yoqlama uchun maksimum 14 kun tanlang (qog'ozga sig'ishi uchun).</p>`;
  const objName = (OBJECTS.find(o => o.id === currentObj) || {}).short || currentObj || "";
  const groups = v11Groups(getWorkers().filter(w => !w.exited)).filter(g => !sel || g.name === sel);
  let html = "";
  groups.forEach(g => {
    const rows = (list, start, night) => list.map((w, i) => `<tr class="${night ? "yoq-night" : ""}"><td>${start + i}</td><td>${esc(w.sicil || "")}</td><td class="fio">${esc(w.fio)}${night ? " 🌙" : ""}</td>${days.map(() => `<td class="yoq-empty"></td><td class="yoq-empty"></td>`).join("")}</tr>`).join("");
    html += `<div class="yoq-sec"><div class="yoq-head"><b>${esc(objName)} — YOQLAMA · ${esc(g.title)}</b>${g.leader ? ` <span>Brigadir: ${esc(g.leader)}</span>` : ""} <em>${from} — ${to} · ${g.list.length} kishi</em>${print ? "" : `<button class="btn-sm yoq-print" data-g="${esc(g.name)}" onclick="printYoqlama(this.dataset.g)">🖨 Faqat shu brigada</button>`}</div>
      <table class="yoq-table"><thead><tr><th style="width:28px">№</th><th style="width:70px">Sicil</th><th class="fio">Soyadi / F.I.O</th>${days.map(ds => `<th colspan="2" style="min-width:48px">${ds.slice(8)}.${ds.slice(5, 7)}</th>`).join("")}</tr>
      <tr><th></th><th></th><th></th>${days.map(() => `<th style="font-size:9px">±</th><th style="font-size:9px">F.M</th>`).join("")}</tr></thead><tbody>${rows(g.day, 1, false)}${g.night.length ? `<tr class="yoq-sep"><td colspan="${3 + days.length * 2}">🌙 Kecha smenasi</td></tr>` : ""}${rows(g.night, g.day.length + 1, true)}</tbody></table></div>`;
  });
  return html || "<p>Ishchi yo'q</p>";
}
function renderYoqlama() {
  const box = document.getElementById("yoqlamaContent"); if (!box) return;
  const s = document.getElementById("yoqBr");
  if (s) {
    const cur = s.value, gs = v11Groups(getWorkers().filter(w => !w.exited));
    s.innerHTML = '<option value="">Hamma brigadalar</option>' + gs.map(g => `<option value="${esc(g.name)}">${esc(g.title)} (${g.list.length})</option>`).join("");
    s.value = gs.some(g => g.name === cur) ? cur : "";
  }
  box.innerHTML = v11YoqHTML(s ? s.value : "", false);
}
function printYoqlama(only) {
  const sel = typeof only === "string" && only ? only : (document.getElementById("yoqBr")?.value || "");
  const content = v11YoqHTML(sel, true), w = window.open("", "_blank"); if (!w) { alert("Pop-up bloklangan"); return; }
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Yoqlama</title><style>
    @page{size:A4 portrait;margin:8mm}body{font-family:Arial,sans-serif;font-size:11px;margin:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    .yoq-sec{page-break-after:always}.yoq-sec:last-child{page-break-after:auto}.yoq-head{margin:0 0 4px;font-size:12px}.yoq-head span,.yoq-head em{color:#555;font-style:normal;margin-left:8px;font-size:10px}
    .yoq-table{border-collapse:collapse;width:100%}.yoq-table th,.yoq-table td{border:1px solid #000;padding:2px 4px;text-align:center}
    .yoq-table .fio{text-align:left;font-size:10px}.yoq-empty{height:16px}.yoq-night td{background:#e0e7ff}.yoq-sep td{background:#c7d2fe;font-weight:700;font-size:9px;text-align:left}
  </style></head><body>${content}<script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`);
  w.document.close();
}

/* ---------- Excel (brigadalar alohida varaqda) ---------- */
function v11Sheet(wb, name, rows) {
  const used = wb.SheetNames; let nm = String(name).replace(/[\\\/\?\*\[\]:]/g, " ").trim().slice(0, 28) || "Sheet", k = 1, base = nm;
  while (used.includes(nm)) nm = base + "_" + (++k);
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), nm);
}
function v11Export(type) {
  const wb = XLSX.utils.book_new(), act = getWorkers().filter(w => !w.exited);
  if (type === "bodro" || type === "bodro_staff") {
    const month = document.getElementById("bodroMonth").value, [y, m] = month.split("-").map(Number), dim = new Date(y, m, 0).getDate();
    const b = JSON.parse(localStorage.getItem(key("bodro_" + month)) || "{}");
    v11Groups(bodroWorkers(month).filter(w => isStaff(w) === (type === "bodro_staff"))).forEach(g => {
      const rows = [[g.title + (g.leader ? " — " + g.leader : ""), month], ["№", "F.I.O", "Sicil", "Lavozim", "Smena", ...Array.from({ length: dim }, (_, i) => i + 1), "Jami"]];
      g.list.forEach((w, i) => { let t = 0; const c = []; for (let d = 1; d <= dim; d++) { const v = v11Val(w, month, d, b); c.push(v === "" ? "" : (isNaN(+v) ? v : +v)); t += v11Num(v); } rows.push([i + 1, w.fio, w.sicil, w.lavozim, w.vardiya === "GECE" ? "Kecha" : "Kunduz", ...c, t]); });
      v11Sheet(wb, g.title, rows);
    });
  } else if (type === "yoqlama") {
    const { days } = v11YoqDays(), sel = document.getElementById("yoqBr")?.value || "";
    v11Groups(act).filter(g => !sel || g.name === sel).forEach(g => {
      const rows = [["№", "Sicil", "F.I.O", "Smena", ...days.flatMap(d => [d.slice(8) + "." + d.slice(5, 7) + " ±", "F.M"])]];
      g.list.forEach((w, i) => rows.push([i + 1, w.sicil, w.fio, w.vardiya === "GECE" ? "Kecha" : "Kunduz"]));
      v11Sheet(wb, g.title, rows);
    });
  } else if (type === "patent") {
    const rows = [["№", "F.I.O", "Hujjat", "Raqam", "Berilgan", "Tugash", "Tugashgacha (kun)", "To'lov muddati (2 kun oldin)", "To'lovgacha (kun)", "Oxirgi to'lov", "To'langan oylar"]];
    act.filter(v11IsPatent).map(w => ({ w, days: patentDaysLeft(w) })).sort((a, b) => a.days - b.days).forEach(({ w }, i) => {
      const due = payDue(w), ed = expiryDays(w), pd = payDays(w);
      rows.push([i + 1, w.fio, w.doc_type || "", w.patent || "", w.patent_berilgan || "", w.patent_tugash || "", ed < 900 ? ed : "", due ? ymd(addDays(due, -2)) : "", pd < 900 ? pd : "", w.last_paid || "", (w.pays || []).length + "/12"]);
    });
    v11Sheet(wb, "Patent", rows);
  } else if (type === "malumot") {
    const rows = [["№", "F.I.O", "Brigada", "Lavozim", "Sicil", "Davlat", "Fuqarolik", "Tug'ilgan sana", "Pasport", "Pasport kim bergan", "Pasport berilgan", "Pasport tugash", "INN", "SNILS", "Ish hujjati", "Hujjat raqami", "Berilgan", "Tugash"]];
    v11Groups(act).flatMap(g => g.list).forEach((w, i) => { const none = getDocKind(w) === "none"; rows.push([i + 1, w.fio, isStaff(w) ? "STAFF" : w.ekip, w.lavozim || "", w.sicil || "", w.davlat || "", w.fuqarolik || w.millat || "", w.tugilgan || "", w.pasport || "", w.pasport_beruvchi || "", w.pasport_berilgan || "", w.pasport_tugash || "", w.inn || "", w.snils || "", V11_DOCNAME[w.doc_type] || w.doc_type || "", none ? "" : (w.patent || ""), none ? "" : (w.patent_berilgan || ""), none ? "" : (w.patent_tugash || "")]); });
    v11Sheet(wb, "Ishchi ma'lumoti", rows);
  }
  XLSX.writeFile(wb, `${currentObj}_${type}_${todayStr()}.xlsx`);
}
(function () {
  const _ex = window.exportExcel;
  window.exportExcel = function (type) {
    if (window.XLSX && ["bodro", "bodro_staff", "yoqlama", "patent", "malumot"].includes(type)) { v11Export(type); return; }
    return _ex(type);
  };
})();

/* ---------- Ishga tushirish ---------- */
function v11Setup() {
  const act = document.querySelector("#sec-yoqlama .sec-actions");
  if (act && !document.getElementById("yoqBr")) act.insertAdjacentHTML("afterbegin", '<select id="yoqBr" onchange="renderYoqlama()" title="Brigadani tanlang"></select>');
  const d = document.querySelector("#sec-patent .section-desc");
  if (d) d.textContent = "Faqat Patent bilan ishlaydiganlar (O'zbek, Tojik, Ozarbayjon). Har bir ishchi uchun 12 oylik to'lov jadvali va chek (PDF/rasm) yuklash — «Cheklar» tugmasida.";
  v11FillCountryLists(); v11FillBeruvchiList(); v11MigrateBeruvchi(); v11MigrateFuqarolik(); onDavlatChange(); onTurChange();
  renderBodro(); renderPatent(); renderBrigades(); renderPositionManager();
}
(function () {
  const _init = window.initObject;
  window.initObject = function () {
    currentObj = new URLSearchParams(location.search).get("id");
    if (OBJECTS.some(o => o.id === currentObj)) {
      try { if (currentObj === "jois" && typeof seedJoisData === "function") seedJoisData(); migrateWorkers(); v11Migrate(); v11NormLavozim(); } catch (e) { console.error("v11 migratsiya:", e); }
    }
    _init();
    try { v11Setup(); } catch (e) { console.error("v11 setup:", e); }
  };
})();


function v11FillBeruvchiList() {
  const dl = document.getElementById("pasportBeruvchiList"); if (!dl) return;
  const set = new Set();
  if (typeof PERSON_DB !== "undefined") PERSON_DB.forEach(e => { if (e.pasport_beruvchi) set.add(e.pasport_beruvchi); });
  getWorkers().forEach(w => { if (w.pasport_beruvchi) set.add(w.pasport_beruvchi); });
  dl.innerHTML = [...set].sort().map(x => `<option value="${esc(x)}">`).join("");
}
function v11MigrateBeruvchi() {
  if (localStorage.getItem(key("v11_beruvchi"))) return;
  if (typeof PERSON_DB === "undefined" || typeof dbFind !== "function") return;
  const list = getWorkers(); let n = 0;
  list.forEach(w => {
    if (w.pasport_beruvchi) return;
    const e = dbFind(w.fio);
    if (e && e.pasport_beruvchi) { w.pasport_beruvchi = e.pasport_beruvchi; n++; }
  });
  if (n) saveWorkers(list);
  localStorage.setItem(key("v11_beruvchi"), "1");
  if (n) console.log("pasport_beruvchi migrated", n);
}

function v11ShortCitizen(s) {
  const map = {"узбекистан":"o'zbek","uzbekistan":"o'zbek","таджикистан":"tojik","tajikistan":"tojik","азербайджан":"ozarbayjon","турция":"turk","turkey":"turk","туркменистан":"turkman","turkmenistan":"turkman","казахстан":"qozoq","кыргызстан":"qirg'iz","россия":"rus","russia":"rus","рф":"rus","беларусь":"belarus","армения":"arman"};
  const k = String(s||"").toLowerCase().trim();
  if (map[k]) return map[k];
  for (const [a,b] of Object.entries(map)) if (k.includes(a) || a.includes(k)) return b;
  if (/o'zbek|tojik|turkman|turk|qozoq|qirg|rus|ozarbay/.test(k)) return k;
  return k;
}
function v11MigrateFuqarolik() {
  if (localStorage.getItem(key("v11_fq2"))) return;
  const list = getWorkers(); let n = 0;
  list.forEach(w => {
    if (w.fuqarolik) return;
    let src = w.millat || w.davlat || "";
    if (!src && typeof dbFind === "function") {
      const e = dbFind(w.fio);
      if (e) { src = e.fuqarolik || e.millat || ""; if (e.pasport_beruvchi && !w.pasport_beruvchi) w.pasport_beruvchi = e.pasport_beruvchi; if (e.davlat && !w.davlat) w.davlat = e.davlat; if (e.millat && !w.davlat) w.davlat = e.millat; }
    }
    if (src) { w.fuqarolik = v11ShortCitizen(src); n++; }
    if (!w.davlat && w.millat) w.davlat = String(w.millat).toUpperCase();
  });
  if (n) saveWorkers(list);
  localStorage.setItem(key("v11_fq2"), "1");
  if (n) console.log("fuqarolik filled", n);
}
